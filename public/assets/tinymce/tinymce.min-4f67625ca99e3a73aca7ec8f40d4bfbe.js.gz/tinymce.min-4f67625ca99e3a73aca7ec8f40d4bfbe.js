// 4.0.12 (2013-12-18)
!function (e, t) {
    "use strict";
    function n(e, t) {
        for (var n, r = [], i = 0; i < e.length; ++i) {
            if (n = s[e[i]] || o(e[i]), !n)throw"module definition dependecy not found: " + e[i];
            r.push(n)
        }
        t.apply(null, r)
    }

    function r(e, r, i) {
        if ("string" != typeof e)throw"invalid module definition, module id must be defined and be a string";
        if (r === t)throw"invalid module definition, dependencies must be specified";
        if (i === t)throw"invalid module definition, definition function must be specified";
        n(r, function () {
            s[e] = i.apply(null, arguments)
        })
    }

    function i(e) {
        return!!s[e]
    }

    function o(t) {
        for (var n = e, r = t.split(/[.\/]/), i = 0; i < r.length; ++i) {
            if (!n[r[i]])return;
            n = n[r[i]]
        }
        return n
    }

    function a(n) {
        for (var r = 0; r < n.length; r++) {
            for (var i = e, o = n[r], a = o.split(/[.\/]/), l = 0; l < a.length - 1; ++l)i[a[l]] === t && (i[a[l]] = {}), i = i[a[l]];
            i[a[a.length - 1]] = s[o]
        }
    }

    var s = {}, l = "tinymce/dom/Sizzle", c = "tinymce/html/Styles", d = "tinymce/dom/EventUtils", u = "tinymce/dom/TreeWalker", f = "tinymce/util/Tools", p = "tinymce/dom/Range", m = "tinymce/html/Entities", h = "tinymce/Env", g = "tinymce/dom/DOMUtils", v = "tinymce/dom/ScriptLoader", y = "tinymce/AddOnManager", b = "tinymce/html/Node", C = "tinymce/html/Schema", x = "tinymce/html/SaxParser", w = "tinymce/html/DomParser", _ = "tinymce/html/Writer", N = "tinymce/html/Serializer", E = "tinymce/dom/Serializer", k = "tinymce/dom/TridentSelection", S = "tinymce/util/VK", T = "tinymce/dom/ControlSelection", R = "tinymce/dom/Selection", A = "tinymce/dom/RangeUtils", B = "tinymce/Formatter", L = "tinymce/UndoManager", H = "tinymce/EnterKey", D = "tinymce/ForceBlocks", M = "tinymce/EditorCommands", P = "tinymce/util/URI", O = "tinymce/util/Class", I = "tinymce/ui/Selector", F = "tinymce/ui/Collection", z = "tinymce/ui/DomUtils", W = "tinymce/ui/Control", V = "tinymce/ui/Factory", U = "tinymce/ui/Container", q = "tinymce/ui/DragHelper", j = "tinymce/ui/Scrollable", $ = "tinymce/ui/Panel", K = "tinymce/ui/Movable", Y = "tinymce/ui/Resizable", G = "tinymce/ui/FloatPanel", X = "tinymce/ui/KeyboardNavigation", J = "tinymce/ui/Window", Q = "tinymce/ui/MessageBox", Z = "tinymce/WindowManager", et = "tinymce/util/Quirks", tt = "tinymce/util/Observable", nt = "tinymce/Shortcuts", rt = "tinymce/Editor", it = "tinymce/util/I18n", ot = "tinymce/FocusManager", at = "tinymce/EditorManager", st = "tinymce/LegacyInput", lt = "tinymce/util/XHR", ct = "tinymce/util/JSON", dt = "tinymce/util/JSONRequest", ut = "tinymce/util/JSONP", ft = "tinymce/util/LocalStorage", pt = "tinymce/Compat", mt = "tinymce/ui/Layout", ht = "tinymce/ui/AbsoluteLayout", gt = "tinymce/ui/Tooltip", vt = "tinymce/ui/Widget", yt = "tinymce/ui/Button", bt = "tinymce/ui/ButtonGroup", Ct = "tinymce/ui/Checkbox", xt = "tinymce/ui/PanelButton", wt = "tinymce/ui/ColorButton", _t = "tinymce/ui/ComboBox", Nt = "tinymce/ui/Path", Et = "tinymce/ui/ElementPath", kt = "tinymce/ui/FormItem", St = "tinymce/ui/Form", Tt = "tinymce/ui/FieldSet", Rt = "tinymce/ui/FilePicker", At = "tinymce/ui/FitLayout", Bt = "tinymce/ui/FlexLayout", Lt = "tinymce/ui/FlowLayout", Ht = "tinymce/ui/FormatControls", Dt = "tinymce/ui/GridLayout", Mt = "tinymce/ui/Iframe", Pt = "tinymce/ui/Label", Ot = "tinymce/ui/Toolbar", It = "tinymce/ui/MenuBar", Ft = "tinymce/ui/MenuButton", zt = "tinymce/ui/ListBox", Wt = "tinymce/ui/MenuItem", Vt = "tinymce/ui/Menu", Ut = "tinymce/ui/Radio", qt = "tinymce/ui/ResizeHandle", jt = "tinymce/ui/Spacer", $t = "tinymce/ui/SplitButton", Kt = "tinymce/ui/StackLayout", Yt = "tinymce/ui/TabPanel", Gt = "tinymce/ui/TextBox", Xt = "tinymce/ui/Throbber";
    r(l, [], function () {
        if (!window.jQuery)throw new Error("Load jQuery first");
        return jQuery.find
    }), r(c, [], function () {
        return function (e, t) {
            function n(e, t, n, r) {
                function i(e) {
                    return e = parseInt(e, 10).toString(16), e.length > 1 ? e : "0" + e
                }

                return"#" + i(t) + i(n) + i(r)
            }

            var r = /rgb\s*\(\s*([0-9]+)\s*,\s*([0-9]+)\s*,\s*([0-9]+)\s*\)/gi, i = /(?:url(?:(?:\(\s*\"([^\"]+)\"\s*\))|(?:\(\s*\'([^\']+)\'\s*\))|(?:\(\s*([^)\s]+)\s*\))))|(?:\'([^\']+)\')|(?:\"([^\"]+)\")/gi, o = /\s*([^:]+):\s*([^;]+);?/g, a = /\s+$/, s, l, c = {}, d, u = "\ufeff";
            for (e = e || {}, d = ("\\\" \\' \\; \\: ; : " + u).split(" "), l = 0; l < d.length; l++)c[d[l]] = u + l, c[u + l] = d[l];
            return{toHex: function (e) {
                return e.replace(r, n)
            }, parse: function (t) {
                function s(e, t, n) {
                    var r, i, o, a;
                    if (r = h[e + "-top" + t], r && (i = h[e + "-right" + t], i && (o = h[e + "-bottom" + t], o && (a = h[e + "-left" + t])))) {
                        var s = [r, i, o, a];
                        for (l = s.length - 1; l-- && s[l] === s[l + 1];);
                        l > -1 && n || (h[e + t] = -1 == l ? s[0] : s.join(" "), delete h[e + "-top" + t], delete h[e + "-right" + t], delete h[e + "-bottom" + t], delete h[e + "-left" + t])
                    }
                }

                function d(e) {
                    var t = h[e], n;
                    if (t) {
                        for (t = t.split(" "), n = t.length; n--;)if (t[n] !== t[0])return!1;
                        return h[e] = t[0], !0
                    }
                }

                function u(e, t, n, r) {
                    d(t) && d(n) && d(r) && (h[e] = h[t] + " " + h[n] + " " + h[r], delete h[t], delete h[n], delete h[r])
                }

                function f(e) {
                    return b = !0, c[e]
                }

                function p(e, t) {
                    return b && (e = e.replace(/\uFEFF[0-9]/g, function (e) {
                        return c[e]
                    })), t || (e = e.replace(/\\([\'\";:])/g, "$1")), e
                }

                function m(t, n, r, i, o, a) {
                    return(o = o || a) ? (o = p(o), "'" + o.replace(/\'/g, "\\'") + "'") : (n = p(n || r || i), !e.allow_script_urls && /(java|vb)script:/i.test(n.replace(/[\s\r\n]+/, "")) ? "" : (C && (n = C.call(x, n, "style")), "url('" + n.replace(/\'/g, "\\'") + "')"))
                }

                var h = {}, g, v, y, b, C = e.url_converter, x = e.url_converter_scope || this;
                if (t) {
                    for (t = t.replace(/[\u0000-\u001F]/g, ""), t = t.replace(/\\[\"\';:\uFEFF]/g, f).replace(/\"[^\"]+\"|\'[^\']+\'/g, function (e) {
                        return e.replace(/[;:]/g, f)
                    }); g = o.exec(t);) {
                        if (v = g[1].replace(a, "").toLowerCase(), y = g[2].replace(a, ""), v && y.length > 0) {
                            if (!e.allow_script_urls && ("behavior" == v || /expression\s*\(/.test(y)))continue;
                            "font-weight" === v && "700" === y ? y = "bold" : ("color" === v || "background-color" === v) && (y = y.toLowerCase()), y = y.replace(r, n), y = y.replace(i, m), h[v] = b ? p(y, !0) : y
                        }
                        o.lastIndex = g.index + g[0].length
                    }
                    s("border", "", !0), s("border", "-width"), s("border", "-color"), s("border", "-style"), s("padding", ""), s("margin", ""), u("border", "border-width", "border-style", "border-color"), "medium none" === h.border && delete h.border, "none" === h["border-image"] && delete h["border-image"]
                }
                return h
            }, serialize: function (e, n) {
                function r(n) {
                    var r, o, a, l;
                    if (r = t.styles[n])for (o = 0, a = r.length; a > o; o++)n = r[o], l = e[n], l !== s && l.length > 0 && (i += (i.length > 0 ? " " : "") + n + ": " + l + ";")
                }

                var i = "", o, a;
                if (n && t && t.styles)r("*"), r(n); else for (o in e)a = e[o], a !== s && a.length > 0 && (i += (i.length > 0 ? " " : "") + o + ": " + a + ";");
                return i
            }}
        }
    }), r(d, [], function () {
        function e(e, t, n, r) {
            e.addEventListener ? e.addEventListener(t, n, r || !1) : e.attachEvent && e.attachEvent("on" + t, n)
        }

        function t(e, t, n, r) {
            e.removeEventListener ? e.removeEventListener(t, n, r || !1) : e.detachEvent && e.detachEvent("on" + t, n)
        }

        function n(e, t) {
            function n() {
                return!1
            }

            function r() {
                return!0
            }

            var i, o = t || {}, l;
            for (i in e)s[i] || (o[i] = e[i]);
            if (o.target || (o.target = o.srcElement || document), e && a.test(e.type) && e.pageX === l && e.clientX !== l) {
                var c = o.target.ownerDocument || document, d = c.documentElement, u = c.body;
                o.pageX = e.clientX + (d && d.scrollLeft || u && u.scrollLeft || 0) - (d && d.clientLeft || u && u.clientLeft || 0), o.pageY = e.clientY + (d && d.scrollTop || u && u.scrollTop || 0) - (d && d.clientTop || u && u.clientTop || 0)
            }
            return o.preventDefault = function () {
                o.isDefaultPrevented = r, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
            }, o.stopPropagation = function () {
                o.isPropagationStopped = r, e && (e.stopPropagation ? e.stopPropagation() : e.cancelBubble = !0)
            }, o.stopImmediatePropagation = function () {
                o.isImmediatePropagationStopped = r, o.stopPropagation()
            }, o.isDefaultPrevented || (o.isDefaultPrevented = n, o.isPropagationStopped = n, o.isImmediatePropagationStopped = n), o
        }

        function r(n, r, i) {
            function o() {
                i.domLoaded || (i.domLoaded = !0, r(c))
            }

            function a() {
                "complete" === l.readyState && (t(l, "readystatechange", a), o())
            }

            function s() {
                try {
                    l.documentElement.doScroll("left")
                } catch (e) {
                    return setTimeout(s, 0), void 0
                }
                o()
            }

            var l = n.document, c = {type: "ready"};
            return i.domLoaded ? (r(c), void 0) : (l.addEventListener ? "complete" === l.readyState ? o() : e(n, "DOMContentLoaded", o) : (e(l, "readystatechange", a), l.documentElement.doScroll && n === n.top && s()), e(n, "load", o), void 0)
        }

        function i() {
            function i(e, t) {
                var n, r, i, o, a = s[t];
                if (n = a && a[e.type])for (r = 0, i = n.length; i > r; r++)if (o = n[r], o && o.func.call(o.scope, e) === !1 && e.preventDefault(), e.isImmediatePropagationStopped())return
            }

            var a = this, s = {}, l, c, d, u, f;
            c = o + (+new Date).toString(32), u = "onmouseenter"in document.documentElement, d = "onfocusin"in document.documentElement, f = {mouseenter: "mouseover", mouseleave: "mouseout"}, l = 1, a.domLoaded = !1, a.events = s, a.bind = function (t, o, p, m) {
                function h(e) {
                    i(n(e || _.event), g)
                }

                var g, v, y, b, C, x, w, _ = window;
                if (t && 3 !== t.nodeType && 8 !== t.nodeType) {
                    for (t[c] ? g = t[c] : (g = l++, t[c] = g, s[g] = {}), m = m || t, o = o.split(" "), y = o.length; y--;)b = o[y], x = h, C = w = !1, "DOMContentLoaded" === b && (b = "ready"), a.domLoaded && "ready" === b && "complete" == t.readyState ? p.call(m, n({type: b})) : (u || (C = f[b], C && (x = function (e) {
                        var t, r;
                        if (t = e.currentTarget, r = e.relatedTarget, r && t.contains)r = t.contains(r); else for (; r && r !== t;)r = r.parentNode;
                        r || (e = n(e || _.event), e.type = "mouseout" === e.type ? "mouseleave" : "mouseenter", e.target = t, i(e, g))
                    })), d || "focusin" !== b && "focusout" !== b || (w = !0, C = "focusin" === b ? "focus" : "blur", x = function (e) {
                        e = n(e || _.event), e.type = "focus" === e.type ? "focusin" : "focusout", i(e, g)
                    }), v = s[g][b], v ? "ready" === b && a.domLoaded ? p({type: b}) : v.push({func: p, scope: m}) : (s[g][b] = v = [
                        {func: p, scope: m}
                    ], v.fakeName = C, v.capture = w, v.nativeHandler = x, "ready" === b ? r(t, x, a) : e(t, C || b, x, w)));
                    return t = v = 0, p
                }
            }, a.unbind = function (e, n, r) {
                var i, o, l, d, u, f;
                if (!e || 3 === e.nodeType || 8 === e.nodeType)return a;
                if (i = e[c]) {
                    if (f = s[i], n) {
                        for (n = n.split(" "), l = n.length; l--;)if (u = n[l], o = f[u]) {
                            if (r)for (d = o.length; d--;)if (o[d].func === r) {
                                var p = o.nativeHandler;
                                o = o.slice(0, d).concat(o.slice(d + 1)), o.nativeHandler = p, f[u] = o
                            }
                            r && 0 !== o.length || (delete f[u], t(e, o.fakeName || u, o.nativeHandler, o.capture))
                        }
                    } else {
                        for (u in f)o = f[u], t(e, o.fakeName || u, o.nativeHandler, o.capture);
                        f = {}
                    }
                    for (u in f)return a;
                    delete s[i];
                    try {
                        delete e[c]
                    } catch (m) {
                        e[c] = null
                    }
                }
                return a
            }, a.fire = function (e, t, r) {
                var o;
                if (!e || 3 === e.nodeType || 8 === e.nodeType)return a;
                r = n(null, r), r.type = t, r.target = e;
                do o = e[c], o && i(r, o), e = e.parentNode || e.ownerDocument || e.defaultView || e.parentWindow; while (e && !r.isPropagationStopped());
                return a
            }, a.clean = function (e) {
                var t, n, r = a.unbind;
                if (!e || 3 === e.nodeType || 8 === e.nodeType)return a;
                if (e[c] && r(e), e.getElementsByTagName || (e = e.document), e && e.getElementsByTagName)for (r(e), n = e.getElementsByTagName("*"), t = n.length; t--;)e = n[t], e[c] && r(e);
                return a
            }, a.destroy = function () {
                s = {}
            }, a.cancel = function (e) {
                return e && (e.preventDefault(), e.stopImmediatePropagation()), !1
            }
        }

        var o = "mce-data-", a = /^(?:mouse|contextmenu)|click/, s = {keyLocation: 1, layerX: 1, layerY: 1, returnValue: 1};
        return i.Event = new i, i.Event.bind(window, "ready", function () {
        }), i
    }), r(u, [], function () {
        return function (e, t) {
            function n(e, n, r, i) {
                var o, a;
                if (e) {
                    if (!i && e[n])return e[n];
                    if (e != t) {
                        if (o = e[r])return o;
                        for (a = e.parentNode; a && a != t; a = a.parentNode)if (o = a[r])return o
                    }
                }
            }

            var r = e;
            this.current = function () {
                return r
            }, this.next = function (e) {
                return r = n(r, "firstChild", "nextSibling", e)
            }, this.prev = function (e) {
                return r = n(r, "lastChild", "previousSibling", e)
            }
        }
    }), r(f, [], function () {
        function e(e, n) {
            return n ? "array" == n && g(e) ? !0 : typeof e == n : e !== t
        }

        function n(e) {
            var t = [], n, r;
            for (n = 0, r = e.length; r > n; n++)t[n] = e[n];
            return t
        }

        function r(e, t, n) {
            var r;
            for (e = e || [], t = t || ",", "string" == typeof e && (e = e.split(t)), n = n || {}, r = e.length; r--;)n[e[r]] = {};
            return n
        }

        function i(e, n, r) {
            var i, o;
            if (!e)return 0;
            if (r = r || e, e.length !== t) {
                for (i = 0, o = e.length; o > i; i++)if (n.call(r, e[i], i, e) === !1)return 0
            } else for (i in e)if (e.hasOwnProperty(i) && n.call(r, e[i], i, e) === !1)return 0;
            return 1
        }

        function o(e, t) {
            var n = [];
            return i(e, function (e) {
                n.push(t(e))
            }), n
        }

        function a(e, t) {
            var n = [];
            return i(e, function (e) {
                (!t || t(e)) && n.push(e)
            }), n
        }

        function s(e, t, n) {
            var r = this, i, o, a, s, l, c = 0;
            if (e = /^((static) )?([\w.]+)(:([\w.]+))?/.exec(e), a = e[3].match(/(^|\.)(\w+)$/i)[2], o = r.createNS(e[3].replace(/\.\w+$/, ""), n), !o[a]) {
                if ("static" == e[2])return o[a] = t, this.onCreate && this.onCreate(e[2], e[3], o[a]), void 0;
                t[a] || (t[a] = function () {
                }, c = 1), o[a] = t[a], r.extend(o[a].prototype, t), e[5] && (i = r.resolve(e[5]).prototype, s = e[5].match(/\.(\w+)$/i)[1], l = o[a], o[a] = c ? function () {
                    return i[s].apply(this, arguments)
                } : function () {
                    return this.parent = i[s], l.apply(this, arguments)
                }, o[a].prototype[a] = o[a], r.each(i, function (e, t) {
                    o[a].prototype[t] = i[t]
                }), r.each(t, function (e, t) {
                    i[t] ? o[a].prototype[t] = function () {
                        return this.parent = i[t], e.apply(this, arguments)
                    } : t != a && (o[a].prototype[t] = e)
                })), r.each(t["static"], function (e, t) {
                    o[a][t] = e
                })
            }
        }

        function l(e, t) {
            var n, r;
            if (e)for (n = 0, r = e.length; r > n; n++)if (e[n] === t)return n;
            return-1
        }

        function c(e, n) {
            var r, i, o, a = arguments, s;
            for (r = 1, i = a.length; i > r; r++) {
                n = a[r];
                for (o in n)n.hasOwnProperty(o) && (s = n[o], s !== t && (e[o] = s))
            }
            return e
        }

        function d(e, t, n, r) {
            r = r || this, e && (n && (e = e[n]), i(e, function (e, i) {
                return t.call(r, e, i, n) === !1 ? !1 : (d(e, t, n, r), void 0)
            }))
        }

        function u(e, t) {
            var n, r;
            for (t = t || window, e = e.split("."), n = 0; n < e.length; n++)r = e[n], t[r] || (t[r] = {}), t = t[r];
            return t
        }

        function f(e, t) {
            var n, r;
            for (t = t || window, e = e.split("."), n = 0, r = e.length; r > n && (t = t[e[n]], t); n++);
            return t
        }

        function p(t, n) {
            return!t || e(t, "array") ? t : o(t.split(n || ","), h)
        }

        var m = /^\s*|\s*$/g, h = function (e) {
            return null === e || e === t ? "" : ("" + e).replace(m, "")
        }, g = Array.isArray || function (e) {
            return"[object Array]" === Object.prototype.toString.call(e)
        };
        return{trim: h, isArray: g, is: e, toArray: n, makeMap: r, each: i, map: o, grep: a, inArray: l, extend: c, create: s, walk: d, createNS: u, resolve: f, explode: p}
    }), r(p, [f], function (e) {
        function t(n) {
            function r() {
                return M.createDocumentFragment()
            }

            function i(e, t) {
                _(F, e, t)
            }

            function o(e, t) {
                _(z, e, t)
            }

            function a(e) {
                i(e.parentNode, $(e))
            }

            function s(e) {
                i(e.parentNode, $(e) + 1)
            }

            function l(e) {
                o(e.parentNode, $(e))
            }

            function c(e) {
                o(e.parentNode, $(e) + 1)
            }

            function d(e) {
                e ? (D[U] = D[V], D[q] = D[W]) : (D[V] = D[U], D[W] = D[q]), D.collapsed = F
            }

            function u(e) {
                a(e), c(e)
            }

            function f(e) {
                i(e, 0), o(e, 1 === e.nodeType ? e.childNodes.length : e.nodeValue.length)
            }

            function p(e, t) {
                var n = D[V], r = D[W], i = D[U], o = D[q], a = t.startContainer, s = t.startOffset, l = t.endContainer, c = t.endOffset;
                return 0 === e ? w(n, r, a, s) : 1 === e ? w(i, o, a, s) : 2 === e ? w(i, o, l, c) : 3 === e ? w(n, r, l, c) : void 0
            }

            function m() {
                N(I)
            }

            function h() {
                return N(P)
            }

            function g() {
                return N(O)
            }

            function v(e) {
                var t = this[V], r = this[W], i, o;
                3 !== t.nodeType && 4 !== t.nodeType || !t.nodeValue ? (t.childNodes.length > 0 && (o = t.childNodes[r]), o ? t.insertBefore(e, o) : 3 == t.nodeType ? n.insertAfter(e, t) : t.appendChild(e)) : r ? r >= t.nodeValue.length ? n.insertAfter(e, t) : (i = t.splitText(r), t.parentNode.insertBefore(e, i)) : t.parentNode.insertBefore(e, t)
            }

            function y(e) {
                var t = D.extractContents();
                D.insertNode(e), e.appendChild(t), D.selectNode(e)
            }

            function b() {
                return j(new t(n), {startContainer: D[V], startOffset: D[W], endContainer: D[U], endOffset: D[q], collapsed: D.collapsed, commonAncestorContainer: D.commonAncestorContainer})
            }

            function C(e, t) {
                var n;
                if (3 == e.nodeType)return e;
                if (0 > t)return e;
                for (n = e.firstChild; n && t > 0;)--t, n = n.nextSibling;
                return n ? n : e
            }

            function x() {
                return D[V] == D[U] && D[W] == D[q]
            }

            function w(e, t, r, i) {
                var o, a, s, l, c, d;
                if (e == r)return t == i ? 0 : i > t ? -1 : 1;
                for (o = r; o && o.parentNode != e;)o = o.parentNode;
                if (o) {
                    for (a = 0, s = e.firstChild; s != o && t > a;)a++, s = s.nextSibling;
                    return a >= t ? -1 : 1
                }
                for (o = e; o && o.parentNode != r;)o = o.parentNode;
                if (o) {
                    for (a = 0, s = r.firstChild; s != o && i > a;)a++, s = s.nextSibling;
                    return i > a ? -1 : 1
                }
                for (l = n.findCommonAncestor(e, r), c = e; c && c.parentNode != l;)c = c.parentNode;
                for (c || (c = l), d = r; d && d.parentNode != l;)d = d.parentNode;
                if (d || (d = l), c == d)return 0;
                for (s = l.firstChild; s;) {
                    if (s == c)return-1;
                    if (s == d)return 1;
                    s = s.nextSibling
                }
            }

            function _(e, t, r) {
                var i, o;
                for (e ? (D[V] = t, D[W] = r) : (D[U] = t, D[q] = r), i = D[U]; i.parentNode;)i = i.parentNode;
                for (o = D[V]; o.parentNode;)o = o.parentNode;
                o == i ? w(D[V], D[W], D[U], D[q]) > 0 && D.collapse(e) : D.collapse(e), D.collapsed = x(), D.commonAncestorContainer = n.findCommonAncestor(D[V], D[U])
            }

            function N(e) {
                var t, n = 0, r = 0, i, o, a, s, l, c;
                if (D[V] == D[U])return E(e);
                for (t = D[U], i = t.parentNode; i; t = i, i = i.parentNode) {
                    if (i == D[V])return k(t, e);
                    ++n
                }
                for (t = D[V], i = t.parentNode; i; t = i, i = i.parentNode) {
                    if (i == D[U])return S(t, e);
                    ++r
                }
                for (o = r - n, a = D[V]; o > 0;)a = a.parentNode, o--;
                for (s = D[U]; 0 > o;)s = s.parentNode, o++;
                for (l = a.parentNode, c = s.parentNode; l != c; l = l.parentNode, c = c.parentNode)a = l, s = c;
                return T(a, s, e)
            }

            function E(e) {
                var t, n, i, o, a, s, l, c, d;
                if (e != I && (t = r()), D[W] == D[q])return t;
                if (3 == D[V].nodeType) {
                    if (n = D[V].nodeValue, i = n.substring(D[W], D[q]), e != O && (o = D[V], c = D[W], d = D[q] - D[W], 0 === c && d >= o.nodeValue.length - 1 ? o.parentNode.removeChild(o) : o.deleteData(c, d), D.collapse(F)), e == I)return;
                    return i.length > 0 && t.appendChild(M.createTextNode(i)), t
                }
                for (o = C(D[V], D[W]), a = D[q] - D[W]; o && a > 0;)s = o.nextSibling, l = L(o, e), t && t.appendChild(l), --a, o = s;
                return e != O && D.collapse(F), t
            }

            function k(e, t) {
                var n, i, o, a, s, l;
                if (t != I && (n = r()), i = R(e, t), n && n.appendChild(i), o = $(e), a = o - D[W], 0 >= a)return t != O && (D.setEndBefore(e), D.collapse(z)), n;
                for (i = e.previousSibling; a > 0;)s = i.previousSibling, l = L(i, t), n && n.insertBefore(l, n.firstChild), --a, i = s;
                return t != O && (D.setEndBefore(e), D.collapse(z)), n
            }

            function S(e, t) {
                var n, i, o, a, s, l;
                for (t != I && (n = r()), o = A(e, t), n && n.appendChild(o), i = $(e), ++i, a = D[q] - i, o = e.nextSibling; o && a > 0;)s = o.nextSibling, l = L(o, t), n && n.appendChild(l), --a, o = s;
                return t != O && (D.setStartAfter(e), D.collapse(F)), n
            }

            function T(e, t, n) {
                var i, o, a, s, l, c, d, u;
                for (n != I && (o = r()), i = A(e, n), o && o.appendChild(i), a = e.parentNode, s = $(e), l = $(t), ++s, c = l - s, d = e.nextSibling; c > 0;)u = d.nextSibling, i = L(d, n), o && o.appendChild(i), d = u, --c;
                return i = R(t, n), o && o.appendChild(i), n != O && (D.setStartAfter(e), D.collapse(F)), o
            }

            function R(e, t) {
                var n = C(D[U], D[q] - 1), r, i, o, a, s, l = n != D[U];
                if (n == e)return B(n, l, z, t);
                for (r = n.parentNode, i = B(r, z, z, t); r;) {
                    for (; n;)o = n.previousSibling, a = B(n, l, z, t), t != I && i.insertBefore(a, i.firstChild), l = F, n = o;
                    if (r == e)return i;
                    n = r.previousSibling, r = r.parentNode, s = B(r, z, z, t), t != I && s.appendChild(i), i = s
                }
            }

            function A(e, t) {
                var n = C(D[V], D[W]), r = n != D[V], i, o, a, s, l;
                if (n == e)return B(n, r, F, t);
                for (i = n.parentNode, o = B(i, z, F, t); i;) {
                    for (; n;)a = n.nextSibling, s = B(n, r, F, t), t != I && o.appendChild(s), r = F, n = a;
                    if (i == e)return o;
                    n = i.nextSibling, i = i.parentNode, l = B(i, z, F, t), t != I && l.appendChild(o), o = l
                }
            }

            function B(e, t, r, i) {
                var o, a, s, l, c;
                if (t)return L(e, i);
                if (3 == e.nodeType) {
                    if (o = e.nodeValue, r ? (l = D[W], a = o.substring(l), s = o.substring(0, l)) : (l = D[q], a = o.substring(0, l), s = o.substring(l)), i != O && (e.nodeValue = s), i == I)return;
                    return c = n.clone(e, z), c.nodeValue = a, c
                }
                if (i != I)return n.clone(e, z)
            }

            function L(e, t) {
                return t != I ? t == O ? n.clone(e, F) : e : (e.parentNode.removeChild(e), void 0)
            }

            function H() {
                return n.create("body", null, g()).outerText
            }

            var D = this, M = n.doc, P = 0, O = 1, I = 2, F = !0, z = !1, W = "startOffset", V = "startContainer", U = "endContainer", q = "endOffset", j = e.extend, $ = n.nodeIndex;
            return j(D, {startContainer: M, startOffset: 0, endContainer: M, endOffset: 0, collapsed: F, commonAncestorContainer: M, START_TO_START: 0, START_TO_END: 1, END_TO_END: 2, END_TO_START: 3, setStart: i, setEnd: o, setStartBefore: a, setStartAfter: s, setEndBefore: l, setEndAfter: c, collapse: d, selectNode: u, selectNodeContents: f, compareBoundaryPoints: p, deleteContents: m, extractContents: h, cloneContents: g, insertNode: v, surroundContents: y, cloneRange: b, toStringIE: H}), D
        }

        return t.prototype.toString = function () {
            return this.toStringIE()
        }, t
    }), r(m, [f], function (e) {
        function t(e) {
            var t;
            return t = document.createElement("div"), t.innerHTML = e, t.textContent || t.innerText || e
        }

        function n(e, t) {
            var n, r, i, a = {};
            if (e) {
                for (e = e.split(","), t = t || 10, n = 0; n < e.length; n += 2)r = String.fromCharCode(parseInt(e[n], t)), o[r] || (i = "&" + e[n + 1] + ";", a[r] = i, a[i] = r);
                return a
            }
        }

        var r = e.makeMap, i, o, a, s = /[&<>\"\u007E-\uD7FF\uE000-\uFFEF]|[\uD800-\uDBFF][\uDC00-\uDFFF]/g, l = /[<>&\u007E-\uD7FF\uE000-\uFFEF]|[\uD800-\uDBFF][\uDC00-\uDFFF]/g, c = /[<>&\"\']/g, d = /&(#x|#)?([\w]+);/g, u = {128: "\u20ac", 130: "\u201a", 131: "\u0192", 132: "\u201e", 133: "\u2026", 134: "\u2020", 135: "\u2021", 136: "\u02c6", 137: "\u2030", 138: "\u0160", 139: "\u2039", 140: "\u0152", 142: "\u017d", 145: "\u2018", 146: "\u2019", 147: "\u201c", 148: "\u201d", 149: "\u2022", 150: "\u2013", 151: "\u2014", 152: "\u02dc", 153: "\u2122", 154: "\u0161", 155: "\u203a", 156: "\u0153", 158: "\u017e", 159: "\u0178"};
        o = {'"': "&quot;", "'": "&#39;", "<": "&lt;", ">": "&gt;", "&": "&amp;"}, a = {"&lt;": "<", "&gt;": ">", "&amp;": "&", "&quot;": '"', "&apos;": "'"}, i = n("50,nbsp,51,iexcl,52,cent,53,pound,54,curren,55,yen,56,brvbar,57,sect,58,uml,59,copy,5a,ordf,5b,laquo,5c,not,5d,shy,5e,reg,5f,macr,5g,deg,5h,plusmn,5i,sup2,5j,sup3,5k,acute,5l,micro,5m,para,5n,middot,5o,cedil,5p,sup1,5q,ordm,5r,raquo,5s,frac14,5t,frac12,5u,frac34,5v,iquest,60,Agrave,61,Aacute,62,Acirc,63,Atilde,64,Auml,65,Aring,66,AElig,67,Ccedil,68,Egrave,69,Eacute,6a,Ecirc,6b,Euml,6c,Igrave,6d,Iacute,6e,Icirc,6f,Iuml,6g,ETH,6h,Ntilde,6i,Ograve,6j,Oacute,6k,Ocirc,6l,Otilde,6m,Ouml,6n,times,6o,Oslash,6p,Ugrave,6q,Uacute,6r,Ucirc,6s,Uuml,6t,Yacute,6u,THORN,6v,szlig,70,agrave,71,aacute,72,acirc,73,atilde,74,auml,75,aring,76,aelig,77,ccedil,78,egrave,79,eacute,7a,ecirc,7b,euml,7c,igrave,7d,iacute,7e,icirc,7f,iuml,7g,eth,7h,ntilde,7i,ograve,7j,oacute,7k,ocirc,7l,otilde,7m,ouml,7n,divide,7o,oslash,7p,ugrave,7q,uacute,7r,ucirc,7s,uuml,7t,yacute,7u,thorn,7v,yuml,ci,fnof,sh,Alpha,si,Beta,sj,Gamma,sk,Delta,sl,Epsilon,sm,Zeta,sn,Eta,so,Theta,sp,Iota,sq,Kappa,sr,Lambda,ss,Mu,st,Nu,su,Xi,sv,Omicron,t0,Pi,t1,Rho,t3,Sigma,t4,Tau,t5,Upsilon,t6,Phi,t7,Chi,t8,Psi,t9,Omega,th,alpha,ti,beta,tj,gamma,tk,delta,tl,epsilon,tm,zeta,tn,eta,to,theta,tp,iota,tq,kappa,tr,lambda,ts,mu,tt,nu,tu,xi,tv,omicron,u0,pi,u1,rho,u2,sigmaf,u3,sigma,u4,tau,u5,upsilon,u6,phi,u7,chi,u8,psi,u9,omega,uh,thetasym,ui,upsih,um,piv,812,bull,816,hellip,81i,prime,81j,Prime,81u,oline,824,frasl,88o,weierp,88h,image,88s,real,892,trade,89l,alefsym,8cg,larr,8ch,uarr,8ci,rarr,8cj,darr,8ck,harr,8dl,crarr,8eg,lArr,8eh,uArr,8ei,rArr,8ej,dArr,8ek,hArr,8g0,forall,8g2,part,8g3,exist,8g5,empty,8g7,nabla,8g8,isin,8g9,notin,8gb,ni,8gf,prod,8gh,sum,8gi,minus,8gn,lowast,8gq,radic,8gt,prop,8gu,infin,8h0,ang,8h7,and,8h8,or,8h9,cap,8ha,cup,8hb,int,8hk,there4,8hs,sim,8i5,cong,8i8,asymp,8j0,ne,8j1,equiv,8j4,le,8j5,ge,8k2,sub,8k3,sup,8k4,nsub,8k6,sube,8k7,supe,8kl,oplus,8kn,otimes,8l5,perp,8m5,sdot,8o8,lceil,8o9,rceil,8oa,lfloor,8ob,rfloor,8p9,lang,8pa,rang,9ea,loz,9j0,spades,9j3,clubs,9j5,hearts,9j6,diams,ai,OElig,aj,oelig,b0,Scaron,b1,scaron,bo,Yuml,m6,circ,ms,tilde,802,ensp,803,emsp,809,thinsp,80c,zwnj,80d,zwj,80e,lrm,80f,rlm,80j,ndash,80k,mdash,80o,lsquo,80p,rsquo,80q,sbquo,80s,ldquo,80t,rdquo,80u,bdquo,810,dagger,811,Dagger,81g,permil,81p,lsaquo,81q,rsaquo,85c,euro", 32);
        var f = {encodeRaw: function (e, t) {
            return e.replace(t ? s : l, function (e) {
                return o[e] || e
            })
        }, encodeAllRaw: function (e) {
            return("" + e).replace(c, function (e) {
                return o[e] || e
            })
        }, encodeNumeric: function (e, t) {
            return e.replace(t ? s : l, function (e) {
                return e.length > 1 ? "&#" + (1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320) + 65536) + ";" : o[e] || "&#" + e.charCodeAt(0) + ";"
            })
        }, encodeNamed: function (e, t, n) {
            return n = n || i, e.replace(t ? s : l, function (e) {
                return o[e] || n[e] || e
            })
        }, getEncodeFunc: function (e, t) {
            function a(e, n) {
                return e.replace(n ? s : l, function (e) {
                    return o[e] || t[e] || "&#" + e.charCodeAt(0) + ";" || e
                })
            }

            function c(e, n) {
                return f.encodeNamed(e, n, t)
            }

            return t = n(t) || i, e = r(e.replace(/\+/g, ",")), e.named && e.numeric ? a : e.named ? t ? c : f.encodeNamed : e.numeric ? f.encodeNumeric : f.encodeRaw
        }, decode: function (e) {
            return e.replace(d, function (e, n, r) {
                return n ? (r = parseInt(r, 2 === n.length ? 16 : 10), r > 65535 ? (r -= 65536, String.fromCharCode(55296 + (r >> 10), 56320 + (1023 & r))) : u[r] || String.fromCharCode(r)) : a[e] || i[e] || t(e)
            })
        }};
        return f
    }), r(h, [], function () {
        var e = navigator, t = e.userAgent, n, r, i, o, a, s, l;
        n = window.opera && window.opera.buildNumber, r = /WebKit/.test(t), i = !r && !n && /MSIE/gi.test(t) && /Explorer/gi.test(e.appName), i = i && /MSIE (\w+)\./.exec(t)[1], o = -1 == t.indexOf("Trident/") || -1 == t.indexOf("rv:") && -1 == e.appName.indexOf("Netscape") ? !1 : 11, i = i || o, a = !r && !o && /Gecko/.test(t), s = -1 != t.indexOf("Mac"), l = /(iPad|iPhone)/.test(t);
        var c = !l || t.match(/AppleWebKit\/(\d*)/)[1] >= 534;
        return{opera: n, webkit: r, ie: i, gecko: a, mac: s, iOS: l, contentEditable: c, transparentSrc: "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", caretAfter: 8 != i, range: window.getSelection && "Range"in window, documentMode: i ? document.documentMode || 7 : 10}
    }), r(g, [l, c, d, u, p, m, h, f], function (e, n, r, i, o, a, s, l) {
        function c(e, t) {
            var i = this, o;
            i.doc = e, i.win = window, i.files = {}, i.counter = 0, i.stdMode = !g || e.documentMode >= 8, i.boxModel = !g || "CSS1Compat" == e.compatMode || i.stdMode, i.hasOuterHTML = "outerHTML"in e.createElement("a"), this.boundEvents = [], i.settings = t = m({keep_values: !1, hex_colors: 1}, t), i.schema = t.schema, i.styles = new n({url_converter: t.url_converter, url_converter_scope: t.url_converter_scope}, t.schema), i.fixDoc(e), i.events = t.ownEvents ? new r(t.proxy) : r.Event, o = t.schema ? t.schema.getBlockElements() : {}, i.isBlock = function (e) {
                if (!e)return!1;
                var t = e.nodeType;
                return t ? !(1 !== t || !o[e.nodeName]) : !!o[e]
            }
        }

        var d = l.each, u = l.is, f = l.grep, p = l.trim, m = l.extend, h = s.webkit, g = s.ie, v = /^([a-z0-9],?)+$/i, y = /^[ \t\r\n]*$/, b = l.makeMap("fillOpacity fontWeight lineHeight opacity orphans widows zIndex zoom", " ");
        return c.prototype = {root: null, props: {"for": "htmlFor", "class": "className", className: "className", checked: "checked", disabled: "disabled", maxlength: "maxLength", readonly: "readOnly", selected: "selected", value: "value", id: "id", name: "name", type: "type"}, fixDoc: function (e) {
            var t = this.settings, n;
            if (g && t.schema) {
                "abbr article aside audio canvas details figcaption figure footer header hgroup mark menu meter nav output progress section summary time video".replace(/\w+/g, function (t) {
                    e.createElement(t)
                });
                for (n in t.schema.getCustomElements())e.createElement(n)
            }
        }, clone: function (e, t) {
            var n = this, r, i;
            return!g || 1 !== e.nodeType || t ? e.cloneNode(t) : (i = n.doc, t ? r.firstChild : (r = i.createElement(e.nodeName), d(n.getAttribs(e), function (t) {
                n.setAttrib(r, t.nodeName, n.getAttrib(e, t.nodeName))
            }), r))
        }, getRoot: function () {
            var e = this;
            return e.get(e.settings.root_element) || e.doc.body
        }, getViewPort: function (e) {
            var t, n;
            return e = e ? e : this.win, t = e.document, n = this.boxModel ? t.documentElement : t.body, {x: e.pageXOffset || n.scrollLeft, y: e.pageYOffset || n.scrollTop, w: e.innerWidth || n.clientWidth, h: e.innerHeight || n.clientHeight}
        }, getRect: function (e) {
            var t = this, n, r;
            return e = t.get(e), n = t.getPos(e), r = t.getSize(e), {x: n.x, y: n.y, w: r.w, h: r.h}
        }, getSize: function (e) {
            var t = this, n, r;
            return e = t.get(e), n = t.getStyle(e, "width"), r = t.getStyle(e, "height"), -1 === n.indexOf("px") && (n = 0), -1 === r.indexOf("px") && (r = 0), {w: parseInt(n, 10) || e.offsetWidth || e.clientWidth, h: parseInt(r, 10) || e.offsetHeight || e.clientHeight}
        }, getParent: function (e, t, n) {
            return this.getParents(e, t, n, !1)
        }, getParents: function (e, n, r, i) {
            var o = this, a, s = [];
            for (e = o.get(e), i = i === t, r = r || ("BODY" != o.getRoot().nodeName ? o.getRoot().parentNode : null), u(n, "string") && (a = n, n = "*" === n ? function (e) {
                return 1 == e.nodeType
            } : function (e) {
                return o.is(e, a)
            }); e && e != r && e.nodeType && 9 !== e.nodeType;) {
                if (!n || n(e)) {
                    if (!i)return e;
                    s.push(e)
                }
                e = e.parentNode
            }
            return i ? s : null
        }, get: function (e) {
            var t;
            return e && this.doc && "string" == typeof e && (t = e, e = this.doc.getElementById(e), e && e.id !== t) ? this.doc.getElementsByName(t)[1] : e
        }, getNext: function (e, t) {
            return this._findSib(e, t, "nextSibling")
        }, getPrev: function (e, t) {
            return this._findSib(e, t, "previousSibling")
        }, select: function (t, n) {
            var r = this;
            return e(t, r.get(n) || r.get(r.settings.root_element) || r.doc, [])
        }, is: function (n, r) {
            var i;
            if (n.length === t) {
                if ("*" === r)return 1 == n.nodeType;
                if (v.test(r)) {
                    for (r = r.toLowerCase().split(/,/), n = n.nodeName.toLowerCase(), i = r.length - 1; i >= 0; i--)if (r[i] == n)return!0;
                    return!1
                }
            }
            return n.nodeType && 1 != n.nodeType ? !1 : e.matches(r, n.nodeType ? [n] : n).length > 0
        }, add: function (e, t, n, r, i) {
            var o = this;
            return this.run(e, function (e) {
                var a;
                return a = u(t, "string") ? o.doc.createElement(t) : t, o.setAttribs(a, n), r && (r.nodeType ? a.appendChild(r) : o.setHTML(a, r)), i ? a : e.appendChild(a)
            })
        }, create: function (e, t, n) {
            return this.add(this.doc.createElement(e), e, t, n, 1)
        }, createHTML: function (e, t, n) {
            var r = "", i;
            r += "<" + e;
            for (i in t)t.hasOwnProperty(i) && null !== t[i] && (r += " " + i + '="' + this.encode(t[i]) + '"');
            return"undefined" != typeof n ? r + ">" + n + "</" + e + ">" : r + " />"
        }, createFragment: function (e) {
            var t, n, r = this.doc, i;
            for (i = r.createElement("div"), t = r.createDocumentFragment(), e && (i.innerHTML = e); n = i.firstChild;)t.appendChild(n);
            return t
        }, remove: function (e, t) {
            return this.run(e, function (e) {
                var n, r = e.parentNode;
                if (!r)return null;
                if (t)for (; n = e.firstChild;)!g || 3 !== n.nodeType || n.nodeValue ? r.insertBefore(n, e) : e.removeChild(n);
                return r.removeChild(e)
            })
        }, setStyle: function (e, t, n) {
            return this.run(e, function (e) {
                var r = this, i, o;
                if (t)if ("string" == typeof t) {
                    i = e.style, t = t.replace(/-(\D)/g, function (e, t) {
                        return t.toUpperCase()
                    }), "number" != typeof n || b[t] || (n += "px"), "opacity" === t && e.runtimeStyle && "undefined" == typeof e.runtimeStyle.opacity && (i.filter = "" === n ? "" : "alpha(opacity=" + 100 * n + ")"), "float" == t && (t = "cssFloat"in e.style ? "cssFloat" : "styleFloat");
                    try {
                        i[t] = n
                    } catch (a) {
                    }
                    r.settings.update_styles && e.removeAttribute("data-mce-style")
                } else for (o in t)r.setStyle(e, o, t[o])
            })
        }, getStyle: function (e, n, r) {
            if (e = this.get(e)) {
                if (this.doc.defaultView && r) {
                    n = n.replace(/[A-Z]/g, function (e) {
                        return"-" + e
                    });
                    try {
                        return this.doc.defaultView.getComputedStyle(e, null).getPropertyValue(n)
                    } catch (i) {
                        return null
                    }
                }
                return n = n.replace(/-(\D)/g, function (e, t) {
                    return t.toUpperCase()
                }), "float" == n && (n = g ? "styleFloat" : "cssFloat"), e.currentStyle && r ? e.currentStyle[n] : e.style ? e.style[n] : t
            }
        }, setStyles: function (e, t) {
            this.setStyle(e, t)
        }, css: function (e, t, n) {
            this.setStyle(e, t, n)
        }, removeAllAttribs: function (e) {
            return this.run(e, function (e) {
                var t, n = e.attributes;
                for (t = n.length - 1; t >= 0; t--)e.removeAttributeNode(n.item(t))
            })
        }, setAttrib: function (e, t, n) {
            var r = this;
            if (e && t)return this.run(e, function (e) {
                var i = r.settings, o = e.getAttribute(t);
                if (null !== n)switch (t) {
                    case"style":
                        if (!u(n, "string"))return d(n, function (t, n) {
                            r.setStyle(e, n, t)
                        }), void 0;
                        i.keep_values && (n ? e.setAttribute("data-mce-style", n, 2) : e.removeAttribute("data-mce-style", 2)), e.style.cssText = n;
                        break;
                    case"class":
                        e.className = n || "";
                        break;
                    case"src":
                    case"href":
                        i.keep_values && (i.url_converter && (n = i.url_converter.call(i.url_converter_scope || r, n, t, e)), r.setAttrib(e, "data-mce-" + t, n, 2));
                        break;
                    case"shape":
                        e.setAttribute("data-mce-style", n)
                }
                u(n) && null !== n && 0 !== n.length ? e.setAttribute(t, "" + n, 2) : e.removeAttribute(t, 2), o != n && i.onSetAttrib && i.onSetAttrib({attrElm: e, attrName: t, attrValue: n})
            })
        }, setAttribs: function (e, t) {
            var n = this;
            return this.run(e, function (e) {
                d(t, function (t, r) {
                    n.setAttrib(e, r, t)
                })
            })
        }, getAttrib: function (e, t, n) {
            var r, i = this, o;
            if (e = i.get(e), !e || 1 !== e.nodeType)return n === o ? !1 : n;
            if (u(n) || (n = ""), /^(src|href|style|coords|shape)$/.test(t) && (r = e.getAttribute("data-mce-" + t)))return r;
            if (g && i.props[t] && (r = e[i.props[t]], r = r && r.nodeValue ? r.nodeValue : r), r || (r = e.getAttribute(t, 2)), /^(checked|compact|declare|defer|disabled|ismap|multiple|nohref|noshade|nowrap|readonly|selected)$/.test(t))return e[i.props[t]] === !0 && "" === r ? t : r ? t : "";
            if ("FORM" === e.nodeName && e.getAttributeNode(t))return e.getAttributeNode(t).nodeValue;
            if ("style" === t && (r = r || e.style.cssText, r && (r = i.serializeStyle(i.parseStyle(r), e.nodeName), i.settings.keep_values && e.setAttribute("data-mce-style", r))), h && "class" === t && r && (r = r.replace(/(apple|webkit)\-[a-z\-]+/gi, "")), g)switch (t) {
                case"rowspan":
                case"colspan":
                    1 === r && (r = "");
                    break;
                case"size":
                    ("+0" === r || 20 === r || 0 === r) && (r = "");
                    break;
                case"width":
                case"height":
                case"vspace":
                case"checked":
                case"disabled":
                case"readonly":
                    0 === r && (r = "");
                    break;
                case"hspace":
                    -1 === r && (r = "");
                    break;
                case"maxlength":
                case"tabindex":
                    (32768 === r || 2147483647 === r || "32768" === r) && (r = "");
                    break;
                case"multiple":
                case"compact":
                case"noshade":
                case"nowrap":
                    return 65535 === r ? t : n;
                case"shape":
                    r = r.toLowerCase();
                    break;
                default:
                    0 === t.indexOf("on") && r && (r = ("" + r).replace(/^function\s+\w+\(\)\s+\{\s+(.*)\s+\}$/, "$1"))
            }
            return r !== o && null !== r && "" !== r ? "" + r : n
        }, getPos: function (e, t) {
            var n = this, r = 0, i = 0, o, a = n.doc, s;
            if (e = n.get(e), t = t || a.body, e) {
                if (t === a.body && e.getBoundingClientRect)return s = e.getBoundingClientRect(), t = n.boxModel ? a.documentElement : a.body, r = s.left + (a.documentElement.scrollLeft || a.body.scrollLeft) - t.clientTop, i = s.top + (a.documentElement.scrollTop || a.body.scrollTop) - t.clientLeft, {x: r, y: i};
                for (o = e; o && o != t && o.nodeType;)r += o.offsetLeft || 0, i += o.offsetTop || 0, o = o.offsetParent;
                for (o = e.parentNode; o && o != t && o.nodeType;)r -= o.scrollLeft || 0, i -= o.scrollTop || 0, o = o.parentNode
            }
            return{x: r, y: i}
        }, parseStyle: function (e) {
            return this.styles.parse(e)
        }, serializeStyle: function (e, t) {
            return this.styles.serialize(e, t)
        }, addStyle: function (e) {
            var t = this, n = t.doc, r, i;
            if (t !== c.DOM && n === document) {
                var o = c.DOM.addedStyles;
                if (o = o || [], o[e])return;
                o[e] = !0, c.DOM.addedStyles = o
            }
            i = n.getElementById("mceDefaultStyles"), i || (i = n.createElement("style"), i.id = "mceDefaultStyles", i.type = "text/css", r = n.getElementsByTagName("head")[0], r.firstChild ? r.insertBefore(i, r.firstChild) : r.appendChild(i)), i.styleSheet ? i.styleSheet.cssText += e : i.appendChild(n.createTextNode(e))
        }, loadCSS: function (e) {
            var t = this, n = t.doc, r;
            return t !== c.DOM && n === document ? (c.DOM.loadCSS(e), void 0) : (e || (e = ""), r = n.getElementsByTagName("head")[0], d(e.split(","), function (e) {
                var i;
                t.files[e] || (t.files[e] = !0, i = t.create("link", {rel: "stylesheet", href: e}), g && n.documentMode && n.recalc && (i.onload = function () {
                    n.recalc && n.recalc(), i.onload = null
                }), r.appendChild(i))
            }), void 0)
        }, addClass: function (e, t) {
            return this.run(e, function (e) {
                var n;
                return t ? this.hasClass(e, t) ? e.className : (n = this.removeClass(e, t), e.className = n = ("" !== n ? n + " " : "") + t, n) : 0
            })
        }, removeClass: function (e, t) {
            var n = this, r;
            return n.run(e, function (e) {
                var i;
                return n.hasClass(e, t) ? (r || (r = new RegExp("(^|\\s+)" + t + "(\\s+|$)", "g")), i = e.className.replace(r, " "), i = p(" " != i ? i : ""), e.className = i, i || (e.removeAttribute("class"), e.removeAttribute("className")), i) : e.className
            })
        }, hasClass: function (e, t) {
            return e = this.get(e), e && t ? -1 !== (" " + e.className + " ").indexOf(" " + t + " ") : !1
        }, toggleClass: function (e, n, r) {
            r = r === t ? !this.hasClass(e, n) : r, this.hasClass(e, n) !== r && (r ? this.addClass(e, n) : this.removeClass(e, n))
        }, show: function (e) {
            return this.setStyle(e, "display", "block")
        }, hide: function (e) {
            return this.setStyle(e, "display", "none")
        }, isHidden: function (e) {
            return e = this.get(e), !e || "none" == e.style.display || "none" == this.getStyle(e, "display")
        }, uniqueId: function (e) {
            return(e ? e : "mce_") + this.counter++
        }, setHTML: function (e, t) {
            var n = this;
            return n.run(e, function (e) {
                if (g) {
                    for (; e.firstChild;)e.removeChild(e.firstChild);
                    try {
                        e.innerHTML = "<br />" + t, e.removeChild(e.firstChild)
                    } catch (r) {
                        var i = n.create("div");
                        i.innerHTML = "<br />" + t, d(f(i.childNodes), function (t, n) {
                            n && e.canHaveHTML && e.appendChild(t)
                        })
                    }
                } else e.innerHTML = t;
                return t
            })
        }, getOuterHTML: function (e) {
            var t, n = this;
            return(e = n.get(e)) ? 1 === e.nodeType && n.hasOuterHTML ? e.outerHTML : (t = (e.ownerDocument || n.doc).createElement("body"), t.appendChild(e.cloneNode(!0)), t.innerHTML) : null
        }, setOuterHTML: function (e, t, n) {
            var r = this;
            return r.run(e, function (e) {
                function i() {
                    var i, o;
                    for (o = n.createElement("body"), o.innerHTML = t, i = o.lastChild; i;)r.insertAfter(i.cloneNode(!0), e), i = i.previousSibling;
                    r.remove(e)
                }

                if (1 == e.nodeType)if (n = n || e.ownerDocument || r.doc, g)try {
                    1 == e.nodeType && r.hasOuterHTML ? e.outerHTML = t : i()
                } catch (o) {
                    i()
                } else i()
            })
        }, decode: a.decode, encode: a.encodeAllRaw, insertAfter: function (e, t) {
            return t = this.get(t), this.run(e, function (e) {
                var n, r;
                return n = t.parentNode, r = t.nextSibling, r ? n.insertBefore(e, r) : n.appendChild(e), e
            })
        }, replace: function (e, t, n) {
            var r = this;
            return r.run(t, function (t) {
                return u(t, "array") && (e = e.cloneNode(!0)), n && d(f(t.childNodes), function (t) {
                    e.appendChild(t)
                }), t.parentNode.replaceChild(e, t)
            })
        }, rename: function (e, t) {
            var n = this, r;
            return e.nodeName != t.toUpperCase() && (r = n.create(t), d(n.getAttribs(e), function (t) {
                n.setAttrib(r, t.nodeName, n.getAttrib(e, t.nodeName))
            }), n.replace(r, e, 1)), r || e
        }, findCommonAncestor: function (e, t) {
            for (var n = e, r; n;) {
                for (r = t; r && n != r;)r = r.parentNode;
                if (n == r)break;
                n = n.parentNode
            }
            return!n && e.ownerDocument ? e.ownerDocument.documentElement : n
        }, toHex: function (e) {
            return this.styles.toHex(l.trim(e))
        }, run: function (e, t, n) {
            var r = this, i;
            return"string" == typeof e && (e = r.get(e)), e ? (n = n || this, e.nodeType || !e.length && 0 !== e.length ? t.call(n, e) : (i = [], d(e, function (e, o) {
                e && ("string" == typeof e && (e = r.get(e)), i.push(t.call(n, e, o)))
            }), i)) : !1
        }, getAttribs: function (e) {
            var t;
            if (e = this.get(e), !e)return[];
            if (g) {
                if (t = [], "OBJECT" == e.nodeName)return e.attributes;
                "OPTION" === e.nodeName && this.getAttrib(e, "selected") && t.push({specified: 1, nodeName: "selected"});
                var n = /<\/?[\w:\-]+ ?|=[\"][^\"]+\"|=\'[^\']+\'|=[\w\-]+|>/gi;
                return e.cloneNode(!1).outerHTML.replace(n, "").replace(/[\w:\-]+/gi, function (e) {
                    t.push({specified: 1, nodeName: e})
                }), t
            }
            return e.attributes
        }, isEmpty: function (e, t) {
            var n = this, r, o, a, s, l, c = 0;
            if (e = e.firstChild) {
                s = new i(e, e.parentNode), t = t || n.schema ? n.schema.getNonEmptyElements() : null;
                do {
                    if (a = e.nodeType, 1 === a) {
                        if (e.getAttribute("data-mce-bogus"))continue;
                        if (l = e.nodeName.toLowerCase(), t && t[l]) {
                            if ("br" === l) {
                                c++;
                                continue
                            }
                            return!1
                        }
                        for (o = n.getAttribs(e), r = e.attributes.length; r--;)if (l = e.attributes[r].nodeName, "name" === l || "data-mce-bookmark" === l)return!1
                    }
                    if (8 == a)return!1;
                    if (3 === a && !y.test(e.nodeValue))return!1
                } while (e = s.next())
            }
            return 1 >= c
        }, createRng: function () {
            var e = this.doc;
            return e.createRange ? e.createRange() : new o(this)
        }, nodeIndex: function (e, t) {
            var n = 0, r, i, o;
            if (e)for (r = e.nodeType, e = e.previousSibling, i = e; e; e = e.previousSibling)o = e.nodeType, (!t || 3 != o || o != r && e.nodeValue.length) && (n++, r = o);
            return n
        }, split: function (e, t, n) {
            function r(e) {
                function t(e) {
                    var t = e.previousSibling && "SPAN" == e.previousSibling.nodeName, n = e.nextSibling && "SPAN" == e.nextSibling.nodeName;
                    return t && n
                }

                var n, o = e.childNodes, a = e.nodeType;
                if (1 != a || "bookmark" != e.getAttribute("data-mce-type")) {
                    for (n = o.length - 1; n >= 0; n--)r(o[n]);
                    if (9 != a) {
                        if (3 == a && e.nodeValue.length > 0) {
                            var s = p(e.nodeValue).length;
                            if (!i.isBlock(e.parentNode) || s > 0 || 0 === s && t(e))return
                        } else if (1 == a && (o = e.childNodes, 1 == o.length && o[0] && 1 == o[0].nodeType && "bookmark" == o[0].getAttribute("data-mce-type") && e.parentNode.insertBefore(o[0], e), o.length || /^(br|hr|input|img)$/i.test(e.nodeName)))return;
                        i.remove(e)
                    }
                    return e
                }
            }

            var i = this, o = i.createRng(), a, s, l;
            return e && t ? (o.setStart(e.parentNode, i.nodeIndex(e)), o.setEnd(t.parentNode, i.nodeIndex(t)), a = o.extractContents(), o = i.createRng(), o.setStart(t.parentNode, i.nodeIndex(t) + 1), o.setEnd(e.parentNode, i.nodeIndex(e) + 1), s = o.extractContents(), l = e.parentNode, l.insertBefore(r(a), e), n ? l.replaceChild(n, t) : l.insertBefore(t, e), l.insertBefore(r(s), e), i.remove(e), n || t) : void 0
        }, bind: function (e, t, n, r) {
            var i = this;
            if (l.isArray(e)) {
                for (var o = e.length; o--;)e[o] = i.bind(e[o], t, n, r);
                return e
            }
            return!i.settings.collect || e !== i.doc && e !== i.win || i.boundEvents.push([e, t, n, r]), i.events.bind(e, t, n, r || i)
        }, unbind: function (e, t, n) {
            var r = this, i;
            if (l.isArray(e)) {
                for (i = e.length; i--;)e[i] = r.unbind(e[i], t, n);
                return e
            }
            if (r.boundEvents && (e === r.doc || e === r.win))for (i = r.boundEvents.length; i--;) {
                var o = r.boundEvents[i];
                e != o[0] || t && t != o[1] || n && n != o[2] || this.events.unbind(o[0], o[1], o[2])
            }
            return this.events.unbind(e, t, n)
        }, fire: function (e, t, n) {
            return this.events.fire(e, t, n)
        }, getContentEditable: function (e) {
            var t;
            return 1 != e.nodeType ? null : (t = e.getAttribute("data-mce-contenteditable"), t && "inherit" !== t ? t : "inherit" !== e.contentEditable ? e.contentEditable : null)
        }, destroy: function () {
            var t = this;
            if (t.boundEvents) {
                for (var n = t.boundEvents.length; n--;) {
                    var r = t.boundEvents[n];
                    this.events.unbind(r[0], r[1], r[2])
                }
                t.boundEvents = null
            }
            e.setDocument && e.setDocument(), t.win = t.doc = t.root = t.events = t.frag = null
        }, dumpRng: function (e) {
            return"startContainer: " + e.startContainer.nodeName + ", startOffset: " + e.startOffset + ", endContainer: " + e.endContainer.nodeName + ", endOffset: " + e.endOffset
        }, _findSib: function (e, t, n) {
            var r = this, i = t;
            if (e)for ("string" == typeof i && (i = function (e) {
                return r.is(e, t)
            }), e = e[n]; e; e = e[n])if (i(e))return e;
            return null
        }}, c.DOM = new c(document), c
    }), r(v, [g, f], function (e, t) {
        function n() {
            function e(e, t) {
                function n() {
                    o.remove(s), a && (a.onreadystatechange = a.onload = a = null), t()
                }

                function i() {
                    "undefined" != typeof console && console.log && console.log("Failed to load: " + e)
                }

                var o = r, a, s;
                s = o.uniqueId(), a = document.createElement("script"), a.id = s, a.type = "text/javascript", a.src = e, "onreadystatechange"in a ? a.onreadystatechange = function () {
                    /loaded|complete/.test(a.readyState) && n()
                } : a.onload = n, a.onerror = i, (document.getElementsByTagName("head")[0] || document.body).appendChild(a)
            }

            var t = 0, n = 1, a = 2, s = {}, l = [], c = {}, d = [], u = 0, f;
            this.isDone = function (e) {
                return s[e] == a
            }, this.markDone = function (e) {
                s[e] = a
            }, this.add = this.load = function (e, n, r) {
                var i = s[e];
                i == f && (l.push(e), s[e] = t), n && (c[e] || (c[e] = []), c[e].push({func: n, scope: r || this}))
            }, this.loadQueue = function (e, t) {
                this.loadScripts(l, e, t)
            }, this.loadScripts = function (t, r, l) {
                function p(e) {
                    i(c[e], function (e) {
                        e.func.call(e.scope)
                    }), c[e] = f
                }

                var m;
                d.push({func: r, scope: l || this}), m = function () {
                    var r = o(t);
                    t.length = 0, i(r, function (t) {
                        return s[t] == a ? (p(t), void 0) : (s[t] != n && (s[t] = n, u++, e(t, function () {
                            s[t] = a, u--, p(t), m()
                        })), void 0)
                    }), u || (i(d, function (e) {
                        e.func.call(e.scope)
                    }), d.length = 0)
                }, m()
            }
        }

        var r = e.DOM, i = t.each, o = t.grep;
        return n.ScriptLoader = new n, n
    }), r(y, [v, f], function (e, n) {
        function r() {
            var e = this;
            e.items = [], e.urls = {}, e.lookup = {}
        }

        var i = n.each;
        return r.prototype = {get: function (e) {
            return this.lookup[e] ? this.lookup[e].instance : t
        }, dependencies: function (e) {
            var t;
            return this.lookup[e] && (t = this.lookup[e].dependencies), t || []
        }, requireLangPack: function (t, n) {
            if (r.language && r.languageLoad !== !1) {
                if (n && new RegExp("([, ]|\\b)" + r.language + "([, ]|\\b)").test(n) === !1)return;
                e.ScriptLoader.add(this.urls[t] + "/langs/" + r.language + ".js")
            }
        }, add: function (e, t, n) {
            return this.items.push(t), this.lookup[e] = {instance: t, dependencies: n}, t
        }, createUrl: function (e, t) {
            return"object" == typeof t ? t : {prefix: e.prefix, resource: t, suffix: e.suffix}
        }, addComponents: function (t, n) {
            var r = this.urls[t];
            i(n, function (t) {
                e.ScriptLoader.add(r + "/" + t)
            })
        }, load: function (n, o, a, s) {
            function l() {
                var r = c.dependencies(n);
                i(r, function (e) {
                    var n = c.createUrl(o, e);
                    c.load(n.resource, n, t, t)
                }), a && (s ? a.call(s) : a.call(e))
            }

            var c = this, d = o;
            c.urls[n] || ("object" == typeof o && (d = o.prefix + o.resource + o.suffix), 0 !== d.indexOf("/") && -1 == d.indexOf("://") && (d = r.baseURL + "/" + d), c.urls[n] = d.substring(0, d.lastIndexOf("/")), c.lookup[n] ? l() : e.ScriptLoader.add(d, l, s))
        }}, r.PluginManager = new r, r.ThemeManager = new r, r
    }), r(b, [], function () {
        function e(e, t, n) {
            var r, i, o = n ? "lastChild" : "firstChild", a = n ? "prev" : "next";
            if (e[o])return e[o];
            if (e !== t) {
                if (r = e[a])return r;
                for (i = e.parent; i && i !== t; i = i.parent)if (r = i[a])return r
            }
        }

        function t(e, t) {
            this.name = e, this.type = t, 1 === t && (this.attributes = [], this.attributes.map = {})
        }

        var n = /^[ \t\r\n]*$/, r = {"#text": 3, "#comment": 8, "#cdata": 4, "#pi": 7, "#doctype": 10, "#document-fragment": 11};
        return t.prototype = {replace: function (e) {
            var t = this;
            return e.parent && e.remove(), t.insert(e, t), t.remove(), t
        }, attr: function (e, t) {
            var n = this, r, i, o;
            if ("string" != typeof e) {
                for (i in e)n.attr(i, e[i]);
                return n
            }
            if (r = n.attributes) {
                if (t !== o) {
                    if (null === t) {
                        if (e in r.map)for (delete r.map[e], i = r.length; i--;)if (r[i].name === e)return r = r.splice(i, 1), n;
                        return n
                    }
                    if (e in r.map) {
                        for (i = r.length; i--;)if (r[i].name === e) {
                            r[i].value = t;
                            break
                        }
                    } else r.push({name: e, value: t});
                    return r.map[e] = t, n
                }
                return r.map[e]
            }
        }, clone: function () {
            var e = this, n = new t(e.name, e.type), r, i, o, a, s;
            if (o = e.attributes) {
                for (s = [], s.map = {}, r = 0, i = o.length; i > r; r++)a = o[r], "id" !== a.name && (s[s.length] = {name: a.name, value: a.value}, s.map[a.name] = a.value);
                n.attributes = s
            }
            return n.value = e.value, n.shortEnded = e.shortEnded, n
        }, wrap: function (e) {
            var t = this;
            return t.parent.insert(e, t), e.append(t), t
        }, unwrap: function () {
            var e = this, t, n;
            for (t = e.firstChild; t;)n = t.next, e.insert(t, e, !0), t = n;
            e.remove()
        }, remove: function () {
            var e = this, t = e.parent, n = e.next, r = e.prev;
            return t && (t.firstChild === e ? (t.firstChild = n, n && (n.prev = null)) : r.next = n, t.lastChild === e ? (t.lastChild = r, r && (r.next = null)) : n.prev = r, e.parent = e.next = e.prev = null), e
        }, append: function (e) {
            var t = this, n;
            return e.parent && e.remove(), n = t.lastChild, n ? (n.next = e, e.prev = n, t.lastChild = e) : t.lastChild = t.firstChild = e, e.parent = t, e
        }, insert: function (e, t, n) {
            var r;
            return e.parent && e.remove(), r = t.parent || this, n ? (t === r.firstChild ? r.firstChild = e : t.prev.next = e, e.prev = t.prev, e.next = t, t.prev = e) : (t === r.lastChild ? r.lastChild = e : t.next.prev = e, e.next = t.next, e.prev = t, t.next = e), e.parent = r, e
        }, getAll: function (t) {
            var n = this, r, i = [];
            for (r = n.firstChild; r; r = e(r, n))r.name === t && i.push(r);
            return i
        }, empty: function () {
            var t = this, n, r, i;
            if (t.firstChild) {
                for (n = [], i = t.firstChild; i; i = e(i, t))n.push(i);
                for (r = n.length; r--;)i = n[r], i.parent = i.firstChild = i.lastChild = i.next = i.prev = null
            }
            return t.firstChild = t.lastChild = null, t
        }, isEmpty: function (t) {
            var r = this, i = r.firstChild, o, a;
            if (i)do {
                if (1 === i.type) {
                    if (i.attributes.map["data-mce-bogus"])continue;
                    if (t[i.name])return!1;
                    for (o = i.attributes.length; o--;)if (a = i.attributes[o].name, "name" === a || 0 === a.indexOf("data-mce-"))return!1
                }
                if (8 === i.type)return!1;
                if (3 === i.type && !n.test(i.value))return!1
            } while (i = e(i, r));
            return!0
        }, walk: function (t) {
            return e(this, null, t)
        }}, t.create = function (e, n) {
            var i, o;
            if (i = new t(e, r[e] || 1), n)for (o in n)i.attr(o, n[o]);
            return i
        }, t
    }), r(C, [f], function (e) {
        function t(e, t) {
            return e ? e.split(t || " ") : []
        }

        function n(e) {
            function n(e, n, r) {
                function i(e) {
                    var t = {}, n, r;
                    for (n = 0, r = e.length; r > n; n++)t[e[n]] = {};
                    return t
                }

                var o, l, c, d = arguments;
                for (r = r || [], n = n || "", "string" == typeof r && (r = t(r)), l = 3; l < d.length; l++)"string" == typeof d[l] && (d[l] = t(d[l])), r.push.apply(r, d[l]);
                for (e = t(e), o = e.length; o--;)c = [].concat(s, t(n)), a[e[o]] = {attributes: i(c), attributesOrder: c, children: i(r)}
            }

            function i(e, n) {
                var r, i, o, s;
                for (e = t(e), r = e.length, n = t(n); r--;)for (i = a[e[r]], o = 0, s = n.length; s > o; o++)i.attributes[n[o]] = {}, i.attributesOrder.push(n[o])
            }

            var a = {}, s, l, c, d, u, f, p;
            return r[e] ? r[e] : (s = t("id accesskey class dir lang style tabindex title"), l = t("onabort onblur oncancel oncanplay oncanplaythrough onchange onclick onclose oncontextmenu oncuechange ondblclick ondrag ondragend ondragenter ondragleave ondragover ondragstart ondrop ondurationchange onemptied onended onerror onfocus oninput oninvalid onkeydown onkeypress onkeyup onload onloadeddata onloadedmetadata onloadstart onmousedown onmousemove onmouseout onmouseover onmouseup onmousewheel onpause onplay onplaying onprogress onratechange onreset onscroll onseeked onseeking onseeking onselect onshow onstalled onsubmit onsuspend ontimeupdate onvolumechange onwaiting"), c = t("address blockquote div dl fieldset form h1 h2 h3 h4 h5 h6 hr menu ol p pre table ul"), d = t("a abbr b bdo br button cite code del dfn em embed i iframe img input ins kbd label map noscript object q s samp script select small span strong sub sup textarea u var #text #comment"), "html4" != e && (s.push.apply(s, t("contenteditable contextmenu draggable dropzone hidden spellcheck translate")), c.push.apply(c, t("article aside details dialog figure header footer hgroup section nav")), d.push.apply(d, t("audio canvas command datalist mark meter output progress time wbr video ruby bdi keygen"))), "html5-strict" != e && (s.push("xml:lang"), p = t("acronym applet basefont big font strike tt"), d.push.apply(d, p), o(p, function (e) {
                n(e, "", d)
            }), f = t("center dir isindex noframes"), c.push.apply(c, f), u = [].concat(c, d), o(f, function (e) {
                n(e, "", u)
            })), u = u || [].concat(c, d), n("html", "manifest", "head body"), n("head", "", "base command link meta noscript script style title"), n("title hr noscript br"), n("base", "href target"), n("link", "href rel media hreflang type sizes hreflang"), n("meta", "name http-equiv content charset"), n("style", "media type scoped"), n("script", "src async defer type charset"), n("body", "onafterprint onbeforeprint onbeforeunload onblur onerror onfocus onhashchange onload onmessage onoffline ononline onpagehide onpageshow onpopstate onresize onscroll onstorage onunload", u), n("address dt dd div caption", "", u), n("h1 h2 h3 h4 h5 h6 pre p abbr code var samp kbd sub sup i b u bdo span legend em strong small s cite dfn", "", d), n("blockquote", "cite", u), n("ol", "reversed start type", "li"), n("ul", "", "li"), n("li", "value", u), n("dl", "", "dt dd"), n("a", "href target rel media hreflang type", d), n("q", "cite", d), n("ins del", "cite datetime", u), n("img", "src alt usemap ismap width height"), n("iframe", "src name width height", u), n("embed", "src type width height"), n("object", "data type typemustmatch name usemap form width height", u, "param"), n("param", "name value"), n("map", "name", u, "area"), n("area", "alt coords shape href target rel media hreflang type"), n("table", "border", "caption colgroup thead tfoot tbody tr" + ("html4" == e ? " col" : "")), n("colgroup", "span", "col"), n("col", "span"), n("tbody thead tfoot", "", "tr"), n("tr", "", "td th"), n("td", "colspan rowspan headers", u), n("th", "colspan rowspan headers scope abbr", u), n("form", "accept-charset action autocomplete enctype method name novalidate target", u), n("fieldset", "disabled form name", u, "legend"), n("label", "form for", d), n("input", "accept alt autocomplete checked dirname disabled form formaction formenctype formmethod formnovalidate formtarget height list max maxlength min multiple name pattern readonly required size src step type value width"), n("button", "disabled form formaction formenctype formmethod formnovalidate formtarget name type value", "html4" == e ? u : d), n("select", "disabled form multiple name required size", "option optgroup"), n("optgroup", "disabled label", "option"), n("option", "disabled label selected value"), n("textarea", "cols dirname disabled form maxlength name readonly required rows wrap"), n("menu", "type label", u, "li"), n("noscript", "", u), "html4" != e && (n("wbr"), n("ruby", "", d, "rt rp"), n("figcaption", "", u), n("mark rt rp summary bdi", "", d), n("canvas", "width height", u), n("video", "src crossorigin poster preload autoplay mediagroup loop muted controls width height", u, "track source"), n("audio", "src crossorigin preload autoplay mediagroup loop muted controls", u, "track source"), n("source", "src type media"), n("track", "kind src srclang label default"), n("datalist", "", d, "option"), n("article section nav aside header footer", "", u), n("hgroup", "", "h1 h2 h3 h4 h5 h6"), n("figure", "", u, "figcaption"), n("time", "datetime", d), n("dialog", "open", u), n("command", "type label icon disabled checked radiogroup command"), n("output", "for form name", d), n("progress", "value max", d), n("meter", "value min max low high optimum", d), n("details", "open", u, "summary"), n("keygen", "autofocus challenge disabled form keytype name")), "html5-strict" != e && (i("script", "language xml:space"), i("style", "xml:space"), i("object", "declare classid codebase codetype archive standby align border hspace vspace"), i("param", "valuetype type"), i("a", "charset name rev shape coords"), i("br", "clear"), i("applet", "codebase archive code object alt name width height align hspace vspace"), i("img", "name longdesc align border hspace vspace"), i("iframe", "longdesc frameborder marginwidth marginheight scrolling align"), i("font basefont", "size color face"), i("input", "usemap align"), i("select", "onchange"), i("textarea"), i("h1 h2 h3 h4 h5 h6 div p legend caption", "align"), i("ul", "type compact"), i("li", "type"), i("ol dl menu dir", "compact"), i("pre", "width xml:space"), i("hr", "align noshade size width"), i("isindex", "prompt"), i("table", "summary width frame rules cellspacing cellpadding align bgcolor"), i("col", "width align char charoff valign"), i("colgroup", "width align char charoff valign"), i("thead", "align char charoff valign"), i("tr", "align char charoff valign bgcolor"), i("th", "axis align char charoff valign nowrap bgcolor width height"), i("form", "accept"), i("td", "abbr axis scope align char charoff valign nowrap bgcolor width height"), i("tfoot", "align char charoff valign"), i("tbody", "align char charoff valign"), i("area", "nohref"), i("body", "background bgcolor text link vlink alink")), "html4" != e && (i("input button select textarea", "autofocus"), i("input textarea", "placeholder"), i("a", "download"), i("link script img", "crossorigin"), i("iframe", "srcdoc sandbox seamless allowfullscreen")), o(t("a form meter progress dfn"), function (e) {
                a[e] && delete a[e].children[e]
            }), delete a.caption.children.table, r[e] = a, a)
        }

        var r = {}, i = e.makeMap, o = e.each, a = e.extend, s = e.explode, l = e.inArray;
        return function (e) {
            function c(t, n, o) {
                var s = e[t];
                return s ? s = i(s, ",", i(s.toUpperCase(), " ")) : (s = r[t], s || (s = i(n, " ", i(n.toUpperCase(), " ")), s = a(s, o), r[t] = s)), s
            }

            function d(e) {
                return new RegExp("^" + e.replace(/([?+*])/g, ".$1") + "$")
            }

            function u(e) {
                var n, r, o, a, s, c, u, f, p, m, h, g, y, C, x, w, _, N, E, k = /^([#+\-])?([^\[!\/]+)(?:\/([^\[!]+))?(?:(!?)\[([^\]]+)\])?$/, S = /^([!\-])?(\w+::\w+|[^=:<]+)?(?:([=:<])(.*))?$/, T = /[*?+]/;
                if (e)for (e = t(e, ","), v["@"] && (w = v["@"].attributes, _ = v["@"].attributesOrder), n = 0, r = e.length; r > n; n++)if (s = k.exec(e[n])) {
                    if (C = s[1], p = s[2], x = s[3], f = s[5], g = {}, y = [], c = {attributes: g, attributesOrder: y}, "#" === C && (c.paddEmpty = !0), "-" === C && (c.removeEmpty = !0), "!" === s[4] && (c.removeEmptyAttrs = !0), w) {
                        for (N in w)g[N] = w[N];
                        y.push.apply(y, _)
                    }
                    if (f)for (f = t(f, "|"), o = 0, a = f.length; a > o; o++)if (s = S.exec(f[o])) {
                        if (u = {}, h = s[1], m = s[2].replace(/::/g, ":"), C = s[3], E = s[4], "!" === h && (c.attributesRequired = c.attributesRequired || [], c.attributesRequired.push(m), u.required = !0), "-" === h) {
                            delete g[m], y.splice(l(y, m), 1);
                            continue
                        }
                        C && ("=" === C && (c.attributesDefault = c.attributesDefault || [], c.attributesDefault.push({name: m, value: E}), u.defaultValue = E), ":" === C && (c.attributesForced = c.attributesForced || [], c.attributesForced.push({name: m, value: E}), u.forcedValue = E), "<" === C && (u.validValues = i(E, "?"))), T.test(m) ? (c.attributePatterns = c.attributePatterns || [], u.pattern = d(m), c.attributePatterns.push(u)) : (g[m] || y.push(m), g[m] = u)
                    }
                    w || "@" != p || (w = g, _ = y), x && (c.outputName = p, v[x] = c), T.test(p) ? (c.pattern = d(p), b.push(c)) : v[p] = c
                }
            }

            function f(e) {
                v = {}, b = [], u(e), o(x, function (e, t) {
                    y[t] = e.children
                })
            }

            function p(e) {
                var n = /^(~)?(.+)$/;
                e && o(t(e, ","), function (e) {
                    var t = n.exec(e), r = "~" === t[1], i = r ? "span" : "div", s = t[2];
                    if (y[s] = y[i], R[s] = i, r || (k[s.toUpperCase()] = {}, k[s] = {}), !v[s]) {
                        var l = v[i];
                        l = a({}, l), delete l.removeEmptyAttrs, delete l.removeEmpty, v[s] = l
                    }
                    o(y, function (e) {
                        e[i] && (e[s] = e[i])
                    })
                })
            }

            function m(e) {
                var n = /^([+\-]?)(\w+)\[([^\]]+)\]$/;
                e && o(t(e, ","), function (e) {
                    var r = n.exec(e), i, a;
                    r && (a = r[1], i = a ? y[r[2]] : y[r[2]] = {"#comment": {}}, i = y[r[2]], o(t(r[3], "|"), function (e) {
                        "-" === a ? delete i[e] : i[e] = {}
                    }))
                })
            }

            function h(e) {
                var t = v[e], n;
                if (t)return t;
                for (n = b.length; n--;)if (t = b[n], t.pattern.test(e))return t
            }

            var g = this, v = {}, y = {}, b = [], C, x, w, _, N, E, k, S, T, R = {}, A = {};
            e = e || {}, x = n(e.schema), e.verify_html === !1 && (e.valid_elements = "*[*]"), e.valid_styles && (C = {}, o(e.valid_styles, function (e, t) {
                C[t] = s(e)
            })), w = c("whitespace_elements", "pre script noscript style textarea video audio iframe object"), _ = c("self_closing_elements", "colgroup dd dt li option p td tfoot th thead tr"), N = c("short_ended_elements", "area base basefont br col frame hr img input isindex link meta param embed source wbr track"), E = c("boolean_attributes", "checked compact declare defer disabled ismap multiple nohref noresize noshade nowrap readonly selected autoplay loop controls"), S = c("non_empty_elements", "td th iframe video audio object script", N), T = c("text_block_elements", "h1 h2 h3 h4 h5 h6 p div address pre form blockquote center dir fieldset header footer article section hgroup aside nav figure"), k = c("block_elements", "hr table tbody thead tfoot th tr td li ol ul caption dl dt dd noscript menu isindex samp option datalist select optgroup", T), o((e.special || "script noscript style textarea").split(" "), function (e) {
                A[e] = new RegExp("</" + e + "[^>]*>", "gi")
            }), e.valid_elements ? f(e.valid_elements) : (o(x, function (e, t) {
                v[t] = {attributes: e.attributes, attributesOrder: e.attributesOrder}, y[t] = e.children
            }), "html5" != e.schema && o(t("strong/b em/i"), function (e) {
                e = t(e, "/"), v[e[1]].outputName = e[0]
            }), v.img.attributesDefault = [
                {name: "alt", value: ""}
            ], o(t("ol ul sub sup blockquote span font a table tbody tr strong em b i"), function (e) {
                v[e] && (v[e].removeEmpty = !0)
            }), o(t("p h1 h2 h3 h4 h5 h6 th td pre div address caption"), function (e) {
                v[e].paddEmpty = !0
            }), o(t("span"), function (e) {
                v[e].removeEmptyAttrs = !0
            })), p(e.custom_elements), m(e.valid_children), u(e.extended_valid_elements), m("+ol[ul|ol],+ul[ul|ol]"), e.invalid_elements && o(s(e.invalid_elements), function (e) {
                v[e] && delete v[e]
            }), h("span") || u("span[!data-mce-type|*]"), g.children = y, g.styles = C, g.getBoolAttrs = function () {
                return E
            }, g.getBlockElements = function () {
                return k
            }, g.getTextBlockElements = function () {
                return T
            }, g.getShortEndedElements = function () {
                return N
            }, g.getSelfClosingElements = function () {
                return _
            }, g.getNonEmptyElements = function () {
                return S
            }, g.getWhiteSpaceElements = function () {
                return w
            }, g.getSpecialElements = function () {
                return A
            }, g.isValidChild = function (e, t) {
                var n = y[e];
                return!(!n || !n[t])
            }, g.isValid = function (e, t) {
                var n, r, i = h(e);
                if (i) {
                    if (!t)return!0;
                    if (i.attributes[t])return!0;
                    if (n = i.attributePatterns)for (r = n.length; r--;)if (n[r].pattern.test(e))return!0
                }
                return!1
            }, g.getElementRule = h, g.getCustomElements = function () {
                return R
            }, g.addValidElements = u, g.setValidElements = f, g.addCustomElements = p, g.addValidChildren = m, g.elements = v
        }
    }), r(x, [C, m, f], function (e, t, n) {
        var r = n.each;
        return function (i, o) {
            var a = this, s = function () {
            };
            i = i || {}, a.schema = o = o || new e, i.fix_self_closing !== !1 && (i.fix_self_closing = !0), r("comment cdata text start end pi doctype".split(" "), function (e) {
                e && (a[e] = i[e] || s)
            }), a.parse = function (e) {
                function r(e) {
                    var t, n;
                    for (t = f.length; t-- && f[t].name !== e;);
                    if (t >= 0) {
                        for (n = f.length - 1; n >= t; n--)e = f[n], e.valid && s.end(e.name);
                        f.length = t
                    }
                }

                function a(e, t, n, r, o) {
                    var a, s, l = /[\s\u0000-\u001F]+/g;
                    if (t = t.toLowerCase(), n = t in C ? t : F(n || r || o || ""), w && !v && 0 !== t.indexOf("data-")) {
                        if (a = S[t], !a && T) {
                            for (s = T.length; s-- && (a = T[s], !a.pattern.test(t)););
                            -1 === s && (a = null)
                        }
                        if (!a)return;
                        if (a.validValues && !(n in a.validValues))return
                    }
                    if (W[t] && !i.allow_script_urls) {
                        var c = n.replace(l, "");
                        try {
                            if (c = decodeURIComponent(c), V.test(c))return
                        } catch (d) {
                            if (c = unescape(c), V.test(c))return
                        }
                    }
                    p.map[t] = n, p.push({name: t, value: n})
                }

                var s = this, l, c = 0, d, u, f = [], p, m, h, g, v, y, b, C, x, w, _, N, E, k, S, T, R, A, B, L, H, D, M, P, O, I = 0, F = t.decode, z, W = n.makeMap("src,href"), V = /(java|vb)script:/i;
                for (D = new RegExp("<(?:(?:!--([\\w\\W]*?)-->)|(?:!\\[CDATA\\[([\\w\\W]*?)\\]\\]>)|(?:!DOCTYPE([\\w\\W]*?)>)|(?:\\?([^\\s\\/<>]+) ?([\\w\\W]*?)[?/]>)|(?:\\/([^>]+)>)|(?:([A-Za-z0-9\\-\\:\\.]+)((?:\\s+[^\"'>]+(?:(?:\"[^\"]*\")|(?:'[^']*')|[^>]*))*|\\/|\\s+)>))", "g"), M = /([\w:\-]+)(?:\s*=\s*(?:(?:\"((?:[^\"])*)\")|(?:\'((?:[^\'])*)\')|([^>\s]+)))?/g, b = o.getShortEndedElements(), H = i.self_closing_elements || o.getSelfClosingElements(), C = o.getBoolAttrs(), w = i.validate, y = i.remove_internals, z = i.fix_self_closing, P = o.getSpecialElements(); l = D.exec(e);) {
                    if (c < l.index && s.text(F(e.substr(c, l.index - c))), d = l[6])d = d.toLowerCase(), ":" === d.charAt(0) && (d = d.substr(1)), r(d); else if (d = l[7]) {
                        if (d = d.toLowerCase(), ":" === d.charAt(0) && (d = d.substr(1)), x = d in b, z && H[d] && f.length > 0 && f[f.length - 1].name === d && r(d), !w || (_ = o.getElementRule(d))) {
                            if (N = !0, w && (S = _.attributes, T = _.attributePatterns), (k = l[8]) ? (v = -1 !== k.indexOf("data-mce-type"), v && y && (N = !1), p = [], p.map = {}, k.replace(M, a)) : (p = [], p.map = {}), w && !v) {
                                if (R = _.attributesRequired, A = _.attributesDefault, B = _.attributesForced, L = _.removeEmptyAttrs, L && !p.length && (N = !1), B)for (m = B.length; m--;)E = B[m], g = E.name, O = E.value, "{$uid}" === O && (O = "mce_" + I++), p.map[g] = O, p.push({name: g, value: O});
                                if (A)for (m = A.length; m--;)E = A[m], g = E.name, g in p.map || (O = E.value, "{$uid}" === O && (O = "mce_" + I++), p.map[g] = O, p.push({name: g, value: O}));
                                if (R) {
                                    for (m = R.length; m-- && !(R[m]in p.map););
                                    -1 === m && (N = !1)
                                }
                                p.map["data-mce-bogus"] && (N = !1)
                            }
                            N && s.start(d, p, x)
                        } else N = !1;
                        if (u = P[d]) {
                            u.lastIndex = c = l.index + l[0].length, (l = u.exec(e)) ? (N && (h = e.substr(c, l.index - c)), c = l.index + l[0].length) : (h = e.substr(c), c = e.length), N && (h.length > 0 && s.text(h, !0), s.end(d)), D.lastIndex = c;
                            continue
                        }
                        x || (k && k.indexOf("/") == k.length - 1 ? N && s.end(d) : f.push({name: d, valid: N}))
                    } else(d = l[1]) ? (">" === d.charAt(0) && (d = " " + d), i.allow_conditional_comments || "[if" !== d.substr(0, 3) || (d = " " + d), s.comment(d)) : (d = l[2]) ? s.cdata(d) : (d = l[3]) ? s.doctype(d) : (d = l[4]) && s.pi(d, l[5]);
                    c = l.index + l[0].length
                }
                for (c < e.length && s.text(F(e.substr(c))), m = f.length - 1; m >= 0; m--)d = f[m], d.valid && s.end(d.name)
            }
        }
    }), r(w, [b, C, x, f], function (e, t, n, r) {
        var i = r.makeMap, o = r.each, a = r.explode, s = r.extend;
        return function (r, l) {
            function c(t) {
                var n, r, o, a, s, c, u, f, p, m, h, g, v, y;
                for (h = i("tr,td,th,tbody,thead,tfoot,table"), m = l.getNonEmptyElements(), g = l.getTextBlockElements(), n = 0; n < t.length; n++)if (r = t[n], r.parent && !r.fixed)if (g[r.name] && "li" == r.parent.name) {
                    for (v = r.next; v && g[v.name];)v.name = "li", v.fixed = !0, r.parent.insert(v, r.parent), v = v.next;
                    r.unwrap(r)
                } else {
                    for (a = [r], o = r.parent; o && !l.isValidChild(o.name, r.name) && !h[o.name]; o = o.parent)a.push(o);
                    if (o && a.length > 1) {
                        for (a.reverse(), s = c = d.filterNode(a[0].clone()), p = 0; p < a.length - 1; p++) {
                            for (l.isValidChild(c.name, a[p].name) ? (u = d.filterNode(a[p].clone()), c.append(u)) : u = c, f = a[p].firstChild; f && f != a[p + 1];)y = f.next, u.append(f), f = y;
                            c = u
                        }
                        s.isEmpty(m) ? o.insert(r, a[0], !0) : (o.insert(s, a[0], !0), o.insert(r, s)), o = a[0], (o.isEmpty(m) || o.firstChild === o.lastChild && "br" === o.firstChild.name) && o.empty().remove()
                    } else if (r.parent) {
                        if ("li" === r.name) {
                            if (v = r.prev, v && ("ul" === v.name || "ul" === v.name)) {
                                v.append(r);
                                continue
                            }
                            if (v = r.next, v && ("ul" === v.name || "ul" === v.name)) {
                                v.insert(r, v.firstChild, !0);
                                continue
                            }
                            r.wrap(d.filterNode(new e("ul", 1)));
                            continue
                        }
                        l.isValidChild(r.parent.name, "div") && l.isValidChild("div", r.name) ? r.wrap(d.filterNode(new e("div", 1))) : "style" === r.name || "script" === r.name ? r.empty().remove() : r.unwrap()
                    }
                }
            }

            var d = this, u = {}, f = [], p = {}, m = {};
            r = r || {}, r.validate = "validate"in r ? r.validate : !0, r.root_name = r.root_name || "body", d.schema = l = l || new t, d.filterNode = function (e) {
                var t, n, r;
                n in u && (r = p[n], r ? r.push(e) : p[n] = [e]), t = f.length;
                for (; t--;)n = f[t].name, n in e.attributes.map && (r = m[n], r ? r.push(e) : m[n] = [e]);
                return e
            }, d.addNodeFilter = function (e, t) {
                o(a(e), function (e) {
                    var n = u[e];
                    n || (u[e] = n = []), n.push(t)
                })
            }, d.addAttributeFilter = function (e, t) {
                o(a(e), function (e) {
                    var n;
                    for (n = 0; n < f.length; n++)if (f[n].name === e)return f[n].callbacks.push(t), void 0;
                    f.push({name: e, callbacks: [t]})
                })
            }, d.parse = function (t, o) {
                function a() {
                    function e(e) {
                        e && (t = e.firstChild, t && 3 == t.type && (t.value = t.value.replace(R, "")), t = e.lastChild, t && 3 == t.type && (t.value = t.value.replace(L, "")))
                    }

                    var t = y.firstChild, n, i;
                    if (l.isValidChild(y.name, I.toLowerCase())) {
                        for (; t;)n = t.next, 3 == t.type || 1 == t.type && "p" !== t.name && !T[t.name] && !t.attr("data-mce-type") ? i ? i.append(t) : (i = d(I, 1), i.attr(r.forced_root_block_attrs), y.insert(i, t), i.append(t)) : (e(i), i = null), t = n;
                        e(i)
                    }
                }

                function d(t, n) {
                    var r = new e(t, n), i;
                    return t in u && (i = p[t], i ? i.push(r) : p[t] = [r]), r
                }

                function h(e) {
                    var t, n, r;
                    for (t = e.prev; t && 3 === t.type;)n = t.value.replace(L, ""), n.length > 0 ? (t.value = n, t = t.prev) : (r = t.prev, t.remove(), t = r)
                }

                function g(e) {
                    var t, n = {};
                    for (t in e)"li" !== t && "p" != t && (n[t] = e[t]);
                    return n
                }

                var v, y, b, C, x, w, _, N, E, k, S, T, R, A = [], B, L, H, D, M, P, O, I;
                if (o = o || {}, p = {}, m = {}, T = s(i("script,style,head,html,body,title,meta,param"), l.getBlockElements()), O = l.getNonEmptyElements(), P = l.children, S = r.validate, I = "forced_root_block"in o ? o.forced_root_block : r.forced_root_block, M = l.getWhiteSpaceElements(), R = /^[ \t\r\n]+/, L = /[ \t\r\n]+$/, H = /[ \t\r\n]+/g, D = /^[ \t\r\n]+$/, v = new n({validate: S, allow_script_urls: r.allow_script_urls, allow_conditional_comments: r.allow_conditional_comments, self_closing_elements: g(l.getSelfClosingElements()), cdata: function (e) {
                    b.append(d("#cdata", 4)).value = e
                }, text: function (e, t) {
                    var n;
                    B || (e = e.replace(H, " "), b.lastChild && T[b.lastChild.name] && (e = e.replace(R, ""))), 0 !== e.length && (n = d("#text", 3), n.raw = !!t, b.append(n).value = e)
                }, comment: function (e) {
                    b.append(d("#comment", 8)).value = e
                }, pi: function (e, t) {
                    b.append(d(e, 7)).value = t, h(b)
                }, doctype: function (e) {
                    var t;
                    t = b.append(d("#doctype", 10)), t.value = e, h(b)
                }, start: function (e, t, n) {
                    var r, i, o, a, s;
                    if (o = S ? l.getElementRule(e) : {}) {
                        for (r = d(o.outputName || e, 1), r.attributes = t, r.shortEnded = n, b.append(r), s = P[b.name], s && P[r.name] && !s[r.name] && A.push(r), i = f.length; i--;)a = f[i].name, a in t.map && (E = m[a], E ? E.push(r) : m[a] = [r]);
                        T[e] && h(r), n || (b = r), !B && M[e] && (B = !0)
                    }
                }, end: function (t) {
                    var n, r, i, o, a;
                    if (r = S ? l.getElementRule(t) : {}) {
                        if (T[t] && !B) {
                            if (n = b.firstChild, n && 3 === n.type)if (i = n.value.replace(R, ""), i.length > 0)n.value = i, n = n.next; else for (o = n.next, n.remove(), n = o; n && 3 === n.type;)i = n.value, o = n.next, (0 === i.length || D.test(i)) && (n.remove(), n = o), n = o;
                            if (n = b.lastChild, n && 3 === n.type)if (i = n.value.replace(L, ""), i.length > 0)n.value = i, n = n.prev; else for (o = n.prev, n.remove(), n = o; n && 3 === n.type;)i = n.value, o = n.prev, (0 === i.length || D.test(i)) && (n.remove(), n = o), n = o
                        }
                        if (B && M[t] && (B = !1), (r.removeEmpty || r.paddEmpty) && b.isEmpty(O))if (r.paddEmpty)b.empty().append(new e("#text", "3")).value = "\xa0"; else if (!b.attributes.map.name && !b.attributes.map.id)return a = b.parent, b.empty().remove(), b = a, void 0;
                        b = b.parent
                    }
                }}, l), y = b = new e(o.context || r.root_name, 11), v.parse(t), S && A.length && (o.context ? o.invalid = !0 : c(A)), I && ("body" == y.name || o.isRootContent) && a(), !o.invalid) {
                    for (k in p) {
                        for (E = u[k], C = p[k], _ = C.length; _--;)C[_].parent || C.splice(_, 1);
                        for (x = 0, w = E.length; w > x; x++)E[x](C, k, o)
                    }
                    for (x = 0, w = f.length; w > x; x++)if (E = f[x], E.name in m) {
                        for (C = m[E.name], _ = C.length; _--;)C[_].parent || C.splice(_, 1);
                        for (_ = 0, N = E.callbacks.length; N > _; _++)E.callbacks[_](C, E.name, o)
                    }
                }
                return y
            }, r.remove_trailing_brs && d.addNodeFilter("br", function (t) {
                var n, r = t.length, i, o = s({}, l.getBlockElements()), a = l.getNonEmptyElements(), c, d, u, f, p, m;
                for (o.body = 1, n = 0; r > n; n++)if (i = t[n], c = i.parent, o[i.parent.name] && i === c.lastChild) {
                    for (u = i.prev; u;) {
                        if (f = u.name, "span" !== f || "bookmark" !== u.attr("data-mce-type")) {
                            if ("br" !== f)break;
                            if ("br" === f) {
                                i = null;
                                break
                            }
                        }
                        u = u.prev
                    }
                    i && (i.remove(), c.isEmpty(a) && (p = l.getElementRule(c.name), p && (p.removeEmpty ? c.remove() : p.paddEmpty && (c.empty().append(new e("#text", 3)).value = "\xa0"))))
                } else {
                    for (d = i; c && c.firstChild === d && c.lastChild === d && (d = c, !o[c.name]);)c = c.parent;
                    d === c && (m = new e("#text", 3), m.value = "\xa0", i.replace(m))
                }
            }), r.allow_html_in_named_anchor || d.addAttributeFilter("id,name", function (e) {
                for (var t = e.length, n, r, i, o; t--;)if (o = e[t], "a" === o.name && o.firstChild && !o.attr("href")) {
                    i = o.parent, n = o.lastChild;
                    do r = n.prev, i.insert(n, o), n = r; while (n)
                }
            })
        }
    }), r(_, [m, f], function (e, t) {
        var n = t.makeMap;
        return function (t) {
            var r = [], i, o, a, s, l;
            return t = t || {}, i = t.indent, o = n(t.indent_before || ""), a = n(t.indent_after || ""), s = e.getEncodeFunc(t.entity_encoding || "raw", t.entities), l = "html" == t.element_format, {start: function (e, t, n) {
                var c, d, u, f;
                if (i && o[e] && r.length > 0 && (f = r[r.length - 1], f.length > 0 && "\n" !== f && r.push("\n")), r.push("<", e), t)for (c = 0, d = t.length; d > c; c++)u = t[c], r.push(" ", u.name, '="', s(u.value, !0), '"');
                r[r.length] = !n || l ? ">" : " />", n && i && a[e] && r.length > 0 && (f = r[r.length - 1], f.length > 0 && "\n" !== f && r.push("\n"))
            }, end: function (e) {
                var t;
                r.push("</", e, ">"), i && a[e] && r.length > 0 && (t = r[r.length - 1], t.length > 0 && "\n" !== t && r.push("\n"))
            }, text: function (e, t) {
                e.length > 0 && (r[r.length] = t ? e : s(e))
            }, cdata: function (e) {
                r.push("<![CDATA[", e, "]]>")
            }, comment: function (e) {
                r.push("<!--", e, "-->")
            }, pi: function (e, t) {
                t ? r.push("<?", e, " ", t, "?>") : r.push("<?", e, "?>"), i && r.push("\n")
            }, doctype: function (e) {
                r.push("<!DOCTYPE", e, ">", i ? "\n" : "")
            }, reset: function () {
                r.length = 0
            }, getContent: function () {
                return r.join("").replace(/\n$/, "")
            }}
        }
    }), r(N, [_, C], function (e, t) {
        return function (n, r) {
            var i = this, o = new e(n);
            n = n || {}, n.validate = "validate"in n ? n.validate : !0, i.schema = r = r || new t, i.writer = o, i.serialize = function (e) {
                function t(e) {
                    var n = i[e.type], s, l, c, d, u, f, p, m, h;
                    if (n)n(e); else {
                        if (s = e.name, l = e.shortEnded, c = e.attributes, a && c && c.length > 1) {
                            for (f = [], f.map = {}, h = r.getElementRule(e.name), p = 0, m = h.attributesOrder.length; m > p; p++)d = h.attributesOrder[p], d in c.map && (u = c.map[d], f.map[d] = u, f.push({name: d, value: u}));
                            for (p = 0, m = c.length; m > p; p++)d = c[p].name, d in f.map || (u = c.map[d], f.map[d] = u, f.push({name: d, value: u}));
                            c = f
                        }
                        if (o.start(e.name, c, l), !l) {
                            if (e = e.firstChild)do t(e); while (e = e.next);
                            o.end(s)
                        }
                    }
                }

                var i, a;
                return a = n.validate, i = {3: function (e) {
                    o.text(e.value, e.raw)
                }, 8: function (e) {
                    o.comment(e.value)
                }, 7: function (e) {
                    o.pi(e.name, e.value)
                }, 10: function (e) {
                    o.doctype(e.value)
                }, 4: function (e) {
                    o.cdata(e.value)
                }, 11: function (e) {
                    if (e = e.firstChild)do t(e); while (e = e.next)
                }}, o.reset(), 1 != e.type || n.inner ? i[11](e) : t(e), o.getContent()
            }
        }
    }), r(E, [g, w, m, N, b, C, h, f], function (e, t, n, r, i, o, a, s) {
        var l = s.each, c = s.trim, d = e.DOM;
        return function (e, i) {
            var s, u, f;
            return i && (s = i.dom, u = i.schema), s = s || d, u = u || new o(e), e.entity_encoding = e.entity_encoding || "named", e.remove_trailing_brs = "remove_trailing_brs"in e ? e.remove_trailing_brs : !0, f = new t(e, u), f.addAttributeFilter("src,href,style", function (t, n) {
                for (var r = t.length, i, o, a = "data-mce-" + n, l = e.url_converter, c = e.url_converter_scope, d; r--;)i = t[r], o = i.attributes.map[a], o !== d ? (i.attr(n, o.length > 0 ? o : null), i.attr(a, null)) : (o = i.attributes.map[n], "style" === n ? o = s.serializeStyle(s.parseStyle(o), i.name) : l && (o = l.call(c, o, n, i.name)), i.attr(n, o.length > 0 ? o : null))
            }), f.addAttributeFilter("class", function (e) {
                for (var t = e.length, n, r; t--;)n = e[t], r = n.attr("class").replace(/(?:^|\s)mce-item-\w+(?!\S)/g, ""), n.attr("class", r.length > 0 ? r : null)
            }), f.addAttributeFilter("data-mce-type", function (e, t, n) {
                for (var r = e.length, i; r--;)i = e[r], "bookmark" !== i.attributes.map["data-mce-type"] || n.cleanup || i.remove()
            }), f.addAttributeFilter("data-mce-expando", function (e, t) {
                for (var n = e.length; n--;)e[n].attr(t, null)
            }), f.addNodeFilter("noscript", function (e) {
                for (var t = e.length, r; t--;)r = e[t].firstChild, r && (r.value = n.decode(r.value))
            }), f.addNodeFilter("script,style", function (e, t) {
                function n(e) {
                    return e.replace(/(<!--\[CDATA\[|\]\]-->)/g, "\n").replace(/^[\r\n]*|[\r\n]*$/g, "").replace(/^\s*((<!--)?(\s*\/\/)?\s*<!\[CDATA\[|(<!--\s*)?\/\*\s*<!\[CDATA\[\s*\*\/|(\/\/)?\s*<!--|\/\*\s*<!--\s*\*\/)\s*[\r\n]*/gi, "").replace(/\s*(\/\*\s*\]\]>\s*\*\/(-->)?|\s*\/\/\s*\]\]>(-->)?|\/\/\s*(-->)?|\]\]>|\/\*\s*-->\s*\*\/|\s*-->\s*)\s*$/g, "")
                }

                for (var r = e.length, i, o; r--;)if (i = e[r], o = i.firstChild ? i.firstChild.value : "", "script" === t) {
                    var a = (i.attr("type") || "text/javascript").replace(/^mce\-/, "");
                    i.attr("type", "text/javascript" === a ? null : a), o.length > 0 && (i.firstChild.value = "// <![CDATA[\n" + n(o) + "\n// ]]>")
                } else o.length > 0 && (i.firstChild.value = "<!--\n" + n(o) + "\n-->")
            }), f.addNodeFilter("#comment", function (e) {
                for (var t = e.length, n; t--;)n = e[t], 0 === n.value.indexOf("[CDATA[") ? (n.name = "#cdata", n.type = 4, n.value = n.value.replace(/^\[CDATA\[|\]\]$/g, "")) : 0 === n.value.indexOf("mce:protected ") && (n.name = "#text", n.type = 3, n.raw = !0, n.value = unescape(n.value).substr(14))
            }), f.addNodeFilter("xml:namespace,input", function (e, t) {
                for (var n = e.length, r; n--;)r = e[n], 7 === r.type ? r.remove() : 1 === r.type && ("input" !== t || "type"in r.attributes.map || r.attr("type", "text"))
            }), e.fix_list_elements && f.addNodeFilter("ul,ol", function (e) {
                for (var t = e.length, n, r; t--;)n = e[t], r = n.parent, ("ul" === r.name || "ol" === r.name) && n.prev && "li" === n.prev.name && n.prev.append(n)
            }), f.addAttributeFilter("data-mce-src,data-mce-href,data-mce-style,data-mce-selected", function (e, t) {
                for (var n = e.length; n--;)e[n].attr(t, null)
            }), {schema: u, addNodeFilter: f.addNodeFilter, addAttributeFilter: f.addAttributeFilter, serialize: function (t, n) {
                var i = this, o, d, p, m, h;
                return a.ie && s.select("script,style,select,map").length > 0 ? (h = t.innerHTML, t = t.cloneNode(!1), s.setHTML(t, h)) : t = t.cloneNode(!0), o = t.ownerDocument.implementation, o.createHTMLDocument && (d = o.createHTMLDocument(""), l("BODY" == t.nodeName ? t.childNodes : [t], function (e) {
                    d.body.appendChild(d.importNode(e, !0))
                }), t = "BODY" != t.nodeName ? d.body.firstChild : d.body, p = s.doc, s.doc = d), n = n || {}, n.format = n.format || "html", n.selection && (n.forced_root_block = ""), n.no_events || (n.node = t, i.onPreProcess(n)), m = new r(e, u), n.content = m.serialize(f.parse(c(n.getInner ? t.innerHTML : s.getOuterHTML(t)), n)), n.cleanup || (n.content = n.content.replace(/\uFEFF/g, "")), n.no_events || i.onPostProcess(n), p && (s.doc = p), n.node = null, n.content
            }, addRules: function (e) {
                u.addValidElements(e)
            }, setRules: function (e) {
                u.setValidElements(e)
            }, onPreProcess: function (e) {
                i && i.fire("PreProcess", e)
            }, onPostProcess: function (e) {
                i && i.fire("PostProcess", e)
            }}
        }
    }), r(k, [], function () {
        function e(e) {
            function t(t, n) {
                var r, i = 0, o, a, s, l, c, d, u = -1, f;
                if (r = t.duplicate(), r.collapse(n), f = r.parentElement(), f.ownerDocument === e.dom.doc) {
                    for (; "false" === f.contentEditable;)f = f.parentNode;
                    if (!f.hasChildNodes())return{node: f, inside: 1};
                    for (s = f.children, o = s.length - 1; o >= i;)if (d = Math.floor((i + o) / 2), l = s[d], r.moveToElementText(l), u = r.compareEndPoints(n ? "StartToStart" : "EndToEnd", t), u > 0)o = d - 1; else {
                        if (!(0 > u))return{node: l};
                        i = d + 1
                    }
                    if (0 > u)for (l ? r.collapse(!1) : (r.moveToElementText(f), r.collapse(!0), l = f, a = !0), c = 0; 0 !== r.compareEndPoints(n ? "StartToStart" : "StartToEnd", t) && 0 !== r.move("character", 1) && f == r.parentElement();)c++; else for (r.collapse(!0), c = 0; 0 !== r.compareEndPoints(n ? "StartToStart" : "StartToEnd", t) && 0 !== r.move("character", -1) && f == r.parentElement();)c++;
                    return{node: l, position: u, offset: c, inside: a}
                }
            }

            function n() {
                function n(e) {
                    var n = t(o, e), r, i, s = 0, l, c, d;
                    if (r = n.node, i = n.offset, n.inside && !r.hasChildNodes())return a[e ? "setStart" : "setEnd"](r, 0), void 0;
                    if (i === c)return a[e ? "setStartBefore" : "setEndAfter"](r), void 0;
                    if (n.position < 0) {
                        if (l = n.inside ? r.firstChild : r.nextSibling, !l)return a[e ? "setStartAfter" : "setEndAfter"](r), void 0;
                        if (!i)return 3 == l.nodeType ? a[e ? "setStart" : "setEnd"](l, 0) : a[e ? "setStartBefore" : "setEndBefore"](l), void 0;
                        for (; l;) {
                            if (d = l.nodeValue, s += d.length, s >= i) {
                                r = l, s -= i, s = d.length - s;
                                break
                            }
                            l = l.nextSibling
                        }
                    } else {
                        if (l = r.previousSibling, !l)return a[e ? "setStartBefore" : "setEndBefore"](r);
                        if (!i)return 3 == r.nodeType ? a[e ? "setStart" : "setEnd"](l, r.nodeValue.length) : a[e ? "setStartAfter" : "setEndAfter"](l), void 0;
                        for (; l;) {
                            if (s += l.nodeValue.length, s >= i) {
                                r = l, s -= i;
                                break
                            }
                            l = l.previousSibling
                        }
                    }
                    a[e ? "setStart" : "setEnd"](r, s)
                }

                var o = e.getRng(), a = i.createRng(), s, l, c, d, u;
                if (s = o.item ? o.item(0) : o.parentElement(), s.ownerDocument != i.doc)return a;
                if (l = e.isCollapsed(), o.item)return a.setStart(s.parentNode, i.nodeIndex(s)), a.setEnd(a.startContainer, a.startOffset + 1), a;
                try {
                    n(!0), l || n()
                } catch (f) {
                    if (-2147024809 != f.number)throw f;
                    u = r.getBookmark(2), c = o.duplicate(), c.collapse(!0), s = c.parentElement(), l || (c = o.duplicate(), c.collapse(!1), d = c.parentElement(), d.innerHTML = d.innerHTML), s.innerHTML = s.innerHTML, r.moveToBookmark(u), o = e.getRng(), n(!0), l || n()
                }
                return a
            }

            var r = this, i = e.dom, o = !1;
            this.getBookmark = function (n) {
                function r(e) {
                    var t, n, r, o, a = [];
                    for (t = e.parentNode, n = i.getRoot().parentNode; t != n && 9 !== t.nodeType;) {
                        for (r = t.children, o = r.length; o--;)if (e === r[o]) {
                            a.push(o);
                            break
                        }
                        e = t, t = t.parentNode
                    }
                    return a
                }

                function o(e) {
                    var n;
                    return n = t(a, e), n ? {position: n.position, offset: n.offset, indexes: r(n.node), inside: n.inside} : void 0
                }

                var a = e.getRng(), s = {};
                return 2 === n && (a.item ? s.start = {ctrl: !0, indexes: r(a.item(0))} : (s.start = o(!0), e.isCollapsed() || (s.end = o()))), s
            }, this.moveToBookmark = function (e) {
                function t(e) {
                    var t, n, r, o;
                    for (t = i.getRoot(), n = e.length - 1; n >= 0; n--)o = t.children, r = e[n], r <= o.length - 1 && (t = o[r]);
                    return t
                }

                function n(n) {
                    var i = e[n ? "start" : "end"], a, s, l, c;
                    i && (a = i.position > 0, s = o.createTextRange(), s.moveToElementText(t(i.indexes)), c = i.offset, c !== l ? (s.collapse(i.inside || a), s.moveStart("character", a ? -c : c)) : s.collapse(n), r.setEndPoint(n ? "StartToStart" : "EndToStart", s), n && r.collapse(!0))
                }

                var r, o = i.doc.body;
                e.start && (e.start.ctrl ? (r = o.createControlRange(), r.addElement(t(e.start.indexes)), r.select()) : (r = o.createTextRange(), n(!0), n(), r.select()))
            }, this.addRange = function (t) {
                function n(e) {
                    var t, n, a, u, m;
                    a = i.create("a"), t = e ? s : c, n = e ? l : d, u = r.duplicate(), (t == f || t == f.documentElement) && (t = p, n = 0), 3 == t.nodeType ? (t.parentNode.insertBefore(a, t), u.moveToElementText(a), u.moveStart("character", n), i.remove(a), r.setEndPoint(e ? "StartToStart" : "EndToEnd", u)) : (m = t.childNodes, m.length ? (n >= m.length ? i.insertAfter(a, m[m.length - 1]) : t.insertBefore(a, m[n]), u.moveToElementText(a)) : t.canHaveHTML && (t.innerHTML = "<span>&#xFEFF;</span>", a = t.firstChild, u.moveToElementText(a), u.collapse(o)), r.setEndPoint(e ? "StartToStart" : "EndToEnd", u), i.remove(a))
                }

                var r, a, s, l, c, d, u, f = e.dom.doc, p = f.body, m, h;
                if (s = t.startContainer, l = t.startOffset, c = t.endContainer, d = t.endOffset, r = p.createTextRange(), s == c && 1 == s.nodeType) {
                    if (l == d && !s.hasChildNodes()) {
                        if (s.canHaveHTML)return u = s.previousSibling, u && !u.hasChildNodes() && i.isBlock(u) ? u.innerHTML = "&#xFEFF;" : u = null, s.innerHTML = "<span>&#xFEFF;</span><span>&#xFEFF;</span>", r.moveToElementText(s.lastChild), r.select(), i.doc.selection.clear(), s.innerHTML = "", u && (u.innerHTML = ""), void 0;
                        l = i.nodeIndex(s), s = s.parentNode
                    }
                    if (l == d - 1)try {
                        if (h = s.childNodes[l], a = p.createControlRange(), a.addElement(h), a.select(), m = e.getRng(), m.item && h === m.item(0))return
                    } catch (g) {
                    }
                }
                n(!0), n(), r.select()
            }, this.getRangeAt = n
        }

        return e
    }), r(S, [h], function (e) {
        return{BACKSPACE: 8, DELETE: 46, DOWN: 40, ENTER: 13, LEFT: 37, RIGHT: 39, SPACEBAR: 32, TAB: 9, UP: 38, modifierPressed: function (e) {
            return e.shiftKey || e.ctrlKey || e.altKey
        }, metaKeyPressed: function (t) {
            return(e.mac ? t.metaKey : t.ctrlKey) && !t.altKey
        }}
    }), r(T, [S, f, h], function (e, t, n) {
        return function (r, i) {
            function o(e) {
                return i.settings.object_resizing === !1 ? !1 : /TABLE|IMG|DIV/.test(e.nodeName) ? "false" === e.getAttribute("data-mce-resize") ? !1 : !0 : !1
            }

            function a(t) {
                var n, r;
                n = t.screenX - k, r = t.screenY - S, D = n * N[2] + A, M = r * N[3] + B, D = 5 > D ? 5 : D, M = 5 > M ? 5 : M, (e.modifierPressed(t) || "IMG" == x.nodeName && N[2] * N[3] !== 0) && (D = Math.round(M / L), M = Math.round(D * L)), b.setStyles(w, {width: D, height: M}), N[2] < 0 && w.clientWidth <= D && b.setStyle(w, "left", T + (A - D)), N[3] < 0 && w.clientHeight <= M && b.setStyle(w, "top", R + (B - M)), H || (i.fire("ObjectResizeStart", {target: x, width: A, height: B}), H = !0)
            }

            function s() {
                function e(e, t) {
                    t && (x.style[e] || !i.schema.isValid(x.nodeName.toLowerCase(), e) ? b.setStyle(x, e, t) : b.setAttrib(x, e, t))
                }

                H = !1, e("width", D), e("height", M), b.unbind(P, "mousemove", a), b.unbind(P, "mouseup", s), O != P && (b.unbind(O, "mousemove", a), b.unbind(O, "mouseup", s)), b.remove(w), I && "TABLE" != x.nodeName || l(x), i.fire("ObjectResized", {target: x, width: D, height: M}), i.nodeChanged()
            }

            function l(e, t, n) {
                var r, l, d, u, f, p = i.getBody();
                r = b.getPos(e, p), T = r.x, R = r.y, f = e.getBoundingClientRect(), l = f.width || f.right - f.left, d = f.height || f.bottom - f.top, x != e && (h(), x = e, D = M = 0), u = i.fire("ObjectSelected", {target: e}), o(e) && !u.isDefaultPrevented() ? C(_, function (e, r) {
                    function o(t) {
                        H = !0, k = t.screenX, S = t.screenY, A = x.clientWidth, B = x.clientHeight, L = B / A, N = e, w = x.cloneNode(!0), b.addClass(w, "mce-clonedresizable"), w.contentEditable = !1, w.unSelectabe = !0, b.setStyles(w, {left: T, top: R, margin: 0}), w.removeAttribute("data-mce-selected"), i.getBody().appendChild(w), b.bind(P, "mousemove", a), b.bind(P, "mouseup", s), O != P && (b.bind(O, "mousemove", a), b.bind(O, "mouseup", s))
                    }

                    var c, u;
                    return t ? (r == t && o(n), void 0) : (c = b.get("mceResizeHandle" + r), c ? b.show(c) : (u = i.getBody(), c = b.add(u, "div", {id: "mceResizeHandle" + r, "data-mce-bogus": !0, "class": "mce-resizehandle", contentEditable: !1, unSelectabe: !0, style: "cursor:" + r + "-resize; margin:0; padding:0"}), b.bind(c, "mousedown", function (e) {
                        e.preventDefault(), o(e)
                    })), b.setStyles(c, {left: l * e[0] + T - c.offsetWidth / 2, top: d * e[1] + R - c.offsetHeight / 2}), void 0)
                }) : c(), x.setAttribute("data-mce-selected", "1")
            }

            function c() {
                var e, t;
                x && x.removeAttribute("data-mce-selected");
                for (e in _)t = b.get("mceResizeHandle" + e), t && (b.unbind(t), b.remove(t))
            }

            function d(e) {
                function t(e, t) {
                    do if (e === t)return!0; while (e = e.parentNode)
                }

                var n;
                return C(b.select("img[data-mce-selected],hr[data-mce-selected]"), function (e) {
                    e.removeAttribute("data-mce-selected")
                }), n = "mousedown" == e.type ? e.target : r.getNode(), n = b.getParent(n, I ? "table" : "table,img,hr"), n && (g(), t(r.getStart(), n) && t(r.getEnd(), n) && (!I || n != r.getStart() && "IMG" !== r.getStart().nodeName)) ? (l(n), void 0) : (c(), void 0)
            }

            function u(e, t, n) {
                e && e.attachEvent && e.attachEvent("on" + t, n)
            }

            function f(e, t, n) {
                e && e.detachEvent && e.detachEvent("on" + t, n)
            }

            function p(e) {
                var t = e.srcElement, n, r, o, a, s, c, d;
                n = t.getBoundingClientRect(), c = E.clientX - n.left, d = E.clientY - n.top;
                for (r in _)if (o = _[r], a = t.offsetWidth * o[0], s = t.offsetHeight * o[1], Math.abs(a - c) < 8 && Math.abs(s - d) < 8) {
                    N = o;
                    break
                }
                H = !0, i.getDoc().selection.empty(), l(t, r, E)
            }

            function m(e) {
                var t = e.srcElement;
                if (t != x) {
                    if (h(), 0 === t.id.indexOf("mceResizeHandle"))return e.returnValue = !1, void 0;
                    ("IMG" == t.nodeName || "TABLE" == t.nodeName) && (c(), x = t, u(t, "resizestart", p))
                }
            }

            function h() {
                f(x, "resizestart", p)
            }

            function g() {
                try {
                    i.getDoc().execCommand("enableObjectResizing", !1, !1)
                } catch (e) {
                }
            }

            function v(e) {
                var t;
                if (I) {
                    t = P.body.createControlRange();
                    try {
                        return t.addElement(e), t.select(), !0
                    } catch (n) {
                    }
                }
            }

            function y() {
                x = w = null, I && (h(), f(i.getBody(), "controlselect", m))
            }

            var b = i.dom, C = t.each, x, w, _, N, E, k, S, T, R, A, B, L, H, D, M, P = i.getDoc(), O = document, I = n.ie && n.ie < 11;
            _ = {n: [.5, 0, 0, -1], e: [1, .5, 1, 0], s: [.5, 1, 0, 1], w: [0, .5, -1, 0], nw: [0, 0, -1, -1], ne: [1, 0, 1, -1], se: [1, 1, 1, 1], sw: [0, 1, -1, 1]};
            var F = ".mce-content-body";
            return i.contentStyles.push(F + " div.mce-resizehandle {position: absolute;border: 1px solid black;background: #FFF;width: 5px;height: 5px;z-index: 10000}" + F + " .mce-resizehandle:hover {background: #000}" + F + " img[data-mce-selected], hr[data-mce-selected] {outline: 1px solid black;resize: none}" + F + " .mce-clonedresizable {position: absolute;" + (n.gecko ? "" : "outline: 1px dashed black;") + "opacity: .5;filter: alpha(opacity=50);z-index: 10000}"), i.on("init", function () {
                I ? (i.on("ObjectResized", function (e) {
                    "TABLE" != e.target.nodeName && (c(), v(e.target))
                }), u(i.getBody(), "controlselect", m), i.on("mousedown", function (e) {
                    E = e
                })) : (g(), n.ie >= 11 && (i.on("mouseup", function (e) {
                    var t = e.target.nodeName;
                    /^(TABLE|IMG|HR)$/.test(t) && (i.selection.select(e.target, "TABLE" == t), i.nodeChanged())
                }), i.dom.bind(i.getBody(), "mscontrolselect", function (e) {
                    /^(TABLE|IMG|HR)$/.test(e.target.nodeName) && e.preventDefault()
                }))), i.on("nodechange mousedown mouseup ResizeEditor", d), i.on("keydown keyup", function (e) {
                    x && "TABLE" == x.nodeName && d(e)
                })
            }), {controlSelect: v, destroy: y}
        }
    }), r(R, [u, k, T, h, f], function (e, n, r, i, o) {
        function a(e, t, i, o) {
            var a = this;
            a.dom = e, a.win = t, a.serializer = i, a.editor = o, a.controlSelection = new r(a, o), a.win.getSelection || (a.tridentSel = new n(a))
        }

        var s = o.each, l = o.grep, c = o.trim, d = i.ie, u = i.opera;
        return a.prototype = {setCursorLocation: function (e, t) {
            var n = this, r = n.dom.createRng();
            e ? (r.setStart(e, t), r.setEnd(e, t), n.setRng(r), n.collapse(!1)) : (n._moveEndPoint(r, n.editor.getBody(), !0), n.setRng(r))
        }, getContent: function (e) {
            var n = this, r = n.getRng(), i = n.dom.create("body"), o = n.getSel(), a, s, l;
            return e = e || {}, a = s = "", e.get = !0, e.format = e.format || "html", e.selection = !0, n.editor.fire("BeforeGetContent", e), "text" == e.format ? n.isCollapsed() ? "" : r.text || (o.toString ? o.toString() : "") : (r.cloneContents ? (l = r.cloneContents(), l && i.appendChild(l)) : r.item !== t || r.htmlText !== t ? (i.innerHTML = "<br>" + (r.item ? r.item(0).outerHTML : r.htmlText), i.removeChild(i.firstChild)) : i.innerHTML = r.toString(), /^\s/.test(i.innerHTML) && (a = " "), /\s+$/.test(i.innerHTML) && (s = " "), e.getInner = !0, e.content = n.isCollapsed() ? "" : a + n.serializer.serialize(i, e) + s, n.editor.fire("GetContent", e), e.content)
        }, setContent: function (e, t) {
            var n = this, r = n.getRng(), i, o = n.win.document, a, s;
            if (t = t || {format: "html"}, t.set = !0, t.selection = !0, e = t.content = e, t.no_events || n.editor.fire("BeforeSetContent", t), e = t.content, r.insertNode) {
                e += '<span id="__caret">_</span>', r.startContainer == o && r.endContainer == o ? o.body.innerHTML = e : (r.deleteContents(), 0 === o.body.childNodes.length ? o.body.innerHTML = e : r.createContextualFragment ? r.insertNode(r.createContextualFragment(e)) : (a = o.createDocumentFragment(), s = o.createElement("div"), a.appendChild(s), s.outerHTML = e, r.insertNode(a))), i = n.dom.get("__caret"), r = o.createRange(), r.setStartBefore(i), r.setEndBefore(i), n.setRng(r), n.dom.remove("__caret");
                try {
                    n.setRng(r)
                } catch (l) {
                }
            } else r.item && (o.execCommand("Delete", !1, null), r = n.getRng()), /^\s+/.test(e) ? (r.pasteHTML('<span id="__mce_tmp">_</span>' + e), n.dom.remove("__mce_tmp")) : r.pasteHTML(e);
            t.no_events || n.editor.fire("SetContent", t)
        }, getStart: function () {
            var e = this, t = e.getRng(), n, r, i, o;
            if (t.duplicate || t.item) {
                if (t.item)return t.item(0);
                for (i = t.duplicate(), i.collapse(1), n = i.parentElement(), n.ownerDocument !== e.dom.doc && (n = e.dom.getRoot()), r = o = t.parentElement(); o = o.parentNode;)if (o == n) {
                    n = r;
                    break
                }
                return n
            }
            return n = t.startContainer, 1 == n.nodeType && n.hasChildNodes() && (n = n.childNodes[Math.min(n.childNodes.length - 1, t.startOffset)]), n && 3 == n.nodeType ? n.parentNode : n
        }, getEnd: function () {
            var e = this, t = e.getRng(), n, r;
            return t.duplicate || t.item ? t.item ? t.item(0) : (t = t.duplicate(), t.collapse(0), n = t.parentElement(), n.ownerDocument !== e.dom.doc && (n = e.dom.getRoot()), n && "BODY" == n.nodeName ? n.lastChild || n : n) : (n = t.endContainer, r = t.endOffset, 1 == n.nodeType && n.hasChildNodes() && (n = n.childNodes[r > 0 ? r - 1 : r]), n && 3 == n.nodeType ? n.parentNode : n)
        }, getBookmark: function (e, t) {
            function n(e, t) {
                var n = 0;
                return s(a.select(e), function (e, r) {
                    e == t && (n = r)
                }), n
            }

            function r(e) {
                function t(t) {
                    var n, r, i, o = t ? "start" : "end";
                    n = e[o + "Container"], r = e[o + "Offset"], 1 == n.nodeType && "TR" == n.nodeName && (i = n.childNodes, n = i[Math.min(t ? r : r - 1, i.length - 1)], n && (r = t ? 0 : n.childNodes.length, e["set" + (t ? "Start" : "End")](n, r)))
                }

                return t(!0), t(), e
            }

            function i() {
                function e(e, n) {
                    var i = e[n ? "startContainer" : "endContainer"], a = e[n ? "startOffset" : "endOffset"], s = [], l, c, d = 0;
                    if (3 == i.nodeType) {
                        if (t)for (l = i.previousSibling; l && 3 == l.nodeType; l = l.previousSibling)a += l.nodeValue.length;
                        s.push(a)
                    } else c = i.childNodes, a >= c.length && c.length && (d = 1, a = Math.max(0, c.length - 1)), s.push(o.dom.nodeIndex(c[a], t) + d);
                    for (; i && i != r; i = i.parentNode)s.push(o.dom.nodeIndex(i, t));
                    return s
                }

                var n = o.getRng(!0), r = a.getRoot(), i = {};
                return i.start = e(n, !0), o.isCollapsed() || (i.end = e(n)), i
            }

            var o = this, a = o.dom, l, c, d, u, f, p, m = "&#xFEFF;", h;
            if (2 == e)return p = o.getNode(), f = p.nodeName, "IMG" == f ? {name: f, index: n(f, p)} : o.tridentSel ? o.tridentSel.getBookmark(e) : i();
            if (e)return{rng: o.getRng()};
            if (l = o.getRng(), d = a.uniqueId(), u = o.isCollapsed(), h = "overflow:hidden;line-height:0px", l.duplicate || l.item) {
                if (l.item)return p = l.item(0), f = p.nodeName, {name: f, index: n(f, p)};
                c = l.duplicate();
                try {
                    l.collapse(), l.pasteHTML('<span data-mce-type="bookmark" id="' + d + '_start" style="' + h + '">' + m + "</span>"), u || (c.collapse(!1), l.moveToElementText(c.parentElement()), 0 === l.compareEndPoints("StartToEnd", c) && c.move("character", -1), c.pasteHTML('<span data-mce-type="bookmark" id="' + d + '_end" style="' + h + '">' + m + "</span>"))
                } catch (g) {
                    return null
                }
            } else {
                if (p = o.getNode(), f = p.nodeName, "IMG" == f)return{name: f, index: n(f, p)};
                c = r(l.cloneRange()), u || (c.collapse(!1), c.insertNode(a.create("span", {"data-mce-type": "bookmark", id: d + "_end", style: h}, m))), l = r(l), l.collapse(!0), l.insertNode(a.create("span", {"data-mce-type": "bookmark", id: d + "_start", style: h}, m))
            }
            return o.moveToBookmark({id: d, keep: 1}), {id: d}
        }, moveToBookmark: function (e) {
            function t(t) {
                var n = e[t ? "start" : "end"], r, i, o, s;
                if (n) {
                    for (o = n[0], i = c, r = n.length - 1; r >= 1; r--) {
                        if (s = i.childNodes, n[r] > s.length - 1)return;
                        i = s[n[r]]
                    }
                    3 === i.nodeType && (o = Math.min(n[0], i.nodeValue.length)), 1 === i.nodeType && (o = Math.min(n[0], i.childNodes.length)), t ? a.setStart(i, o) : a.setEnd(i, o)
                }
                return!0
            }

            function n(t) {
                var n = o.get(e.id + "_" + t), r, i, a, c, d = e.keep;
                if (n && (r = n.parentNode, "start" == t ? (d ? (r = n.firstChild, i = 1) : i = o.nodeIndex(n), f = p = r, m = h = i) : (d ? (r = n.firstChild, i = 1) : i = o.nodeIndex(n), p = r, h = i), !d)) {
                    for (c = n.previousSibling, a = n.nextSibling, s(l(n.childNodes), function (e) {
                        3 == e.nodeType && (e.nodeValue = e.nodeValue.replace(/\uFEFF/g, ""))
                    }); n = o.get(e.id + "_" + t);)o.remove(n, 1);
                    c && a && c.nodeType == a.nodeType && 3 == c.nodeType && !u && (i = c.nodeValue.length, c.appendData(a.nodeValue), o.remove(a), "start" == t ? (f = p = c, m = h = i) : (p = c, h = i))
                }
            }

            function r(e) {
                return!o.isBlock(e) || e.innerHTML || d || (e.innerHTML = '<br data-mce-bogus="1" />'), e
            }

            var i = this, o = i.dom, a, c, f, p, m, h;
            if (e)if (e.start) {
                if (a = o.createRng(), c = o.getRoot(), i.tridentSel)return i.tridentSel.moveToBookmark(e);
                t(!0) && t() && i.setRng(a)
            } else e.id ? (n("start"), n("end"), f && (a = o.createRng(), a.setStart(r(f), m), a.setEnd(r(p), h), i.setRng(a))) : e.name ? i.select(o.select(e.name)[e.index]) : e.rng && i.setRng(e.rng)
        }, select: function (e, t) {
            var n = this, r = n.dom, i = r.createRng(), o;
            if (n.lastFocusBookmark = null, e) {
                if (!t && n.controlSelection.controlSelect(e))return;
                o = r.nodeIndex(e), i.setStart(e.parentNode, o), i.setEnd(e.parentNode, o + 1), t && (n._moveEndPoint(i, e, !0), n._moveEndPoint(i, e)), n.setRng(i)
            }
            return e
        }, isCollapsed: function () {
            var e = this, t = e.getRng(), n = e.getSel();
            return!t || t.item ? !1 : t.compareEndPoints ? 0 === t.compareEndPoints("StartToEnd", t) : !n || t.collapsed
        }, collapse: function (e) {
            var t = this, n = t.getRng(), r;
            n.item && (r = n.item(0), n = t.win.document.body.createTextRange(), n.moveToElementText(r)), n.collapse(!!e), t.setRng(n)
        }, getSel: function () {
            var e = this.win;
            return e.getSelection ? e.getSelection() : e.document.selection
        }, getRng: function (e) {
            var t = this, n, r, i, o = t.win.document, a;
            if (!e && t.lastFocusBookmark) {
                var s = t.lastFocusBookmark;
                return s.startContainer ? (r = o.createRange(), r.setStart(s.startContainer, s.startOffset), r.setEnd(s.endContainer, s.endOffset)) : r = s, r
            }
            if (e && t.tridentSel)return t.tridentSel.getRangeAt(0);
            try {
                (n = t.getSel()) && (r = n.rangeCount > 0 ? n.getRangeAt(0) : n.createRange ? n.createRange() : o.createRange())
            } catch (l) {
            }
            if (d && r && r.setStart) {
                try {
                    a = o.selection.createRange()
                } catch (l) {
                }
                a && a.item && (i = a.item(0), r = o.createRange(), r.setStartBefore(i), r.setEndAfter(i))
            }
            return r || (r = o.createRange ? o.createRange() : o.body.createTextRange()), r.setStart && 9 === r.startContainer.nodeType && r.collapsed && (i = t.dom.getRoot(), r.setStart(i, 0), r.setEnd(i, 0)), t.selectedRange && t.explicitRange && (0 === r.compareBoundaryPoints(r.START_TO_START, t.selectedRange) && 0 === r.compareBoundaryPoints(r.END_TO_END, t.selectedRange) ? r = t.explicitRange : (t.selectedRange = null, t.explicitRange = null)), r
        }, setRng: function (e, t) {
            var n = this, r;
            if (e.select)try {
                e.select()
            } catch (i) {
            } else if (n.tridentSel) {
                if (e.cloneRange)try {
                    return n.tridentSel.addRange(e), void 0
                } catch (i) {
                }
            } else if (r = n.getSel()) {
                n.explicitRange = e;
                try {
                    r.removeAllRanges(), r.addRange(e)
                } catch (i) {
                }
                t === !1 && r.extend && (r.collapse(e.endContainer, e.endOffset), r.extend(e.startContainer, e.startOffset)), n.selectedRange = r.rangeCount > 0 ? r.getRangeAt(0) : null
            }
        }, setNode: function (e) {
            var t = this;
            return t.setContent(t.dom.getOuterHTML(e)), e
        }, getNode: function () {
            function e(e, t) {
                for (var n = e; e && 3 === e.nodeType && 0 === e.length;)e = t ? e.nextSibling : e.previousSibling;
                return e || n
            }

            var t = this, n = t.getRng(), r, i = n.startContainer, o = n.endContainer, a = n.startOffset, s = n.endOffset, l = t.dom.getRoot();
            return n ? n.setStart ? (r = n.commonAncestorContainer, !n.collapsed && (i == o && 2 > s - a && i.hasChildNodes() && (r = i.childNodes[a]), 3 === i.nodeType && 3 === o.nodeType && (i = i.length === a ? e(i.nextSibling, !0) : i.parentNode, o = 0 === s ? e(o.previousSibling, !1) : o.parentNode, i && i === o)) ? i : r && 3 == r.nodeType ? r.parentNode : r) : (r = n.item ? n.item(0) : n.parentElement(), r.ownerDocument !== t.win.document && (r = l), r) : l
        }, getSelectedBlocks: function (t, n) {
            var r = this, i = r.dom, o, a, s = [];
            if (a = i.getRoot(), t = i.getParent(t || r.getStart(), i.isBlock), n = i.getParent(n || r.getEnd(), i.isBlock), t && t != a && s.push(t), t && n && t != n) {
                o = t;
                for (var l = new e(t, a); (o = l.next()) && o != n;)i.isBlock(o) && s.push(o)
            }
            return n && t != n && n != a && s.push(n), s
        }, isForward: function () {
            var e = this.dom, t = this.getSel(), n, r;
            return t && t.anchorNode && t.focusNode ? (n = e.createRng(), n.setStart(t.anchorNode, t.anchorOffset), n.collapse(!0), r = e.createRng(), r.setStart(t.focusNode, t.focusOffset), r.collapse(!0), n.compareBoundaryPoints(n.START_TO_START, r) <= 0) : !0
        }, normalize: function () {
            function t(t) {
                function a(t, n) {
                    for (var r = new e(t, f.getParent(t.parentNode, f.isBlock) || p); t = r[n ? "prev" : "next"]();)if ("BR" === t.nodeName)return!0
                }

                function s(e, t) {
                    return e.previousSibling && e.previousSibling.nodeName == t
                }

                function l(t, n) {
                    var r, a;
                    for (n = n || c, r = new e(n, f.getParent(n.parentNode, f.isBlock) || p); m = r[t ? "prev" : "next"]();) {
                        if (3 === m.nodeType && m.nodeValue.length > 0)return c = m, d = t ? m.nodeValue.length : 0, i = !0, void 0;
                        if (f.isBlock(m) || h[m.nodeName.toLowerCase()])return;
                        a = m
                    }
                    o && a && (c = a, i = !0, d = 0)
                }

                var c, d, u, f = n.dom, p = f.getRoot(), m, h, g, v;
                if (c = r[(t ? "start" : "end") + "Container"], d = r[(t ? "start" : "end") + "Offset"], h = f.schema.getNonEmptyElements(), v = t, 1 == c.nodeType && d > c.childNodes.length - 1 && (v = !1), 9 === c.nodeType && (c = f.getRoot(), d = 0), c === p) {
                    if (v && (m = c.childNodes[d > 0 ? d - 1 : 0], m && (g = m.nodeName.toLowerCase(), h[m.nodeName] || "TABLE" == m.nodeName)))return;
                    if (c.hasChildNodes() && (d = Math.min(!v && d > 0 ? d - 1 : d, c.childNodes.length - 1), c = c.childNodes[d], d = 0, c.hasChildNodes() && !/TABLE/.test(c.nodeName))) {
                        m = c, u = new e(c, p);
                        do {
                            if (3 === m.nodeType && m.nodeValue.length > 0) {
                                d = v ? 0 : m.nodeValue.length, c = m, i = !0;
                                break
                            }
                            if (h[m.nodeName.toLowerCase()]) {
                                d = f.nodeIndex(m), c = m.parentNode, "IMG" != m.nodeName || v || d++, i = !0;
                                break
                            }
                        } while (m = v ? u.next() : u.prev())
                    }
                }
                o && (3 === c.nodeType && 0 === d && l(!0), 1 === c.nodeType && (m = c.childNodes[d], !m || "BR" !== m.nodeName || s(m, "A") || a(m) || a(m, !0) || l(!0, c.childNodes[d]))), v && !o && 3 === c.nodeType && d === c.nodeValue.length && l(!1), i && r["set" + (t ? "Start" : "End")](c, d)
            }

            var n = this, r, i, o;
            d || (r = n.getRng(), o = r.collapsed, t(!0), o || t(), i && (o && r.collapse(!0), n.setRng(r, n.isForward())))
        }, selectorChanged: function (e, t) {
            var n = this, r;
            return n.selectorChangedData || (n.selectorChangedData = {}, r = {}, n.editor.on("NodeChange", function (e) {
                var t = e.element, i = n.dom, o = i.getParents(t, null, i.getRoot()), a = {};
                s(n.selectorChangedData, function (e, t) {
                    s(o, function (n) {
                        return i.is(n, t) ? (r[t] || (s(e, function (e) {
                            e(!0, {node: n, selector: t, parents: o})
                        }), r[t] = e), a[t] = e, !1) : void 0
                    })
                }), s(r, function (e, n) {
                    a[n] || (delete r[n], s(e, function (e) {
                        e(!1, {node: t, selector: n, parents: o})
                    }))
                })
            })), n.selectorChangedData[e] || (n.selectorChangedData[e] = []), n.selectorChangedData[e].push(t), n
        }, getScrollContainer: function () {
            for (var e, t = this.dom.getRoot(); t && "BODY" != t.nodeName;) {
                if (t.scrollHeight > t.clientHeight) {
                    e = t;
                    break
                }
                t = t.parentNode
            }
            return e
        }, scrollIntoView: function (e) {
            function t(e) {
                for (var t = 0, n = 0, r = e; r && r.nodeType;)t += r.offsetLeft || 0, n += r.offsetTop || 0, r = r.offsetParent;
                return{x: t, y: n}
            }

            var n, r, i = this, o = i.dom, a = o.getRoot(), s, l;
            if ("BODY" != a.nodeName) {
                var c = i.getScrollContainer();
                if (c)return n = t(e).y - t(c).y, l = c.clientHeight, s = c.scrollTop, (s > n || n + 25 > s + l) && (c.scrollTop = s > n ? n : n - l + 25), void 0
            }
            r = o.getViewPort(i.editor.getWin()), n = o.getPos(e).y, s = r.y, l = r.h, (n < r.y || n + 25 > s + l) && i.editor.getWin().scrollTo(0, s > n ? n : n - l + 25)
        }, _moveEndPoint: function (t, n, r) {
            var o = n, a = new e(n, o), s = this.dom.schema.getNonEmptyElements();
            do {
                if (3 == n.nodeType && 0 !== c(n.nodeValue).length)return r ? t.setStart(n, 0) : t.setEnd(n, n.nodeValue.length), void 0;
                if (s[n.nodeName])return r ? t.setStartBefore(n) : "BR" == n.nodeName ? t.setEndBefore(n) : t.setEndAfter(n), void 0;
                if (i.ie && i.ie < 11 && this.dom.isBlock(n) && this.dom.isEmpty(n))return r ? t.setStart(n, 0) : t.setEnd(n, 0), void 0
            } while (n = r ? a.next() : a.prev());
            "BODY" == o.nodeName && (r ? t.setStart(o, 0) : t.setEnd(o, o.childNodes.length))
        }, destroy: function () {
            this.win = null, this.controlSelection.destroy()
        }}, a
    }), r(A, [f], function (e) {
        function t(e) {
            this.walk = function (t, r) {
                function i(e) {
                    var t;
                    return t = e[0], 3 === t.nodeType && t === l && c >= t.nodeValue.length && e.splice(0, 1), t = e[e.length - 1], 0 === u && e.length > 0 && t === d && 3 === t.nodeType && e.splice(e.length - 1, 1), e
                }

                function o(e, t, n) {
                    for (var r = []; e && e != n; e = e[t])r.push(e);
                    return r
                }

                function a(e, t) {
                    do {
                        if (e.parentNode == t)return e;
                        e = e.parentNode
                    } while (e)
                }

                function s(e, t, n) {
                    var a = n ? "nextSibling" : "previousSibling";
                    for (h = e, g = h.parentNode; h && h != t; h = g)g = h.parentNode, v = o(h == e ? h : h[a], a), v.length && (n || v.reverse(), r(i(v)))
                }

                var l = t.startContainer, c = t.startOffset, d = t.endContainer, u = t.endOffset, f, p, m, h, g, v, y;
                if (y = e.select("td.mce-item-selected,th.mce-item-selected"), y.length > 0)return n(y, function (e) {
                    r([e])
                }), void 0;
                if (1 == l.nodeType && l.hasChildNodes() && (l = l.childNodes[c]), 1 == d.nodeType && d.hasChildNodes() && (d = d.childNodes[Math.min(u - 1, d.childNodes.length - 1)]), l == d)return r(i([l]));
                for (f = e.findCommonAncestor(l, d), h = l; h; h = h.parentNode) {
                    if (h === d)return s(l, f, !0);
                    if (h === f)break
                }
                for (h = d; h; h = h.parentNode) {
                    if (h === l)return s(d, f);
                    if (h === f)break
                }
                p = a(l, f) || l, m = a(d, f) || d, s(l, p, !0), v = o(p == l ? p : p.nextSibling, "nextSibling", m == d ? m.nextSibling : m), v.length && r(i(v)), s(d, m)
            }, this.split = function (e) {
                function t(e, t) {
                    return e.splitText(t)
                }

                var n = e.startContainer, r = e.startOffset, i = e.endContainer, o = e.endOffset;
                return n == i && 3 == n.nodeType ? r > 0 && r < n.nodeValue.length && (i = t(n, r), n = i.previousSibling, o > r ? (o -= r, n = i = t(i, o).previousSibling, o = i.nodeValue.length, r = 0) : o = 0) : (3 == n.nodeType && r > 0 && r < n.nodeValue.length && (n = t(n, r), r = 0), 3 == i.nodeType && o > 0 && o < i.nodeValue.length && (i = t(i, o).previousSibling, o = i.nodeValue.length)), {startContainer: n, startOffset: r, endContainer: i, endOffset: o}
            }
        }

        var n = e.each;
        return t.compareRanges = function (e, t) {
            if (e && t) {
                if (!e.item && !e.duplicate)return e.startContainer == t.startContainer && e.startOffset == t.startOffset;
                if (e.item && t.item && e.item(0) === t.item(0))return!0;
                if (e.isEqual && t.isEqual && t.isEqual(e))return!0
            }
            return!1
        }, t
    }), r(B, [u, A, f], function (e, t, n) {
        return function (r) {
            function i(e) {
                return e.nodeType && (e = e.nodeName), !!r.schema.getTextBlockElements()[e.toLowerCase()]
            }

            function o(e, t) {
                return I.getParents(e, t, I.getRoot())
            }

            function a(e) {
                return 1 === e.nodeType && "_mce_caret" === e.id
            }

            function s() {
                d({alignleft: [
                    {selector: "figure,p,h1,h2,h3,h4,h5,h6,td,th,tr,div,ul,ol,li", styles: {textAlign: "left"}, defaultBlock: "div"},
                    {selector: "img,table", collapsed: !1, styles: {"float": "left"}}
                ], aligncenter: [
                    {selector: "figure,p,h1,h2,h3,h4,h5,h6,td,th,tr,div,ul,ol,li", styles: {textAlign: "center"}, defaultBlock: "div"},
                    {selector: "img", collapsed: !1, styles: {display: "block", marginLeft: "auto", marginRight: "auto"}},
                    {selector: "table", collapsed: !1, styles: {marginLeft: "auto", marginRight: "auto"}}
                ], alignright: [
                    {selector: "figure,p,h1,h2,h3,h4,h5,h6,td,th,tr,div,ul,ol,li", styles: {textAlign: "right"}, defaultBlock: "div"},
                    {selector: "img,table", collapsed: !1, styles: {"float": "right"}}
                ], alignjustify: [
                    {selector: "figure,p,h1,h2,h3,h4,h5,h6,td,th,tr,div,ul,ol,li", styles: {textAlign: "justify"}, defaultBlock: "div"}
                ], bold: [
                    {inline: "strong", remove: "all"},
                    {inline: "span", styles: {fontWeight: "bold"}},
                    {inline: "b", remove: "all"}
                ], italic: [
                    {inline: "em", remove: "all"},
                    {inline: "span", styles: {fontStyle: "italic"}},
                    {inline: "i", remove: "all"}
                ], underline: [
                    {inline: "span", styles: {textDecoration: "underline"}, exact: !0},
                    {inline: "u", remove: "all"}
                ], strikethrough: [
                    {inline: "span", styles: {textDecoration: "line-through"}, exact: !0},
                    {inline: "strike", remove: "all"}
                ], forecolor: {inline: "span", styles: {color: "%value"}, wrap_links: !1}, hilitecolor: {inline: "span", styles: {backgroundColor: "%value"}, wrap_links: !1}, fontname: {inline: "span", styles: {fontFamily: "%value"}}, fontsize: {inline: "span", styles: {fontSize: "%value"}}, fontsize_class: {inline: "span", attributes: {"class": "%value"}}, blockquote: {block: "blockquote", wrapper: 1, remove: "all"}, subscript: {inline: "sub"}, superscript: {inline: "sup"}, code: {inline: "code"}, link: {inline: "a", selector: "a", remove: "all", split: !0, deep: !0, onmatch: function () {
                    return!0
                }, onformat: function (e, t, n) {
                    et(n, function (t, n) {
                        I.setAttrib(e, n, t)
                    })
                }}, removeformat: [
                    {selector: "b,strong,em,i,font,u,strike,sub,sup", remove: "all", split: !0, expand: !1, block_expand: !0, deep: !0},
                    {selector: "span", attributes: ["style", "class"], remove: "empty", split: !0, expand: !1, deep: !0},
                    {selector: "*", attributes: ["style", "class"], split: !1, expand: !1, deep: !0}
                ]}), et("p h1 h2 h3 h4 h5 h6 div address pre div dt dd samp".split(/\s/), function (e) {
                    d(e, {block: e, remove: "all"})
                }), d(r.settings.formats)
            }

            function l() {
                r.addShortcut("ctrl+b", "bold_desc", "Bold"), r.addShortcut("ctrl+i", "italic_desc", "Italic"), r.addShortcut("ctrl+u", "underline_desc", "Underline");
                for (var e = 1; 6 >= e; e++)r.addShortcut("ctrl+" + e, "", ["FormatBlock", !1, "h" + e]);
                r.addShortcut("ctrl+7", "", ["FormatBlock", !1, "p"]), r.addShortcut("ctrl+8", "", ["FormatBlock", !1, "div"]), r.addShortcut("ctrl+9", "", ["FormatBlock", !1, "address"])
            }

            function c(e) {
                return e ? O[e] : O
            }

            function d(e, t) {
                e && ("string" != typeof e ? et(e, function (e, t) {
                    d(t, e)
                }) : (t = t.length ? t : [t], et(t, function (e) {
                    e.deep === X && (e.deep = !e.selector), e.split === X && (e.split = !e.selector || e.inline), e.remove === X && e.selector && !e.inline && (e.remove = "none"), e.selector && e.inline && (e.mixed = !0, e.block_expand = !0), "string" == typeof e.classes && (e.classes = e.classes.split(/\s+/))
                }), O[e] = t))
            }

            function u(e) {
                var t;
                return r.dom.getParent(e, function (e) {
                    return t = r.dom.getStyle(e, "text-decoration"), t && "none" !== t
                }), t
            }

            function f(e) {
                var t;
                1 === e.nodeType && e.parentNode && 1 === e.parentNode.nodeType && (t = u(e.parentNode), r.dom.getStyle(e, "color") && t ? r.dom.setStyle(e, "text-decoration", t) : r.dom.getStyle(e, "textdecoration") === t && r.dom.setStyle(e, "text-decoration", null))
            }

            function p(t, n, o) {
                function s(e, t) {
                    t = t || h, e && (t.onformat && t.onformat(e, t, n, o), et(t.styles, function (t, r) {
                        I.setStyle(e, r, E(t, n))
                    }), et(t.attributes, function (t, r) {
                        I.setAttrib(e, r, E(t, n))
                    }), et(t.classes, function (t) {
                        t = E(t, n), I.hasClass(e, t) || I.addClass(e, t)
                    }))
                }

                function l() {
                    function t(t, n) {
                        var r = new e(n);
                        for (o = r.current(); o; o = r.prev())if (o.childNodes.length > 1 || o == t || "BR" == o.tagName)return o
                    }

                    var n = r.selection.getRng(), i = n.startContainer, a = n.endContainer;
                    if (i != a && 0 === n.endOffset) {
                        var s = t(i, a), l = 3 == s.nodeType ? s.length : s.childNodes.length;
                        n.setEnd(s, l)
                    }
                    return n
                }

                function d(e, t, n, r, i) {
                    var o = [], a = -1, s, l = -1, c = -1, d;
                    return et(e.childNodes, function (e, t) {
                        return"UL" === e.nodeName || "OL" === e.nodeName ? (a = t, s = e, !1) : void 0
                    }), et(e.childNodes, function (e, n) {
                        "SPAN" === e.nodeName && "bookmark" == I.getAttrib(e, "data-mce-type") && (e.id == t.id + "_start" ? l = n : e.id == t.id + "_end" && (c = n))
                    }), 0 >= a || a > l && c > a ? (et(tt(e.childNodes), i), 0) : (d = I.clone(n, K), et(tt(e.childNodes), function (e, t) {
                        (a > l && a > t || l > a && t > a) && (o.push(e), e.parentNode.removeChild(e))
                    }), a > l ? e.insertBefore(d, s) : l > a && e.insertBefore(d, s.nextSibling), r.push(d), et(o, function (e) {
                        d.appendChild(e)
                    }), d)
                }

                function u(e, r, o) {
                    var l = [], c, u, f = !0;
                    c = h.inline || h.block, u = I.create(c), s(u), z.walk(e, function (e) {
                        function p(e) {
                            var y, C, x, _, N;
                            return N = f, y = e.nodeName.toLowerCase(), C = e.parentNode.nodeName.toLowerCase(), 1 === e.nodeType && J(e) && (N = f, f = "true" === J(e), _ = !0), w(y, "br") ? (v = 0, h.block && I.remove(e), void 0) : h.wrapper && g(e, t, n) ? (v = 0, void 0) : f && !_ && h.block && !h.wrapper && i(y) && W(C, c) ? (e = I.rename(e, c), s(e), l.push(e), v = 0, void 0) : h.selector && (et(m, function (t) {
                                "collapsed"in t && t.collapsed !== b || I.is(e, t.selector) && !a(e) && (s(e, t), x = !0)
                            }), !h.inline || x) ? (v = 0, void 0) : (!f || _ || !W(c, y) || !W(C, c) || !o && 3 === e.nodeType && 1 === e.nodeValue.length && 65279 === e.nodeValue.charCodeAt(0) || a(e) || h.inline && V(e) ? "li" == y && r ? v = d(e, r, u, l, p) : (v = 0, et(tt(e.childNodes), p), _ && (f = N), v = 0) : (v || (v = I.clone(u, K), e.parentNode.insertBefore(v, e), l.push(v)), v.appendChild(e)), void 0)
                        }

                        var v;
                        et(e, p)
                    }), h.wrap_links === !1 && et(l, function (e) {
                        function t(e) {
                            var n, r, i;
                            if ("A" === e.nodeName) {
                                for (r = I.clone(u, K), l.push(r), i = tt(e.childNodes), n = 0; n < i.length; n++)r.appendChild(i[n]);
                                e.appendChild(r)
                            }
                            et(tt(e.childNodes), t)
                        }

                        t(e)
                    }), et(l, function (e) {
                        function r(e) {
                            var t = 0;
                            return et(e.childNodes, function (e) {
                                k(e) || L(e) || t++
                            }), t
                        }

                        function i(e) {
                            var t, n;
                            return et(e.childNodes, function (e) {
                                return 1 != e.nodeType || L(e) || a(e) ? void 0 : (t = e, K)
                            }), t && x(t, h) && (n = I.clone(t, K), s(n), I.replace(n, e, Y), I.remove(t, 1)), n || e
                        }

                        var o;
                        if (o = r(e), (l.length > 1 || !V(e)) && 0 === o)return I.remove(e, 1), void 0;
                        if (h.inline || h.wrapper) {
                            if (h.exact || 1 !== o || (e = i(e)), et(m, function (t) {
                                et(I.select(t.inline, e), function (e) {
                                    var r;
                                    if (t.wrap_links === !1) {
                                        r = e.parentNode;
                                        do if ("A" === r.nodeName)return; while (r = r.parentNode)
                                    }
                                    R(t, n, e, t.exact ? e : null)
                                })
                            }), g(e.parentNode, t, n))return I.remove(e, 1), e = 0, Y;
                            h.merge_with_parents && I.getParent(e.parentNode, function (r) {
                                return g(r, t, n) ? (I.remove(e, 1), e = 0, Y) : void 0
                            }), e && h.merge_siblings !== !1 && (e = H(B(e), e), e = H(e, B(e, Y)))
                        }
                    })
                }

                var m = c(t), h = m[0], v, y, b = !o && F.isCollapsed();
                if (h)if (o)o.nodeType ? (y = I.createRng(), y.setStartBefore(o), y.setEndAfter(o), u(T(y, m), null, !0)) : u(o, null, !0); else if (b && h.inline && !I.select("td.mce-item-selected,th.mce-item-selected").length)M("apply", t, n); else {
                    var C = r.selection.getNode();
                    U || !m[0].defaultBlock || I.getParent(C, I.isBlock) || p(m[0].defaultBlock), r.selection.setRng(l()), v = F.getBookmark(), u(T(F.getRng(Y), m), v), h.styles && (h.styles.color || h.styles.textDecoration) && (nt(C, f, "childNodes"), f(C)), F.moveToBookmark(v), P(F.getRng(Y)), r.nodeChanged()
                }
            }

            function m(e, t, n) {
                function i(e) {
                    var n, r, o, a, s;
                    if (1 === e.nodeType && J(e) && (a = b, b = "true" === J(e), s = !0), n = tt(e.childNodes), b && !s)for (r = 0, o = p.length; o > r && !R(p[r], t, e, e); r++);
                    if (m.deep && n.length) {
                        for (r = 0, o = n.length; o > r; r++)i(n[r]);
                        s && (b = a)
                    }
                }

                function a(n) {
                    var r;
                    return et(o(n.parentNode).reverse(), function (n) {
                        var i;
                        r || "_start" == n.id || "_end" == n.id || (i = g(n, e, t), i && i.split !== !1 && (r = n))
                    }), r
                }

                function s(e, n, r, i) {
                    var o, a, s, l, c, d;
                    if (e) {
                        for (d = e.parentNode, o = n.parentNode; o && o != d; o = o.parentNode) {
                            for (a = I.clone(o, K), c = 0; c < p.length; c++)if (R(p[c], t, a, a)) {
                                a = 0;
                                break
                            }
                            a && (s && a.appendChild(s), l || (l = a), s = a)
                        }
                        !i || m.mixed && V(e) || (n = I.split(e, n)), s && (r.parentNode.insertBefore(s, r), l.appendChild(r))
                    }
                    return n
                }

                function l(e) {
                    return s(a(e), e, e, !0)
                }

                function d(e) {
                    var t = I.get(e ? "_start" : "_end"), n = t[e ? "firstChild" : "lastChild"];
                    return L(n) && (n = n[e ? "firstChild" : "lastChild"]), I.remove(t, !0), n
                }

                function f(e) {
                    var t, n, o = e.commonAncestorContainer;
                    e = T(e, p, Y), m.split && (t = D(e, Y), n = D(e), t != n ? (/^(TR|TH|TD)$/.test(t.nodeName) && t.firstChild && (t = "TR" == t.nodeName ? t.firstChild.firstChild || t : t.firstChild || t), o && /^T(HEAD|BODY|FOOT|R)$/.test(o.nodeName) && /^(TH|TD)$/.test(n.nodeName) && n.firstChild && (n = n.firstChild || n), t = S(t, "span", {id: "_start", "data-mce-type": "bookmark"}), n = S(n, "span", {id: "_end", "data-mce-type": "bookmark"}), l(t), l(n), t = d(Y), n = d()) : t = n = l(t), e.startContainer = t.parentNode, e.startOffset = q(t), e.endContainer = n.parentNode, e.endOffset = q(n) + 1), z.walk(e, function (e) {
                        et(e, function (e) {
                            i(e), 1 === e.nodeType && "underline" === r.dom.getStyle(e, "text-decoration") && e.parentNode && "underline" === u(e.parentNode) && R({deep: !1, exact: !0, inline: "span", styles: {textDecoration: "underline"}}, null, e)
                        })
                    })
                }

                var p = c(e), m = p[0], h, y, b = !0;
                return n ? (n.nodeType ? (y = I.createRng(), y.setStartBefore(n), y.setEndAfter(n), f(y)) : f(n), void 0) : (F.isCollapsed() && m.inline && !I.select("td.mce-item-selected,th.mce-item-selected").length ? M("remove", e, t) : (h = F.getBookmark(), f(F.getRng(Y)), F.moveToBookmark(h), m.inline && v(e, t, F.getStart()) && P(F.getRng(!0)), r.nodeChanged()), void 0)
            }

            function h(e, t, n) {
                var r = c(e);
                !v(e, t, n) || "toggle"in r[0] && !r[0].toggle ? p(e, t, n) : m(e, t, n)
            }

            function g(e, t, n, r) {
                function i(e, t, i) {
                    var o, a, s = t[i], l;
                    if (t.onmatch)return t.onmatch(e, t, i);
                    if (s)if (s.length === X) {
                        for (o in s)if (s.hasOwnProperty(o)) {
                            if (a = "attributes" === i ? I.getAttrib(e, o) : _(e, o), r && !a && !t.exact)return;
                            if ((!r || t.exact) && !w(a, N(E(s[o], n), o)))return
                        }
                    } else for (l = 0; l < s.length; l++)if ("attributes" === i ? I.getAttrib(e, s[l]) : _(e, s[l]))return t;
                    return t
                }

                var o = c(t), a, s, l;
                if (o && e)for (s = 0; s < o.length; s++)if (a = o[s], x(e, a) && i(e, a, "attributes") && i(e, a, "styles")) {
                    if (l = a.classes)for (s = 0; s < l.length; s++)if (!I.hasClass(e, l[s]))return;
                    return a
                }
            }

            function v(e, t, n) {
                function r(n) {
                    var r = I.getRoot();
                    return n === r ? !1 : (n = I.getParent(n, function (n) {
                        return n.parentNode === r || !!g(n, e, t, !0)
                    }), g(n, e, t))
                }

                var i;
                return n ? r(n) : (n = F.getNode(), r(n) ? Y : (i = F.getStart(), i != n && r(i) ? Y : K))
            }

            function y(e, t) {
                var n, r = [], i = {};
                return n = F.getStart(), I.getParent(n, function (n) {
                    var o, a;
                    for (o = 0; o < e.length; o++)a = e[o], !i[a] && g(n, a, t) && (i[a] = !0, r.push(a))
                }, I.getRoot()), r
            }

            function b(e) {
                var t = c(e), n, r, i, a, s;
                if (t)for (n = F.getStart(), r = o(n), a = t.length - 1; a >= 0; a--) {
                    if (s = t[a].selector, !s || t[a].defaultBlock)return Y;
                    for (i = r.length - 1; i >= 0; i--)if (I.is(r[i], s))return Y
                }
                return K
            }

            function C(e, t, n) {
                var i;
                return G || (G = {}, i = {}, r.on("NodeChange", function (e) {
                    var t = o(e.element), n = {};
                    et(G, function (e, r) {
                        et(t, function (o) {
                            return g(o, r, {}, e.similar) ? (i[r] || (et(e, function (e) {
                                e(!0, {node: o, format: r, parents: t})
                            }), i[r] = e), n[r] = e, !1) : void 0
                        })
                    }), et(i, function (r, o) {
                        n[o] || (delete i[o], et(r, function (n) {
                            n(!1, {node: e.element, format: o, parents: t})
                        }))
                    })
                })), et(e.split(","), function (e) {
                    G[e] || (G[e] = [], G[e].similar = n), G[e].push(t)
                }), this
            }

            function x(e, t) {
                return w(e, t.inline) ? Y : w(e, t.block) ? Y : t.selector ? 1 == e.nodeType && I.is(e, t.selector) : void 0
            }

            function w(e, t) {
                return e = e || "", t = t || "", e = "" + (e.nodeName || e), t = "" + (t.nodeName || t), e.toLowerCase() == t.toLowerCase()
            }

            function _(e, t) {
                return N(I.getStyle(e, t), t)
            }

            function N(e, t) {
                return("color" == t || "backgroundColor" == t) && (e = I.toHex(e)), "fontWeight" == t && 700 == e && (e = "bold"), "fontFamily" == t && (e = e.replace(/[\'\"]/g, "").replace(/,\s+/g, ",")), "" + e
            }

            function E(e, t) {
                return"string" != typeof e ? e = e(t) : t && (e = e.replace(/%(\w+)/g, function (e, n) {
                    return t[n] || e
                })), e
            }

            function k(e) {
                return e && 3 === e.nodeType && /^([\t \r\n]+|)$/.test(e.nodeValue)
            }

            function S(e, t, n) {
                var r = I.create(t, n);
                return e.parentNode.insertBefore(r, e), r.appendChild(e), r
            }

            function T(t, n, a) {
                function s(e) {
                    function t(e) {
                        return"BR" == e.nodeName && e.getAttribute("data-mce-bogus") && !e.nextSibling
                    }

                    var r, i, o, a, s;
                    if (r = i = e ? g : y, a = e ? "previousSibling" : "nextSibling", s = I.getRoot(), 3 == r.nodeType && !k(r) && (e ? v > 0 : b < r.nodeValue.length))return r;
                    for (; ;) {
                        if (!n[0].block_expand && V(i))return i;
                        for (o = i[a]; o; o = o[a])if (!L(o) && !k(o) && !t(o))return i;
                        if (i.parentNode == s) {
                            r = i;
                            break
                        }
                        i = i.parentNode
                    }
                    return r
                }

                function l(e, t) {
                    for (t === X && (t = 3 === e.nodeType ? e.length : e.childNodes.length); e && e.hasChildNodes();)e = e.childNodes[t], e && (t = 3 === e.nodeType ? e.length : e.childNodes.length);
                    return{node: e, offset: t}
                }

                function c(e) {
                    for (var t = e; t;) {
                        if (1 === t.nodeType && J(t))return"false" === J(t) ? t : e;
                        t = t.parentNode
                    }
                    return e
                }

                function d(t, n, i) {
                    function o(e, t) {
                        var n, r, o = e.nodeValue;
                        return"undefined" == typeof t && (t = i ? o.length : 0), i ? (n = o.lastIndexOf(" ", t), r = o.lastIndexOf("\xa0", t), n = n > r ? n : r, -1 === n || a || n++) : (n = o.indexOf(" ", t), r = o.indexOf("\xa0", t), n = -1 !== n && (-1 === r || r > n) ? n : r), n
                    }

                    var s, l, c, d;
                    if (3 === t.nodeType) {
                        if (c = o(t, n), -1 !== c)return{container: t, offset: c};
                        d = t
                    }
                    for (s = new e(t, I.getParent(t, V) || r.getBody()); l = s[i ? "prev" : "next"]();)if (3 === l.nodeType) {
                        if (d = l, c = o(l), -1 !== c)return{container: l, offset: c}
                    } else if (V(l))break;
                    return d ? (n = i ? 0 : d.length, {container: d, offset: n}) : void 0
                }

                function u(e, r) {
                    var i, a, s, l;
                    for (3 == e.nodeType && 0 === e.nodeValue.length && e[r] && (e = e[r]), i = o(e), a = 0; a < i.length; a++)for (s = 0; s < n.length; s++)if (l = n[s], !("collapsed"in l && l.collapsed !== t.collapsed) && I.is(i[a], l.selector))return i[a];
                    return e
                }

                function f(e, t) {
                    var r, a = I.getRoot();
                    if (n[0].wrapper || (r = I.getParent(e, n[0].block, a)), r || (r = I.getParent(3 == e.nodeType ? e.parentNode : e, function (e) {
                        return e != a && i(e)
                    })), r && n[0].wrapper && (r = o(r, "ul,ol").reverse()[0] || r), !r)for (r = e; r[t] && !V(r[t]) && (r = r[t], !w(r, "br")););
                    return r || e
                }

                var p, m, h, g = t.startContainer, v = t.startOffset, y = t.endContainer, b = t.endOffset;
                if (1 == g.nodeType && g.hasChildNodes() && (p = g.childNodes.length - 1, g = g.childNodes[v > p ? p : v], 3 == g.nodeType && (v = 0)), 1 == y.nodeType && y.hasChildNodes() && (p = y.childNodes.length - 1, y = y.childNodes[b > p ? p : b - 1], 3 == y.nodeType && (b = y.nodeValue.length)), g = c(g), y = c(y), (L(g.parentNode) || L(g)) && (g = L(g) ? g : g.parentNode, g = g.nextSibling || g, 3 == g.nodeType && (v = 0)), (L(y.parentNode) || L(y)) && (y = L(y) ? y : y.parentNode, y = y.previousSibling || y, 3 == y.nodeType && (b = y.length)), n[0].inline && (t.collapsed && (h = d(g, v, !0), h && (g = h.container, v = h.offset), h = d(y, b), h && (y = h.container, b = h.offset)), m = l(y, b), m.node)) {
                    for (; m.node && 0 === m.offset && m.node.previousSibling;)m = l(m.node.previousSibling);
                    m.node && m.offset > 0 && 3 === m.node.nodeType && " " === m.node.nodeValue.charAt(m.offset - 1) && m.offset > 1 && (y = m.node, y.splitText(m.offset - 1))
                }
                return(n[0].inline || n[0].block_expand) && (n[0].inline && 3 == g.nodeType && 0 !== v || (g = s(!0)), n[0].inline && 3 == y.nodeType && b !== y.nodeValue.length || (y = s())), n[0].selector && n[0].expand !== K && !n[0].inline && (g = u(g, "previousSibling"), y = u(y, "nextSibling")), (n[0].block || n[0].selector) && (g = f(g, "previousSibling"), y = f(y, "nextSibling"), n[0].block && (V(g) || (g = s(!0)), V(y) || (y = s()))), 1 == g.nodeType && (v = q(g), g = g.parentNode), 1 == y.nodeType && (b = q(y) + 1, y = y.parentNode), {startContainer: g, startOffset: v, endContainer: y, endOffset: b}
            }

            function R(e, t, n, r) {
                var i, o, a;
                if (!x(n, e))return K;
                if ("all" != e.remove)for (et(e.styles, function (e, i) {
                    e = N(E(e, t), i), "number" == typeof i && (i = e, r = 0), (!r || w(_(r, i), e)) && I.setStyle(n, i, ""), a = 1
                }), a && "" === I.getAttrib(n, "style") && (n.removeAttribute("style"), n.removeAttribute("data-mce-style")), et(e.attributes, function (e, i) {
                    var o;
                    if (e = E(e, t), "number" == typeof i && (i = e, r = 0), !r || w(I.getAttrib(r, i), e)) {
                        if ("class" == i && (e = I.getAttrib(n, i), e && (o = "", et(e.split(/\s+/), function (e) {
                            /mce\w+/.test(e) && (o += (o ? " " : "") + e)
                        }), o)))return I.setAttrib(n, i, o), void 0;
                        "class" == i && n.removeAttribute("className"), $.test(i) && n.removeAttribute("data-mce-" + i), n.removeAttribute(i)
                    }
                }), et(e.classes, function (e) {
                    e = E(e, t), (!r || I.hasClass(r, e)) && I.removeClass(n, e)
                }), o = I.getAttribs(n), i = 0; i < o.length; i++)if (0 !== o[i].nodeName.indexOf("_"))return K;
                return"none" != e.remove ? (A(n, e), Y) : void 0
            }

            function A(e, t) {
                function n(e, t, n) {
                    return e = B(e, t, n), !e || "BR" == e.nodeName || V(e)
                }

                var i = e.parentNode, o;
                t.block && (U ? i == I.getRoot() && (t.list_block && w(e, t.list_block) || et(tt(e.childNodes), function (e) {
                    W(U, e.nodeName.toLowerCase()) ? o ? o.appendChild(e) : (o = S(e, U), I.setAttribs(o, r.settings.forced_root_block_attrs)) : o = 0
                })) : V(e) && !V(i) && (n(e, K) || n(e.firstChild, Y, 1) || e.insertBefore(I.create("br"), e.firstChild), n(e, Y) || n(e.lastChild, K, 1) || e.appendChild(I.create("br")))), t.selector && t.inline && !w(t.inline, e) || I.remove(e, 1)
            }

            function B(e, t, n) {
                if (e)for (t = t ? "nextSibling" : "previousSibling", e = n ? e : e[t]; e; e = e[t])if (1 == e.nodeType || !k(e))return e
            }

            function L(e) {
                return e && 1 == e.nodeType && "bookmark" == e.getAttribute("data-mce-type")
            }

            function H(e, t) {
                function n(e, t) {
                    function n(e) {
                        var t = {};
                        return et(I.getAttribs(e), function (n) {
                            var r = n.nodeName.toLowerCase();
                            0 !== r.indexOf("_") && "style" !== r && (t[r] = I.getAttrib(e, r))
                        }), t
                    }

                    function r(e, t) {
                        var n, r;
                        for (r in e)if (e.hasOwnProperty(r)) {
                            if (n = t[r], n === X)return K;
                            if (e[r] != n)return K;
                            delete t[r]
                        }
                        for (r in t)if (t.hasOwnProperty(r))return K;
                        return Y
                    }

                    return e.nodeName != t.nodeName ? K : r(n(e), n(t)) ? r(I.parseStyle(I.getAttrib(e, "style")), I.parseStyle(I.getAttrib(t, "style"))) ? Y : K : K
                }

                function r(e, t) {
                    for (i = e; i; i = i[t]) {
                        if (3 == i.nodeType && 0 !== i.nodeValue.length)return e;
                        if (1 == i.nodeType && !L(i))return i
                    }
                    return e
                }

                var i, o;
                if (e && t && (e = r(e, "previousSibling"), t = r(t, "nextSibling"), n(e, t))) {
                    for (i = e.nextSibling; i && i != t;)o = i, i = i.nextSibling, e.appendChild(o);
                    return I.remove(t), et(tt(t.childNodes), function (t) {
                        e.appendChild(t)
                    }), e
                }
                return t
            }

            function D(t, n) {
                var i, o, a;
                return i = t[n ? "startContainer" : "endContainer"], o = t[n ? "startOffset" : "endOffset"], 1 == i.nodeType && (a = i.childNodes.length - 1, !n && o && o--, i = i.childNodes[o > a ? a : o]), 3 === i.nodeType && n && o >= i.nodeValue.length && (i = new e(i, r.getBody()).next() || i), 3 !== i.nodeType || n || 0 !== o || (i = new e(i, r.getBody()).prev() || i), i
            }

            function M(t, n, o) {
                function a(e) {
                    var t = I.create("span", {id: y, "data-mce-bogus": !0, style: b ? "color:red" : ""});
                    return e && t.appendChild(r.getDoc().createTextNode(j)), t
                }

                function s(e, t) {
                    for (; e;) {
                        if (3 === e.nodeType && e.nodeValue !== j || e.childNodes.length > 1)return!1;
                        t && 1 === e.nodeType && t.push(e), e = e.firstChild
                    }
                    return!0
                }

                function l(e) {
                    for (; e;) {
                        if (e.id === y)return e;
                        e = e.parentNode
                    }
                }

                function d(t) {
                    var n;
                    if (t)for (n = new e(t, t), t = n.current(); t; t = n.next())if (3 === t.nodeType)return t
                }

                function u(e, t) {
                    var n, r;
                    if (e)r = F.getRng(!0), s(e) ? (t !== !1 && (r.setStartBefore(e), r.setEndBefore(e)), I.remove(e)) : (n = d(e), n.nodeValue.charAt(0) === j && (n = n.deleteData(0, 1)), I.remove(e, 1)), F.setRng(r); else if (e = l(F.getStart()), !e)for (; e = I.get(y);)u(e, !1)
                }

                function f() {
                    var e, t, r, i, s, u, f;
                    e = F.getRng(!0), i = e.startOffset, u = e.startContainer, f = u.nodeValue, t = l(F.getStart()), t && (r = d(t)), f && i > 0 && i < f.length && /\w/.test(f.charAt(i)) && /\w/.test(f.charAt(i - 1)) ? (s = F.getBookmark(), e.collapse(!0), e = T(e, c(n)), e = z.split(e), p(n, o, e), F.moveToBookmark(s)) : (t && r.nodeValue === j ? p(n, o, t) : (t = a(!0), r = t.firstChild, e.insertNode(t), i = 1, p(n, o, t)), F.setCursorLocation(r, i))
                }

                function h() {
                    var e = F.getRng(!0), t, r, s, l, d, u, f = [], p, h;
                    for (t = e.startContainer, r = e.startOffset, d = t, 3 == t.nodeType && ((r != t.nodeValue.length || t.nodeValue === j) && (l = !0), d = d.parentNode); d;) {
                        if (g(d, n, o)) {
                            u = d;
                            break
                        }
                        d.nextSibling && (l = !0), f.push(d), d = d.parentNode
                    }
                    if (u)if (l)s = F.getBookmark(), e.collapse(!0), e = T(e, c(n), !0), e = z.split(e), m(n, o, e), F.moveToBookmark(s); else {
                        for (h = a(), d = h, p = f.length - 1; p >= 0; p--)d.appendChild(I.clone(f[p], !1)), d = d.firstChild;
                        d.appendChild(I.doc.createTextNode(j)), d = d.firstChild;
                        var v = I.getParent(u, i);
                        v && I.isEmpty(v) ? u.parentNode.replaceChild(h, u) : I.insertAfter(h, u), F.setCursorLocation(d, 1), I.isEmpty(u) && I.remove(u)
                    }
                }

                function v() {
                    var e;
                    e = l(F.getStart()), e && !I.isEmpty(e) && nt(e, function (e) {
                        1 != e.nodeType || e.id === y || I.isEmpty(e) || I.setAttrib(e, "data-mce-bogus", null)
                    }, "childNodes")
                }

                var y = "_mce_caret", b = r.settings.caret_debug;
                r._hasCaretEvents || (Z = function () {
                    var e = [], t;
                    if (s(l(F.getStart()), e))for (t = e.length; t--;)I.setAttrib(e[t], "data-mce-bogus", "1")
                }, Q = function (e) {
                    var t = e.keyCode;
                    u(), (8 == t || 37 == t || 39 == t) && u(l(F.getStart())), v()
                }, r.on("SetContent", function (e) {
                    e.selection && v()
                }), r._hasCaretEvents = !0), "apply" == t ? f() : h()
            }

            function P(t) {
                var n = t.startContainer, r = t.startOffset, i, o, a, s, l;
                if (3 == n.nodeType && r >= n.nodeValue.length && (r = q(n), n = n.parentNode, i = !0), 1 == n.nodeType)for (s = n.childNodes, n = s[Math.min(r, s.length - 1)], o = new e(n, I.getParent(n, I.isBlock)), (r > s.length - 1 || i) && o.next(), a = o.current(); a; a = o.next())if (3 == a.nodeType && !k(a))return l = I.create("a", null, j), a.parentNode.insertBefore(l, a), t.setStart(a, 0), F.setRng(t), I.remove(l), void 0
            }

            var O = {}, I = r.dom, F = r.selection, z = new t(I), W = r.schema.isValidChild, V = I.isBlock, U = r.settings.forced_root_block, q = I.nodeIndex, j = "\ufeff", $ = /^(src|href|style)$/, K = !1, Y = !0, G, X, J = I.getContentEditable, Q, Z, et = n.each, tt = n.grep, nt = n.walk, rt = n.extend;
            rt(this, {get: c, register: d, apply: p, remove: m, toggle: h, match: v, matchAll: y, matchNode: g, canApply: b, formatChanged: C}), s(), l(), r.on("BeforeGetContent", function () {
                Z && Z()
            }), r.on("mouseup keydown", function (e) {
                Q && Q(e)
            })
        }
    }), r(L, [h, f], function (e, t) {
        var n = t.trim, r;
        return r = new RegExp(["<span[^>]+data-mce-bogus[^>]+>[\u200b\ufeff]+<\\/span>", "<div[^>]+data-mce-bogus[^>]+><\\/div>", '\\s?data-mce-selected="[^"]+"'].join("|"), "gi"), function (t) {
            function i() {
                return n(t.getContent({format: "raw", no_events: 1}).replace(r, ""))
            }

            function o() {
                a.typing = !1, a.add()
            }

            var a, s = 0, l = [], c, d, u;
            return t.on("init", function () {
                a.add()
            }), t.on("BeforeExecCommand", function (e) {
                var t = e.command;
                "Undo" != t && "Redo" != t && "mceRepaint" != t && a.beforeChange()
            }), t.on("ExecCommand", function (e) {
                var t = e.command;
                "Undo" != t && "Redo" != t && "mceRepaint" != t && a.add()
            }), t.on("ObjectResizeStart", function () {
                a.beforeChange()
            }), t.on("SaveContent ObjectResized", o), t.dom.bind(t.dom.getRoot(), "dragend", o), t.dom.bind(t.getBody(), "focusout", function () {
                !t.removed && a.typing && o()
            }), t.on("KeyUp", function (n) {
                var r = n.keyCode;
                (r >= 33 && 36 >= r || r >= 37 && 40 >= r || 45 == r || 13 == r || n.ctrlKey) && (o(), t.nodeChanged()), (46 == r || 8 == r || e.mac && (91 == r || 93 == r)) && t.nodeChanged(), d && a.typing && (t.isDirty() || (t.isNotDirty = !l[0] || i() == l[0].content, t.isNotDirty || t.fire("change", {level: l[0], lastLevel: null})), t.fire("TypingUndo"), d = !1, t.nodeChanged())
            }), t.on("KeyDown", function (e) {
                var t = e.keyCode;
                return t >= 33 && 36 >= t || t >= 37 && 40 >= t || 45 == t ? (a.typing && o(), void 0) : ((16 > t || t > 20) && 224 != t && 91 != t && !a.typing && (a.beforeChange(), a.typing = !0, a.add(), d = !0), void 0)
            }), t.on("MouseDown", function () {
                a.typing && o()
            }), t.addShortcut("ctrl+z", "", "Undo"), t.addShortcut("ctrl+y,ctrl+shift+z", "", "Redo"), t.on("AddUndo Undo Redo ClearUndos MouseUp", function (e) {
                e.isDefaultPrevented() || t.nodeChanged()
            }), a = {data: l, typing: !1, beforeChange: function () {
                u || (c = t.selection.getBookmark(2, !0))
            }, add: function (e) {
                var n, r = t.settings, o;
                if (e = e || {}, e.content = i(), u || t.fire("BeforeAddUndo", {level: e}).isDefaultPrevented())return null;
                if (o = l[s], o && o.content == e.content)return null;
                if (l[s] && (l[s].beforeBookmark = c), r.custom_undo_redo_levels && l.length > r.custom_undo_redo_levels) {
                    for (n = 0; n < l.length - 1; n++)l[n] = l[n + 1];
                    l.length--, s = l.length
                }
                e.bookmark = t.selection.getBookmark(2, !0), s < l.length - 1 && (l.length = s + 1), l.push(e), s = l.length - 1;
                var a = {level: e, lastLevel: o};
                return t.fire("AddUndo", a), s > 0 && (t.fire("change", a), t.isNotDirty = !1), e
            }, undo: function () {
                var e;
                return a.typing && (a.add(), a.typing = !1), s > 0 && (e = l[--s], 0 === s && (t.isNotDirty = !0), t.setContent(e.content, {format: "raw"}), t.selection.moveToBookmark(e.beforeBookmark), t.fire("undo", {level: e})), e
            }, redo: function () {
                var e;
                return s < l.length - 1 && (e = l[++s], t.setContent(e.content, {format: "raw"}), t.selection.moveToBookmark(e.bookmark), t.fire("redo", {level: e})), e
            }, clear: function () {
                l = [], s = 0, a.typing = !1, t.fire("ClearUndos")
            }, hasUndo: function () {
                return s > 0 || a.typing && l[0] && i() != l[0].content
            }, hasRedo: function () {
                return s < l.length - 1 && !this.typing
            }, transact: function (e) {
                a.beforeChange(), u = !0, e(), u = !1, a.add()
            }}
        }
    }), r(H, [u, h], function (e, t) {
        var n = t.ie && t.ie < 11;
        return function (r) {
            function i(i) {
                function u(e) {
                    return e && o.isBlock(e) && !/^(TD|TH|CAPTION|FORM)$/.test(e.nodeName) && !/^(fixed|absolute)/i.test(e.style.position) && "true" !== o.getContentEditable(e)
                }

                function f(e) {
                    var t;
                    o.isBlock(e) && (t = a.getRng(), e.appendChild(o.create("span", null, "\xa0")), a.select(e), e.lastChild.outerHTML = "", a.setRng(t))
                }

                function p(e) {
                    for (var t = e, n = [], r; t = t.firstChild;) {
                        if (o.isBlock(t))return;
                        1 != t.nodeType || d[t.nodeName.toLowerCase()] || n.push(t)
                    }
                    for (r = n.length; r--;)t = n[r], !t.hasChildNodes() || t.firstChild == t.lastChild && "" === t.firstChild.nodeValue ? o.remove(t) : "A" == t.nodeName && " " === (t.innerText || t.textContent) && o.remove(t)
                }

                function m(n) {
                    function r(e) {
                        for (; e;) {
                            if (1 == e.nodeType || 3 == e.nodeType && e.data && /[\r\n\s]/.test(e.data))return e;
                            e = e.nextSibling
                        }
                    }

                    var i, s, l, c = n, u;
                    if (t.ie && t.ie < 9 && A && A.firstChild && A.firstChild == A.lastChild && "BR" == A.firstChild.tagName && o.remove(A.firstChild), "LI" == n.nodeName) {
                        var f = r(n.firstChild);
                        f && /^(UL|OL)$/.test(f.nodeName) && n.insertBefore(o.doc.createTextNode("\xa0"), n.firstChild)
                    }
                    if (l = o.createRng(), n.hasChildNodes()) {
                        for (i = new e(n, n); s = i.current();) {
                            if (3 == s.nodeType) {
                                l.setStart(s, 0), l.setEnd(s, 0);
                                break
                            }
                            if (d[s.nodeName.toLowerCase()]) {
                                l.setStartBefore(s), l.setEndBefore(s);
                                break
                            }
                            c = s, s = i.next()
                        }
                        s || (l.setStart(c, 0), l.setEnd(c, 0))
                    } else"BR" == n.nodeName ? n.nextSibling && o.isBlock(n.nextSibling) ? ((!B || 9 > B) && (u = o.create("br"), n.parentNode.insertBefore(u, n)), l.setStartBefore(n), l.setEndBefore(n)) : (l.setStartAfter(n), l.setEndAfter(n)) : (l.setStart(n, 0), l.setEnd(n, 0));
                    a.setRng(l), o.remove(u), a.scrollIntoView(n)
                }

                function h(e) {
                    var t = s.forced_root_block;
                    t && t.toLowerCase() === e.tagName.toLowerCase() && o.setAttribs(e, s.forced_root_block_attrs)
                }

                function g(e) {
                    var t = T, r, i, a;
                    if (e || "TABLE" == P ? (r = o.create(e || I), h(r)) : r = A.cloneNode(!1), a = r, s.keep_styles !== !1)do if (/^(SPAN|STRONG|B|EM|I|FONT|STRIKE|U)$/.test(t.nodeName)) {
                        if ("_mce_caret" == t.id)continue;
                        i = t.cloneNode(!1), o.setAttrib(i, "id", ""), r.hasChildNodes() ? (i.appendChild(r.firstChild), r.appendChild(i)) : (a = i, r.appendChild(i))
                    } while (t = t.parentNode);
                    return n || (a.innerHTML = '<br data-mce-bogus="1">'), r
                }

                function v(t) {
                    var n, r, i;
                    if (3 == T.nodeType && (t ? R > 0 : R < T.nodeValue.length))return!1;
                    if (T.parentNode == A && F && !t)return!0;
                    if (t && 1 == T.nodeType && T == A.firstChild)return!0;
                    if ("TABLE" === T.nodeName || T.previousSibling && "TABLE" == T.previousSibling.nodeName)return F && !t || !F && t;
                    for (n = new e(T, A), 3 == T.nodeType && (t && 0 === R ? n.prev() : t || R != T.nodeValue.length || n.next()); r = n.current();) {
                        if (1 === r.nodeType) {
                            if (!r.getAttribute("data-mce-bogus") && (i = r.nodeName.toLowerCase(), d[i] && "br" !== i))return!1
                        } else if (3 === r.nodeType && !/^[ \t\r\n]*$/.test(r.nodeValue))return!1;
                        t ? n.prev() : n.next()
                    }
                    return!0
                }

                function y(e, t) {
                    var n, i, a, s, l, d, f = I || "P";
                    if (i = o.getParent(e, o.isBlock), d = r.getBody().nodeName.toLowerCase(), !i || !u(i)) {
                        if (i = i || S, !i.hasChildNodes())return n = o.create(f), h(n), i.appendChild(n), E.setStart(n, 0), E.setEnd(n, 0), n;
                        for (s = e; s.parentNode != i;)s = s.parentNode;
                        for (; s && !o.isBlock(s);)a = s, s = s.previousSibling;
                        if (a && c.isValidChild(d, f.toLowerCase())) {
                            for (n = o.create(f), h(n), a.parentNode.insertBefore(n, a), s = a; s && !o.isBlock(s);)l = s.nextSibling, n.appendChild(s), s = l;
                            E.setStart(e, t), E.setEnd(e, t)
                        }
                    }
                    return e
                }

                function b() {
                    function e(e) {
                        for (var t = M[e ? "firstChild" : "lastChild"]; t && 1 != t.nodeType;)t = t[e ? "nextSibling" : "previousSibling"];
                        return t === A
                    }

                    function t() {
                        var e = M.parentNode;
                        return"LI" == e.nodeName ? e : M
                    }

                    var n = M.parentNode.nodeName;
                    /^(OL|UL|LI)$/.test(n) && (I = "LI"), H = I ? g(I) : o.create("BR"), e(!0) && e() ? "LI" == n ? o.insertAfter(H, t()) : o.replace(H, M) : e(!0) ? "LI" == n ? (o.insertAfter(H, t()), H.appendChild(o.doc.createTextNode(" ")), H.appendChild(M)) : M.parentNode.insertBefore(H, M) : e() ? (o.insertAfter(H, t()), f(H)) : (M = t(), k = E.cloneRange(), k.setStartAfter(A), k.setEndAfter(M), D = k.extractContents(), "LI" == I && "LI" == D.firstChild.nodeName ? (H = D.firstChild, o.insertAfter(D, M)) : (o.insertAfter(D, M), o.insertAfter(H, M))), o.remove(A), m(H), l.add()
                }

                function C() {
                    for (var t = new e(T, A), n; n = t.next();)if (d[n.nodeName.toLowerCase()] || n.length > 0)return!0
                }

                function x() {
                    var e, t, r;
                    T && 3 == T.nodeType && R >= T.nodeValue.length && (n || C() || (e = o.create("br"), E.insertNode(e), E.setStartAfter(e), E.setEndAfter(e), t = !0)), e = o.create("br"), E.insertNode(e), n && "PRE" == P && (!B || 8 > B) && e.parentNode.insertBefore(o.doc.createTextNode("\r"), e), r = o.create("span", {}, "&nbsp;"), e.parentNode.insertBefore(r, e), a.scrollIntoView(r), o.remove(r), t ? (E.setStartBefore(e), E.setEndBefore(e)) : (E.setStartAfter(e), E.setEndAfter(e)), a.setRng(E), l.add()
                }

                function w(e) {
                    do 3 === e.nodeType && (e.nodeValue = e.nodeValue.replace(/^[\r\n]+/, "")), e = e.firstChild; while (e)
                }

                function _(e) {
                    var t = o.getRoot(), n, r;
                    for (n = e; n !== t && "false" !== o.getContentEditable(n);)"true" === o.getContentEditable(n) && (r = n), n = n.parentNode;
                    return n !== t ? r : t
                }

                function N(e) {
                    var t;
                    n || (e.normalize(), t = e.lastChild, (!t || /^(left|right)$/gi.test(o.getStyle(t, "float", !0))) && o.add(e, "br"))
                }

                var E = a.getRng(!0), k, S, T, R, A, B, L, H, D, M, P, O, I, F;
                if (!E.collapsed)return r.execCommand("Delete"), void 0;
                if (!i.isDefaultPrevented() && (T = E.startContainer, R = E.startOffset, I = (s.force_p_newlines ? "p" : "") || s.forced_root_block, I = I ? I.toUpperCase() : "", B = o.doc.documentMode, L = i.shiftKey, 1 == T.nodeType && T.hasChildNodes() && (F = R > T.childNodes.length - 1, T = T.childNodes[Math.min(R, T.childNodes.length - 1)] || T, R = F && 3 == T.nodeType ? T.nodeValue.length : 0), S = _(T))) {
                    if (l.beforeChange(), !o.isBlock(S) && S != o.getRoot())return(!I || L) && x(), void 0;
                    if ((I && !L || !I && L) && (T = y(T, R)), A = o.getParent(T, o.isBlock), M = A ? o.getParent(A.parentNode, o.isBlock) : null, P = A ? A.nodeName.toUpperCase() : "", O = M ? M.nodeName.toUpperCase() : "", "LI" != O || i.ctrlKey || (A = M, P = O), "LI" == P) {
                        if (!I && L)return x(), void 0;
                        if (o.isEmpty(A))return b(), void 0
                    }
                    if ("PRE" == P && s.br_in_pre !== !1) {
                        if (!L)return x(), void 0
                    } else if (!I && !L && "LI" != P || I && L)return x(), void 0;
                    I && A === r.getBody() || (I = I || "P", v() ? (H = /^(H[1-6]|PRE|FIGURE)$/.test(P) && "HGROUP" != O ? g(I) : g(), s.end_container_on_empty_block && u(M) && o.isEmpty(A) ? H = o.split(M, A) : o.insertAfter(H, A), m(H)) : v(!0) ? (H = A.parentNode.insertBefore(g(), A), f(H), m(A)) : (k = E.cloneRange(), k.setEndAfter(A), D = k.extractContents(), w(D), H = D.firstChild, o.insertAfter(D, A), p(H), N(A), m(H)), o.setAttrib(H, "id", ""), r.fire("NewBlock", {newBlock: H}), l.add())
                }
            }

            var o = r.dom, a = r.selection, s = r.settings, l = r.undoManager, c = r.schema, d = c.getNonEmptyElements();
            r.on("keydown", function (e) {
                13 == e.keyCode && i(e) !== !1 && e.preventDefault()
            })
        }
    }), r(D, [], function () {
        return function (e) {
            function t() {
                var t = i.getStart(), s = e.getBody(), l, c, d, u, f, p, m, h = -16777215, g, v, y, b, C;
                if (C = n.forced_root_block, t && 1 === t.nodeType && C) {
                    for (; t && t != s;) {
                        if (a[t.nodeName])return;
                        t = t.parentNode
                    }
                    if (l = i.getRng(), l.setStart) {
                        c = l.startContainer, d = l.startOffset, u = l.endContainer, f = l.endOffset;
                        try {
                            v = e.getDoc().activeElement === s
                        } catch (x) {
                        }
                    } else l.item && (t = l.item(0), l = e.getDoc().body.createTextRange(), l.moveToElementText(t)), v = l.parentElement().ownerDocument === e.getDoc(), y = l.duplicate(), y.collapse(!0), d = -1 * y.move("character", h), y.collapsed || (y = l.duplicate(), y.collapse(!1), f = -1 * y.move("character", h) - d);
                    for (t = s.firstChild, b = s.nodeName.toLowerCase(); t;)if ((3 === t.nodeType || 1 == t.nodeType && !a[t.nodeName]) && o.isValidChild(b, C.toLowerCase())) {
                        if (3 === t.nodeType && 0 === t.nodeValue.length) {
                            m = t, t = t.nextSibling, r.remove(m);
                            continue
                        }
                        p || (p = r.create(C, e.settings.forced_root_block_attrs), t.parentNode.insertBefore(p, t), g = !0), m = t, t = t.nextSibling, p.appendChild(m)
                    } else p = null, t = t.nextSibling;
                    if (g && v) {
                        if (l.setStart)l.setStart(c, d), l.setEnd(u, f), i.setRng(l); else try {
                            l = e.getDoc().body.createTextRange(), l.moveToElementText(s), l.collapse(!0), l.moveStart("character", d), f > 0 && l.moveEnd("character", f), l.select()
                        } catch (x) {
                        }
                        e.nodeChanged()
                    }
                }
            }

            var n = e.settings, r = e.dom, i = e.selection, o = e.schema, a = o.getBlockElements();
            n.forced_root_block && e.on("NodeChange", t)
        }
    }), r(M, [N, h, f], function (e, n, r) {
        var i = r.each, o = r.extend, a = r.map, s = r.inArray, l = r.explode, c = n.gecko, d = n.ie, u = !0, f = !1;
        return function (r) {
            function p(e, t, n) {
                var r;
                return e = e.toLowerCase(), (r = N.exec[e]) ? (r(e, t, n), u) : f
            }

            function m(e) {
                var t;
                return e = e.toLowerCase(), (t = N.state[e]) ? t(e) : -1
            }

            function h(e) {
                var t;
                return e = e.toLowerCase(), (t = N.value[e]) ? t(e) : f
            }

            function g(e, t) {
                t = t || "exec", i(e, function (e, n) {
                    i(n.toLowerCase().split(","), function (n) {
                        N[t][n] = e
                    })
                })
            }

            function v(e, n, i) {
                return n === t && (n = f), i === t && (i = null), r.getDoc().execCommand(e, n, i)
            }

            function y(e) {
                return k.match(e)
            }

            function b(e, n) {
                k.toggle(e, n ? {value: n} : t), r.nodeChanged()
            }

            function C(e) {
                S = _.getBookmark(e)
            }

            function x() {
                _.moveToBookmark(S)
            }

            var w = r.dom, _ = r.selection, N = {state: {}, exec: {}, value: {}}, E = r.settings, k = r.formatter, S;
            o(this, {execCommand: p, queryCommandState: m, queryCommandValue: h, addCommands: g}), g({"mceResetDesignMode,mceBeginUndoLevel": function () {
            }, "mceEndUndoLevel,mceAddUndoLevel": function () {
                r.undoManager.add()
            }, "Cut,Copy,Paste": function (e) {
                var t = r.getDoc(), i;
                try {
                    v(e)
                } catch (o) {
                    i = u
                }
                if (i || !t.queryCommandSupported(e)) {
                    var a = r.translate("Your browser doesn't support direct access to the clipboard. Please use the Ctrl+X/C/V keyboard shortcuts instead.");
                    n.mac && (a = a.replace(/Ctrl\+/g, "\u2318+")), r.windowManager.alert(a)
                }
            }, unlink: function () {
                if (_.isCollapsed()) {
                    var e = _.getNode();
                    return"A" == e.tagName && r.dom.remove(e, !0), void 0
                }
                k.remove("link")
            }, "JustifyLeft,JustifyCenter,JustifyRight,JustifyFull": function (e) {
                var t = e.substring(7);
                "full" == t && (t = "justify"), i("left,center,right,justify".split(","), function (e) {
                    t != e && k.remove("align" + e)
                }), b("align" + t), p("mceRepaint")
            }, "InsertUnorderedList,InsertOrderedList": function (e) {
                var t, n;
                v(e), t = w.getParent(_.getNode(), "ol,ul"), t && (n = t.parentNode, /^(H[1-6]|P|ADDRESS|PRE)$/.test(n.nodeName) && (C(), w.split(n, t), x()))
            }, "Bold,Italic,Underline,Strikethrough,Superscript,Subscript": function (e) {
                b(e)
            }, "ForeColor,HiliteColor,FontName": function (e, t, n) {
                b(e, n)
            }, FontSize: function (e, t, n) {
                var r, i;
                n >= 1 && 7 >= n && (i = l(E.font_size_style_values), r = l(E.font_size_classes), n = r ? r[n - 1] || n : i[n - 1] || n), b(e, n)
            }, RemoveFormat: function (e) {
                k.remove(e)
            }, mceBlockQuote: function () {
                b("blockquote")
            }, FormatBlock: function (e, t, n) {
                return b(n || "p")
            }, mceCleanup: function () {
                var e = _.getBookmark();
                r.setContent(r.getContent({cleanup: u}), {cleanup: u}), _.moveToBookmark(e)
            }, mceRemoveNode: function (e, t, n) {
                var i = n || _.getNode();
                i != r.getBody() && (C(), r.dom.remove(i, u), x())
            }, mceSelectNodeDepth: function (e, t, n) {
                var i = 0;
                w.getParent(_.getNode(), function (e) {
                    return 1 == e.nodeType && i++ == n ? (_.select(e), f) : void 0
                }, r.getBody())
            }, mceSelectNode: function (e, t, n) {
                _.select(n)
            }, mceInsertContent: function (t, n, i) {
                function o(e) {
                    function t(e) {
                        return r[e] && 3 == r[e].nodeType
                    }

                    var n, r, i;
                    return n = _.getRng(!0), r = n.startContainer, i = n.startOffset, 3 == r.nodeType && (i > 0 ? e = e.replace(/^&nbsp;/, " ") : t("previousSibling") || (e = e.replace(/^ /, "&nbsp;")), i < r.length ? e = e.replace(/&nbsp;(<br>|)$/, " ") : t("nextSibling") || (e = e.replace(/(&nbsp;| )(<br>|)$/, "&nbsp;"))), e
                }

                var a, s, l, c, u, f, p, m, h, g, v;
                /^ | $/.test(i) && (i = o(i)), a = r.parser, s = new e({}, r.schema), v = '<span id="mce_marker" data-mce-type="bookmark">&#xFEFF;&#200B;</span>', f = {content: i, format: "html", selection: !0}, r.fire("BeforeSetContent", f), i = f.content, -1 == i.indexOf("{$caret}") && (i += "{$caret}"), i = i.replace(/\{\$caret\}/, v), m = _.getRng();
                var y = m.startContainer || (m.parentElement ? m.parentElement() : null), b = r.getBody();
                y === b && _.isCollapsed() && w.isBlock(b.firstChild) && w.isEmpty(b.firstChild) && (m = w.createRng(), m.setStart(b.firstChild, 0), m.setEnd(b.firstChild, 0), _.setRng(m)), _.isCollapsed() || r.getDoc().execCommand("Delete", !1, null), l = _.getNode();
                var C = {context: l.nodeName.toLowerCase()};
                if (u = a.parse(i, C), h = u.lastChild, "mce_marker" == h.attr("id"))for (p = h, h = h.prev; h; h = h.walk(!0))if (3 == h.type || !w.isBlock(h.name)) {
                    h.parent.insert(p, h, "br" === h.name);
                    break
                }
                if (C.invalid) {
                    for (_.setContent(v), l = _.getNode(), c = r.getBody(), 9 == l.nodeType ? l = h = c : h = l; h !== c;)l = h, h = h.parentNode;
                    i = l == c ? c.innerHTML : w.getOuterHTML(l), i = s.serialize(a.parse(i.replace(/<span (id="mce_marker"|id=mce_marker).+?<\/span>/i, function () {
                        return s.serialize(u)
                    }))), l == c ? w.setHTML(c, i) : w.setOuterHTML(l, i)
                } else i = s.serialize(u), h = l.firstChild, g = l.lastChild, !h || h === g && "BR" === h.nodeName ? w.setHTML(l, i) : _.setContent(i);
                p = w.get("mce_marker"), _.scrollIntoView(p), m = w.createRng(), h = p.previousSibling, h && 3 == h.nodeType ? (m.setStart(h, h.nodeValue.length), d || (g = p.nextSibling, g && 3 == g.nodeType && (h.appendData(g.data), g.parentNode.removeChild(g)))) : (m.setStartBefore(p), m.setEndBefore(p)), w.remove(p), _.setRng(m), r.fire("SetContent", f), r.addVisual()
            }, mceInsertRawHTML: function (e, t, n) {
                _.setContent("tiny_mce_marker"), r.setContent(r.getContent().replace(/tiny_mce_marker/g, function () {
                    return n
                }))
            }, mceToggleFormat: function (e, t, n) {
                b(n)
            }, mceSetContent: function (e, t, n) {
                r.setContent(n)
            }, "Indent,Outdent": function (e) {
                var t, n, r;
                t = E.indentation, n = /[a-z%]+$/i.exec(t), t = parseInt(t, 10), m("InsertUnorderedList") || m("InsertOrderedList") ? v(e) : (E.forced_root_block || w.getParent(_.getNode(), w.isBlock) || k.apply("div"), i(_.getSelectedBlocks(), function (i) {
                    var o;
                    "LI" != i.nodeName && (o = "rtl" == w.getStyle(i, "direction", !0) ? "paddingRight" : "paddingLeft", "outdent" == e ? (r = Math.max(0, parseInt(i.style[o] || 0, 10) - t), w.setStyle(i, o, r ? r + n : "")) : (r = parseInt(i.style[o] || 0, 10) + t + n, w.setStyle(i, o, r)))
                }))
            }, mceRepaint: function () {
                if (c)try {
                    C(u), _.getSel() && _.getSel().selectAllChildren(r.getBody()), _.collapse(u), x()
                } catch (e) {
                }
            }, InsertHorizontalRule: function () {
                r.execCommand("mceInsertContent", !1, "<hr />")
            }, mceToggleVisualAid: function () {
                r.hasVisual = !r.hasVisual, r.addVisual()
            }, mceReplaceContent: function (e, t, n) {
                r.execCommand("mceInsertContent", !1, n.replace(/\{\$selection\}/g, _.getContent({format: "text"})))
            }, mceInsertLink: function (e, t, n) {
                var r;
                "string" == typeof n && (n = {href: n}), r = w.getParent(_.getNode(), "a"), n.href = n.href.replace(" ", "%20"), r && n.href || k.remove("link"), n.href && k.apply("link", n, r)
            }, selectAll: function () {
                var e = w.getRoot(), t;
                _.getRng().setStart ? (t = w.createRng(), t.setStart(e, 0), t.setEnd(e, e.childNodes.length), _.setRng(t)) : (t = _.getRng(), t.item || (t.moveToElementText(e), t.select()))
            }, "delete": function () {
                v("Delete");
                var e = r.getBody();
                w.isEmpty(e) && (r.setContent(""), e.firstChild && w.isBlock(e.firstChild) ? r.selection.setCursorLocation(e.firstChild, 0) : r.selection.setCursorLocation(e, 0))
            }, mceNewDocument: function () {
                r.setContent("")
            }}), g({"JustifyLeft,JustifyCenter,JustifyRight,JustifyFull": function (e) {
                var t = "align" + e.substring(7), n = _.isCollapsed() ? [w.getParent(_.getNode(), w.isBlock)] : _.getSelectedBlocks(), r = a(n, function (e) {
                    return!!k.matchNode(e, t)
                });
                return-1 !== s(r, u)
            }, "Bold,Italic,Underline,Strikethrough,Superscript,Subscript": function (e) {
                return y(e)
            }, mceBlockQuote: function () {
                return y("blockquote")
            }, Outdent: function () {
                var e;
                if (E.inline_styles) {
                    if ((e = w.getParent(_.getStart(), w.isBlock)) && parseInt(e.style.paddingLeft, 10) > 0)return u;
                    if ((e = w.getParent(_.getEnd(), w.isBlock)) && parseInt(e.style.paddingLeft, 10) > 0)return u
                }
                return m("InsertUnorderedList") || m("InsertOrderedList") || !E.inline_styles && !!w.getParent(_.getNode(), "BLOCKQUOTE")
            }, "InsertUnorderedList,InsertOrderedList": function (e) {
                var t = w.getParent(_.getNode(), "ul,ol");
                return t && ("insertunorderedlist" === e && "UL" === t.tagName || "insertorderedlist" === e && "OL" === t.tagName)
            }}, "state"), g({"FontSize,FontName": function (e) {
                var t = 0, n;
                return(n = w.getParent(_.getNode(), "span")) && (t = "fontsize" == e ? n.style.fontSize : n.style.fontFamily.replace(/, /g, ",").replace(/[\'\"]/g, "").toLowerCase()), t
            }}, "value"), g({Undo: function () {
                r.undoManager.undo()
            }, Redo: function () {
                r.undoManager.redo()
            }})
        }
    }), r(P, [f], function (e) {
        function t(e, i) {
            var o = this, a, s;
            if (e = r(e), i = o.settings = i || {}, /^([\w\-]+):([^\/]{2})/i.test(e) || /^\s*#/.test(e))return o.source = e, void 0;
            var l = 0 === e.indexOf("//");
            0 !== e.indexOf("/") || l || (e = (i.base_uri ? i.base_uri.protocol || "http" : "http") + "://mce_host" + e), /^[\w\-]*:?\/\//.test(e) || (s = i.base_uri ? i.base_uri.path : new t(location.href).directory, e = "" === i.base_uri.protocol ? "//mce_host" + o.toAbsPath(s, e) : (i.base_uri && i.base_uri.protocol || "http") + "://mce_host" + o.toAbsPath(s, e)), e = e.replace(/@@/g, "(mce_at)"), e = /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@\/]*):?([^:@\/]*))?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/.exec(e), n(["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"], function (t, n) {
                var r = e[n];
                r && (r = r.replace(/\(mce_at\)/g, "@@")), o[t] = r
            }), a = i.base_uri, a && (o.protocol || (o.protocol = a.protocol), o.userInfo || (o.userInfo = a.userInfo), o.port || "mce_host" !== o.host || (o.port = a.port), o.host && "mce_host" !== o.host || (o.host = a.host), o.source = ""), l && (o.protocol = "")
        }

        var n = e.each, r = e.trim;
        return t.prototype = {setPath: function (e) {
            var t = this;
            e = /^(.*?)\/?(\w+)?$/.exec(e), t.path = e[0], t.directory = e[1], t.file = e[2], t.source = "", t.getURI()
        }, toRelative: function (e) {
            var n = this, r;
            if ("./" === e)return e;
            if (e = new t(e, {base_uri: n}), "mce_host" != e.host && n.host != e.host && e.host || n.port != e.port || n.protocol != e.protocol && "" !== e.protocol)return e.getURI();
            var i = n.getURI(), o = e.getURI();
            return i == o || "/" == i.charAt(i.length - 1) && i.substr(0, i.length - 1) == o ? i : (r = n.toRelPath(n.path, e.path), e.query && (r += "?" + e.query), e.anchor && (r += "#" + e.anchor), r)
        }, toAbsolute: function (e, n) {
            return e = new t(e, {base_uri: this}), e.getURI(this.host == e.host && this.protocol == e.protocol ? n : 0)
        }, toRelPath: function (e, t) {
            var n, r = 0, i = "", o, a;
            if (e = e.substring(0, e.lastIndexOf("/")), e = e.split("/"), n = t.split("/"), e.length >= n.length)for (o = 0, a = e.length; a > o; o++)if (o >= n.length || e[o] != n[o]) {
                r = o + 1;
                break
            }
            if (e.length < n.length)for (o = 0, a = n.length; a > o; o++)if (o >= e.length || e[o] != n[o]) {
                r = o + 1;
                break
            }
            if (1 === r)return t;
            for (o = 0, a = e.length - (r - 1); a > o; o++)i += "../";
            for (o = r - 1, a = n.length; a > o; o++)i += o != r - 1 ? "/" + n[o] : n[o];
            return i
        }, toAbsPath: function (e, t) {
            var r, i = 0, o = [], a, s;
            for (a = /\/$/.test(t) ? "/" : "", e = e.split("/"), t = t.split("/"), n(e, function (e) {
                e && o.push(e)
            }), e = o, r = t.length - 1, o = []; r >= 0; r--)0 !== t[r].length && "." !== t[r] && (".." !== t[r] ? i > 0 ? i-- : o.push(t[r]) : i++);
            return r = e.length - i, s = 0 >= r ? o.reverse().join("/") : e.slice(0, r).join("/") + "/" + o.reverse().join("/"), 0 !== s.indexOf("/") && (s = "/" + s), a && s.lastIndexOf("/") !== s.length - 1 && (s += a), s
        }, getURI: function (e) {
            var t, n = this;
            return(!n.source || e) && (t = "", e || (t += n.protocol ? n.protocol + "://" : "//", n.userInfo && (t += n.userInfo + "@"), n.host && (t += n.host), n.port && (t += ":" + n.port)), n.path && (t += n.path), n.query && (t += "?" + n.query), n.anchor && (t += "#" + n.anchor), n.source = t), n.source
        }}, t
    }), r(O, [f], function (e) {
        function t() {
        }

        var n = e.each, r = e.extend, i, o;
        return t.extend = i = function (e) {
            function t() {
                var e, t, n, r;
                if (!o && (r = this, r.init && r.init.apply(r, arguments), t = r.Mixins))for (e = t.length; e--;)n = t[e], n.init && n.init.apply(r, arguments)
            }

            function a() {
                return this
            }

            function s(e, t) {
                return function () {
                    var n = this, r = n._super, i;
                    return n._super = c[e], i = t.apply(n, arguments), n._super = r, i
                }
            }

            var l = this, c = l.prototype, d, u, f;
            o = !0, d = new l, o = !1, e.Mixins && (n(e.Mixins, function (t) {
                t = t;
                for (var n in t)"init" !== n && (e[n] = t[n])
            }), c.Mixins && (e.Mixins = c.Mixins.concat(e.Mixins))), e.Methods && n(e.Methods.split(","), function (t) {
                e[t] = a
            }), e.Properties && n(e.Properties.split(","), function (t) {
                var n = "_" + t;
                e[t] = function (e) {
                    var t = this, r;
                    return e !== r ? (t[n] = e, t) : t[n]
                }
            }), e.Statics && n(e.Statics, function (e, n) {
                t[n] = e
            }), e.Defaults && c.Defaults && (e.Defaults = r({}, c.Defaults, e.Defaults));
            for (u in e)f = e[u], d[u] = "function" == typeof f && c[u] ? s(u, f) : f;
            return t.prototype = d, t.constructor = t, t.extend = i, t
        }, t
    }), r(I, [O], function (e) {
        function t(e) {
            for (var t = [], n = e.length, r; n--;)r = e[n], r.__checked || (t.push(r), r.__checked = 1);
            for (n = t.length; n--;)delete t[n].__checked;
            return t
        }

        var n = /^([\w\\*]+)?(?:#([\w\\]+))?(?:\.([\w\\\.]+))?(?:\[\@?([\w\\]+)([\^\$\*!~]?=)([\w\\]+)\])?(?:\:(.+))?/i, r = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g, i = /^\s*|\s*$/g, o, a = e.extend({init: function (e) {
            function t(e) {
                return e ? (e = e.toLowerCase(), function (t) {
                    return"*" === e || t.type === e
                }) : void 0
            }

            function o(e) {
                return e ? function (t) {
                    return t._name === e
                } : void 0
            }

            function a(e) {
                return e ? (e = e.split("."), function (t) {
                    for (var n = e.length; n--;)if (!t.hasClass(e[n]))return!1;
                    return!0
                }) : void 0
            }

            function s(e, t, n) {
                return e ? function (r) {
                    var i = r[e] ? r[e]() : "";
                    return t ? "=" === t ? i === n : "*=" === t ? i.indexOf(n) >= 0 : "~=" === t ? (" " + i + " ").indexOf(" " + n + " ") >= 0 : "!=" === t ? i != n : "^=" === t ? 0 === i.indexOf(n) : "$=" === t ? i.substr(i.length - n.length) === n : !1 : !!n
                } : void 0
            }

            function l(e) {
                var t;
                return e ? (e = /(?:not\((.+)\))|(.+)/i.exec(e), e[1] ? (t = d(e[1], []), function (e) {
                    return!u(e, t)
                }) : (e = e[2], function (t, n, r) {
                    return"first" === e ? 0 === n : "last" === e ? n === r - 1 : "even" === e ? n % 2 === 0 : "odd" === e ? n % 2 === 1 : t[e] ? t[e]() : !1
                })) : void 0
            }

            function c(e, r, c) {
                function d(e) {
                    e && r.push(e)
                }

                var u;
                return u = n.exec(e.replace(i, "")), d(t(u[1])), d(o(u[2])), d(a(u[3])), d(s(u[4], u[5], u[6])), d(l(u[7])), r.psuedo = !!u[7], r.direct = c, r
            }

            function d(e, t) {
                var n = [], i, o, a;
                do if (r.exec(""), o = r.exec(e), o && (e = o[3], n.push(o[1]), o[2])) {
                    i = o[3];
                    break
                } while (o);
                for (i && d(i, t), e = [], a = 0; a < n.length; a++)">" != n[a] && e.push(c(n[a], [], ">" === n[a - 1]));
                return t.push(e), t
            }

            var u = this.match;
            this._selectors = d(e, [])
        }, match: function (e, t) {
            var n, r, i, o, a, s, l, c, d, u, f, p, m;
            for (t = t || this._selectors, n = 0, r = t.length; r > n; n++) {
                for (a = t[n], o = a.length, m = e, p = 0, i = o - 1; i >= 0; i--)for (c = a[i]; m;) {
                    if (c.psuedo)for (f = m.parent().items(), d = u = f.length; d-- && f[d] !== m;);
                    for (s = 0, l = c.length; l > s; s++)if (!c[s](m, d, u)) {
                        s = l + 1;
                        break
                    }
                    if (s === l) {
                        p++;
                        break
                    }
                    if (i === o - 1)break;
                    m = m.parent()
                }
                if (p === o)return!0
            }
            return!1
        }, find: function (e) {
            function n(e, t, i) {
                var o, a, s, l, c, d = t[i];
                for (o = 0, a = e.length; a > o; o++) {
                    for (c = e[o], s = 0, l = d.length; l > s; s++)if (!d[s](c, o, a)) {
                        s = l + 1;
                        break
                    }
                    if (s === l)i == t.length - 1 ? r.push(c) : c.items && n(c.items(), t, i + 1); else if (d.direct)return;
                    c.items && n(c.items(), t, i)
                }
            }

            var r = [], i, s, l = this._selectors;
            if (e.items) {
                for (i = 0, s = l.length; s > i; i++)n(e.items(), l[i], 0);
                s > 1 && (r = t(r))
            }
            return o || (o = a.Collection), new o(r)
        }});
        return a
    }), r(F, [f, I, O], function (e, t, n) {
        var r, i, o = Array.prototype.push, a = Array.prototype.slice;
        return i = {length: 0, init: function (e) {
            e && this.add(e)
        }, add: function (t) {
            var n = this;
            return e.isArray(t) ? o.apply(n, t) : t instanceof r ? n.add(t.toArray()) : o.call(n, t), n
        }, set: function (e) {
            var t = this, n = t.length, r;
            for (t.length = 0, t.add(e), r = t.length; n > r; r++)delete t[r];
            return t
        }, filter: function (e) {
            var n = this, i, o, a = [], s, l;
            for ("string" == typeof e ? (e = new t(e), l = function (t) {
                return e.match(t)
            }) : l = e, i = 0, o = n.length; o > i; i++)s = n[i], l(s) && a.push(s);
            return new r(a)
        }, slice: function () {
            return new r(a.apply(this, arguments))
        }, eq: function (e) {
            return-1 === e ? this.slice(e) : this.slice(e, +e + 1)
        }, each: function (t) {
            return e.each(this, t), this
        }, toArray: function () {
            return e.toArray(this)
        }, indexOf: function (e) {
            for (var t = this, n = t.length; n-- && t[n] !== e;);
            return n
        }, reverse: function () {
            return new r(e.toArray(this).reverse())
        }, hasClass: function (e) {
            return this[0] ? this[0].hasClass(e) : !1
        }, prop: function (e, t) {
            var n = this, r, i;
            return t !== r ? (n.each(function (n) {
                n[e] && n[e](t)
            }), n) : (i = n[0], i && i[e] ? i[e]() : void 0)
        }, exec: function (t) {
            var n = this, r = e.toArray(arguments).slice(1);
            return n.each(function (e) {
                e[t] && e[t].apply(e, r)
            }), n
        }, remove: function () {
            for (var e = this.length; e--;)this[e].remove();
            return this
        }}, e.each("fire on off show hide addClass removeClass append prepend before after reflow".split(" "), function (t) {
            i[t] = function () {
                var n = e.toArray(arguments);
                return this.each(function (e) {
                    t in e && e[t].apply(e, n)
                }), this
            }
        }), e.each("text name disabled active selected checked visible parent value data".split(" "), function (e) {
            i[e] = function (t) {
                return this.prop(e, t)
            }
        }), r = n.extend(i), t.Collection = r, r
    }), r(z, [f, g], function (e, t) {
        return{id: function () {
            return t.DOM.uniqueId()
        }, createFragment: function (e) {
            return t.DOM.createFragment(e)
        }, getWindowSize: function () {
            return t.DOM.getViewPort()
        }, getSize: function (e) {
            var t, n;
            if (e.getBoundingClientRect) {
                var r = e.getBoundingClientRect();
                t = Math.max(r.width || r.right - r.left, e.offsetWidth), n = Math.max(r.height || r.bottom - r.bottom, e.offsetHeight)
            } else t = e.offsetWidth, n = e.offsetHeight;
            return{width: t, height: n}
        }, getPos: function (e, n) {
            return t.DOM.getPos(e, n)
        }, getViewPort: function (e) {
            return t.DOM.getViewPort(e)
        }, get: function (e) {
            return document.getElementById(e)
        }, addClass: function (e, n) {
            return t.DOM.addClass(e, n)
        }, removeClass: function (e, n) {
            return t.DOM.removeClass(e, n)
        }, hasClass: function (e, n) {
            return t.DOM.hasClass(e, n)
        }, toggleClass: function (e, n, r) {
            return t.DOM.toggleClass(e, n, r)
        }, css: function (e, n, r) {
            return t.DOM.setStyle(e, n, r)
        }, on: function (e, n, r, i) {
            return t.DOM.bind(e, n, r, i)
        }, off: function (e, n, r) {
            return t.DOM.unbind(e, n, r)
        }, fire: function (e, n, r) {
            return t.DOM.fire(e, n, r)
        }, innerHtml: function (e, n) {
            t.DOM.setHTML(e, n)
        }}
    }), r(W, [O, f, F, z], function (e, t, n, r) {
        var i = t.makeMap("focusin focusout scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave wheel keydown keypress keyup contextmenu", " "), o = {}, a = "onmousewheel"in document, s = !1, l = e.extend({Statics: {controlIdLookup: {}, elementIdCache: o}, isRtl: function () {
            return l.rtl
        }, classPrefix: "mce-", init: function (e) {
            var n = this, i, o;
            if (n.settings = e = t.extend({}, n.Defaults, e), n._id = r.id(), n._text = n._name = "", n._width = n._height = 0, n._aria = {role: e.role}, i = e.classes)for (i = i.split(" "), i.map = {}, o = i.length; o--;)i.map[i[o]] = !0;
            n._classes = i || [], n.visible(!0), t.each("title text width height name classes visible disabled active value".split(" "), function (t) {
                var r = e[t], i;
                r !== i ? n[t](r) : n["_" + t] === i && (n["_" + t] = !1)
            }), n.on("click", function () {
                return n.disabled() ? !1 : void 0
            }), e.classes && t.each(e.classes.split(" "), function (e) {
                n.addClass(e)
            }), n.settings = e, n._borderBox = n.parseBox(e.border), n._paddingBox = n.parseBox(e.padding), n._marginBox = n.parseBox(e.margin), e.hidden && n.hide()
        }, Properties: "parent,title,text,width,height,disabled,active,name,value", Methods: "renderHtml", getContainerElm: function () {
            return document.body
        }, getParentCtrl: function (e) {
            for (var t; e && !(t = l.controlIdLookup[e.id]);)e = e.parentNode;
            return t
        }, parseBox: function (e) {
            var t, n = 10;
            if (e)return"number" == typeof e ? (e = e || 0, {top: e, left: e, bottom: e, right: e}) : (e = e.split(" "), t = e.length, 1 === t ? e[1] = e[2] = e[3] = e[0] : 2 === t ? (e[2] = e[0], e[3] = e[1]) : 3 === t && (e[3] = e[1]), {top: parseInt(e[0], n) || 0, right: parseInt(e[1], n) || 0, bottom: parseInt(e[2], n) || 0, left: parseInt(e[3], n) || 0})
        }, borderBox: function () {
            return this._borderBox
        }, paddingBox: function () {
            return this._paddingBox
        }, marginBox: function () {
            return this._marginBox
        }, measureBox: function (e, t) {
            function n(t) {
                var n = document.defaultView;
                return n ? (t = t.replace(/[A-Z]/g, function (e) {
                    return"-" + e
                }), n.getComputedStyle(e, null).getPropertyValue(t)) : e.currentStyle[t]
            }

            function r(e) {
                var t = parseFloat(n(e), 10);
                return isNaN(t) ? 0 : t
            }

            return{top: r(t + "TopWidth"), right: r(t + "RightWidth"), bottom: r(t + "BottomWidth"), left: r(t + "LeftWidth")}
        }, initLayoutRect: function () {
            var e = this, t = e.settings, n, i, o = e.getEl(), a, s, l, c, d, u, f, p;
            n = e._borderBox = e._borderBox || e.measureBox(o, "border"), e._paddingBox = e._paddingBox || e.measureBox(o, "padding"), e._marginBox = e._marginBox || e.measureBox(o, "margin"), p = r.getSize(o), u = t.minWidth, f = t.minHeight, l = u || p.width, c = f || p.height, a = t.width, s = t.height, d = t.autoResize, d = "undefined" != typeof d ? d : !a && !s, a = a || l, s = s || c;
            var m = n.left + n.right, h = n.top + n.bottom, g = t.maxWidth || 65535, v = t.maxHeight || 65535;
            return e._layoutRect = i = {x: t.x || 0, y: t.y || 0, w: a, h: s, deltaW: m, deltaH: h, contentW: a - m, contentH: s - h, innerW: a - m, innerH: s - h, startMinWidth: u || 0, startMinHeight: f || 0, minW: Math.min(l, g), minH: Math.min(c, v), maxW: g, maxH: v, autoResize: d, scrollW: 0}, e._lastLayoutRect = {}, i
        }, layoutRect: function (e) {
            var t = this, n = t._layoutRect, r, i, o, a, s, c;
            return n || (n = t.initLayoutRect()), e ? (o = n.deltaW, a = n.deltaH, e.x !== s && (n.x = e.x), e.y !== s && (n.y = e.y), e.minW !== s && (n.minW = e.minW), e.minH !== s && (n.minH = e.minH), i = e.w, i !== s && (i = i < n.minW ? n.minW : i, i = i > n.maxW ? n.maxW : i, n.w = i, n.innerW = i - o), i = e.h, i !== s && (i = i < n.minH ? n.minH : i, i = i > n.maxH ? n.maxH : i, n.h = i, n.innerH = i - a), i = e.innerW, i !== s && (i = i < n.minW - o ? n.minW - o : i, i = i > n.maxW - o ? n.maxW - o : i, n.innerW = i, n.w = i + o), i = e.innerH, i !== s && (i = i < n.minH - a ? n.minH - a : i, i = i > n.maxH - a ? n.maxH - a : i, n.innerH = i, n.h = i + a), e.contentW !== s && (n.contentW = e.contentW), e.contentH !== s && (n.contentH = e.contentH), r = t._lastLayoutRect, (r.x !== n.x || r.y !== n.y || r.w !== n.w || r.h !== n.h) && (c = l.repaintControls, c && c.map && !c.map[t._id] && (c.push(t), c.map[t._id] = !0), r.x = n.x, r.y = n.y, r.w = n.w, r.h = n.h), t) : n
        }, repaint: function () {
            var e = this, t, n, r, i, o = 0, a = 0, s, l;
            l = document.createRange ? function (e) {
                return e
            } : Math.round, t = e.getEl().style, r = e._layoutRect, s = e._lastRepaintRect || {}, i = e._borderBox, o = i.left + i.right, a = i.top + i.bottom, r.x !== s.x && (t.left = l(r.x) + "px", s.x = r.x), r.y !== s.y && (t.top = l(r.y) + "px", s.y = r.y), r.w !== s.w && (t.width = l(r.w - o) + "px", s.w = r.w), r.h !== s.h && (t.height = l(r.h - a) + "px", s.h = r.h), e._hasBody && r.innerW !== s.innerW && (n = e.getEl("body").style, n.width = l(r.innerW) + "px", s.innerW = r.innerW), e._hasBody && r.innerH !== s.innerH && (n = n || e.getEl("body").style, n.height = l(r.innerH) + "px", s.innerH = r.innerH), e._lastRepaintRect = s, e.fire("repaint", {}, !1)
        }, on: function (e, t) {
            function n(e) {
                var t, n;
                return function (i) {
                    return t || r.parents().each(function (r) {
                        var i = r.settings.callbacks;
                        return i && (t = i[e]) ? (n = r, !1) : void 0
                    }), t.call(n, i)
                }
            }

            var r = this, o, a, s, l;
            if (t)for ("string" == typeof t && (t = n(t)), s = e.toLowerCase().split(" "), l = s.length; l--;)e = s[l], o = r._bindings, o || (o = r._bindings = {}), a = o[e], a || (a = o[e] = []), a.push(t), i[e] && (r._nativeEvents ? r._nativeEvents[e] = !0 : r._nativeEvents = {name: !0}, r._rendered && r.bindPendingEvents());
            return r
        }, off: function (e, t) {
            var n = this, r, i = n._bindings, o, a, s, l;
            if (i)if (e)for (s = e.toLowerCase().split(" "), r = s.length; r--;) {
                if (e = s[r], o = i[e], !e) {
                    for (a in i)i[a].length = 0;
                    return n
                }
                if (o)if (t)for (l = o.length; l--;)o[l] === t && o.splice(l, 1); else o.length = 0
            } else n._bindings = [];
            return n
        }, fire: function (e, t, n) {
            function r() {
                return!1
            }

            function i() {
                return!0
            }

            var o = this, a, s, l, c;
            if (e = e.toLowerCase(), t = t || {}, t.type || (t.type = e), t.control || (t.control = o), t.preventDefault || (t.preventDefault = function () {
                t.isDefaultPrevented = i
            }, t.stopPropagation = function () {
                t.isPropagationStopped = i
            }, t.stopImmediatePropagation = function () {
                t.isImmediatePropagationStopped = i
            }, t.isDefaultPrevented = r, t.isPropagationStopped = r, t.isImmediatePropagationStopped = r), o._bindings && (l = o._bindings[e]))for (a = 0, s = l.length; s > a && (t.isImmediatePropagationStopped() || l[a].call(o, t) !== !1); a++);
            if (n !== !1)for (c = o.parent(); c && !t.isPropagationStopped();)c.fire(e, t, !1), c = c.parent();
            return t
        }, hasEventListeners: function (e) {
            return e in this._bindings
        }, parents: function (e) {
            var t = this, r = new n;
            for (t = t.parent(); t; t = t.parent())r.add(t);
            return e && (r = r.filter(e)), r
        }, next: function () {
            var e = this.parent().items();
            return e[e.indexOf(this) + 1]
        }, prev: function () {
            var e = this.parent().items();
            return e[e.indexOf(this) - 1]
        }, findCommonAncestor: function (e, t) {
            for (var n; e;) {
                for (n = t; n && e != n;)n = n.parent();
                if (e == n)break;
                e = e.parent()
            }
            return e
        }, hasClass: function (e, t) {
            var n = this._classes[t || "control"];
            return e = this.classPrefix + e, n && !!n.map[e]
        }, addClass: function (e, t) {
            var n = this, r, i;
            return e = this.classPrefix + e, r = n._classes[t || "control"], r || (r = [], r.map = {}, n._classes[t || "control"] = r), r.map[e] || (r.map[e] = e, r.push(e), n._rendered && (i = n.getEl(t), i && (i.className = r.join(" ")))), n
        }, removeClass: function (e, t) {
            var n = this, r, i, o;
            if (e = this.classPrefix + e, r = n._classes[t || "control"], r && r.map[e])for (delete r.map[e], i = r.length; i--;)r[i] === e && r.splice(i, 1);
            return n._rendered && (o = n.getEl(t), o && (o.className = r.join(" "))), n
        }, toggleClass: function (e, t, n) {
            var r = this;
            return t ? r.addClass(e, n) : r.removeClass(e, n), r
        }, classes: function (e) {
            var t = this._classes[e || "control"];
            return t ? t.join(" ") : ""
        }, innerHtml: function (e) {
            return r.innerHtml(this.getEl(), e), this
        }, getEl: function (e, t) {
            var n, i = e ? this._id + "-" + e : this._id;
            return n = o[i] = (t === !0 ? null : o[i]) || r.get(i)
        }, visible: function (e) {
            var t = this, n;
            return"undefined" != typeof e ? (t._visible !== e && (t._rendered && (t.getEl().style.display = e ? "" : "none"), t._visible = e, n = t.parent(), n && (n._lastRect = null), t.fire(e ? "show" : "hide")), t) : t._visible
        }, show: function () {
            return this.visible(!0)
        }, hide: function () {
            return this.visible(!1)
        }, focus: function () {
            try {
                this.getEl().focus()
            } catch (e) {
            }
            return this
        }, blur: function () {
            return this.getEl().blur(), this
        }, aria: function (e, t) {
            var n = this, r = n.getEl();
            return"undefined" == typeof t ? n._aria[e] : (n._aria[e] = t, n._rendered && ("label" == e && r.setAttribute("aria-labeledby", n._id), r.setAttribute("role" == e ? e : "aria-" + e, t)), n)
        }, encode: function (e, t) {
            return t !== !1 && l.translate && (e = l.translate(e)), (e || "").replace(/[&<>"]/g, function (e) {
                return"&#" + e.charCodeAt(0) + ";"
            })
        }, before: function (e) {
            var t = this, n = t.parent();
            return n && n.insert(e, n.items().indexOf(t), !0), t
        }, after: function (e) {
            var t = this, n = t.parent();
            return n && n.insert(e, n.items().indexOf(t)), t
        }, remove: function () {
            var e = this, t = e.getEl(), n = e.parent(), i, a;
            if (e.items) {
                var s = e.items().toArray();
                for (a = s.length; a--;)s[a].remove()
            }
            if (n && n.items && (i = [], n.items().each(function (t) {
                t !== e && i.push(t)
            }), n.items().set(i), n._lastRect = null), e._eventsRoot && e._eventsRoot == e && r.off(t), delete l.controlIdLookup[e._id], delete o[e._id], t && t.parentNode) {
                var c = t.getElementsByTagName("*");
                for (a = c.length; a--;)delete o[c[a].id];
                t.parentNode.removeChild(t)
            }
            return e
        }, renderBefore: function (e) {
            var t = this;
            return e.parentNode.insertBefore(r.createFragment(t.renderHtml()), e), t.postRender(), t
        }, renderTo: function (e) {
            var t = this;
            return e = e || t.getContainerElm(), e.appendChild(r.createFragment(t.renderHtml())), t.postRender(), t
        }, postRender: function () {
            var e = this, t = e.settings, n, i, o, a, s;
            for (a in t)0 === a.indexOf("on") && e.on(a.substr(2), t[a]);
            if (e._eventsRoot) {
                for (o = e.parent(); !s && o; o = o.parent())s = o._eventsRoot;
                if (s)for (a in s._nativeEvents)e._nativeEvents[a] = !0
            }
            e.bindPendingEvents(), t.style && (n = e.getEl(), n && (n.setAttribute("style", t.style), n.style.cssText = t.style)), e._visible || r.css(e.getEl(), "display", "none"), e.settings.border && (i = e.borderBox(), r.css(e.getEl(), {"border-top-width": i.top, "border-right-width": i.right, "border-bottom-width": i.bottom, "border-left-width": i.left})), l.controlIdLookup[e._id] = e;
            for (var c in e._aria)e.aria(c, e._aria[c]);
            e.fire("postrender", {}, !1)
        }, scrollIntoView: function (e) {
            function t(e, t) {
                var n, r, i = e;
                for (n = r = 0; i && i != t && i.nodeType;)n += i.offsetLeft || 0, r += i.offsetTop || 0, i = i.offsetParent;
                return{x: n, y: r}
            }

            var n = this.getEl(), r = n.parentNode, i, o, a, s, l, c, d = t(n, r);
            return i = d.x, o = d.y, a = n.offsetWidth, s = n.offsetHeight, l = r.clientWidth, c = r.clientHeight, "end" == e ? (i -= l - a, o -= c - s) : "center" == e && (i -= l / 2 - a / 2, o -= c / 2 - s / 2), r.scrollLeft = i, r.scrollTop = o, this
        }, bindPendingEvents: function () {
            function e(e) {
                var t = o.getParentCtrl(e.target);
                t && t.fire(e.type, e)
            }

            function t() {
                var e = u._lastHoverCtrl;
                e && (e.fire("mouseleave", {target: e.getEl()}), e.parents().each(function (e) {
                    e.fire("mouseleave", {target: e.getEl()})
                }), u._lastHoverCtrl = null)
            }

            function n(e) {
                var t = o.getParentCtrl(e.target), n = u._lastHoverCtrl, r = 0, i, a, s;
                if (t !== n) {
                    if (u._lastHoverCtrl = t, a = t.parents().toArray().reverse(), a.push(t), n) {
                        for (s = n.parents().toArray().reverse(), s.push(n), r = 0; r < s.length && a[r] === s[r]; r++);
                        for (i = s.length - 1; i >= r; i--)n = s[i], n.fire("mouseleave", {target: n.getEl()})
                    }
                    for (i = r; i < a.length; i++)t = a[i], t.fire("mouseenter", {target: t.getEl()})
                }
            }

            function i(e) {
                e.preventDefault(), "mousewheel" == e.type ? (e.deltaY = -1 / 40 * e.wheelDelta, e.wheelDeltaX && (e.deltaX = -1 / 40 * e.wheelDeltaX)) : (e.deltaX = 0, e.deltaY = e.detail), e = o.fire("wheel", e)
            }

            var o = this, l, c, d, u, f, p;
            if (o._rendered = !0, f = o._nativeEvents) {
                for (d = o.parents().toArray(), d.unshift(o), l = 0, c = d.length; !u && c > l; l++)u = d[l]._eventsRoot;
                for (u || (u = d[d.length - 1] || o), o._eventsRoot = u, c = l, l = 0; c > l; l++)d[l]._eventsRoot = u;
                for (p in f) {
                    if (!f)return!1;
                    "wheel" !== p || s ? ("mouseenter" === p || "mouseleave" === p ? u._hasMouseEnter || (r.on(u.getEl(), "mouseleave", t), r.on(u.getEl(), "mouseover", n), u._hasMouseEnter = 1) : u[p] || (r.on(u.getEl(), p, e), u[p] = !0), f[p] = !1) : a ? r.on(o.getEl(), "mousewheel", i) : r.on(o.getEl(), "DOMMouseScroll", i)
                }
            }
        }, reflow: function () {
            return this.repaint(), this
        }});
        return l
    }), r(V, [], function () {
        var e = {}, t;
        return{add: function (t, n) {
            e[t.toLowerCase()] = n
        }, has: function (t) {
            return!!e[t.toLowerCase()]
        }, create: function (n, r) {
            var i, o, a;
            if (!t) {
                a = tinymce.ui;
                for (o in a)e[o.toLowerCase()] = a[o];
                t = !0
            }
            if ("string" == typeof n ? (r = r || {}, r.type = n) : (r = n, n = r.type), n = n.toLowerCase(), i = e[n], !i)throw new Error("Could not find control by type: " + n);
            return i = new i(r), i.type = n, i
        }}
    }), r(U, [W, F, I, V, f, z], function (e, t, n, r, i, o) {
        var a = {};
        return e.extend({layout: "", innerClass: "container-inner", init: function (e) {
            var n = this;
            n._super(e), e = n.settings, n._fixed = e.fixed, n._items = new t, n.isRtl() && n.addClass("rtl"), n.addClass("container"), n.addClass("container-body", "body"), e.containerCls && n.addClass(e.containerCls), n._layout = r.create((e.layout || n.layout) + "layout"), n.settings.items && n.add(n.settings.items), n._hasBody = !0
        }, items: function () {
            return this._items
        }, find: function (e) {
            return e = a[e] = a[e] || new n(e), e.find(this)
        }, add: function (e) {
            var t = this;
            return t.items().add(t.create(e)).parent(t), t
        }, focus: function () {
            var e = this;
            return e.keyNav ? e.keyNav.focusFirst() : e._super(), e
        }, replace: function (e, t) {
            for (var n, r = this.items(), i = r.length; i--;)if (r[i] === e) {
                r[i] = t;
                break
            }
            i >= 0 && (n = t.getEl(), n && n.parentNode.removeChild(n), n = e.getEl(), n && n.parentNode.removeChild(n)), t.parent(this)
        }, create: function (t) {
            var n = this, o, a = [];
            return i.isArray(t) || (t = [t]), i.each(t, function (t) {
                t && (t instanceof e || ("string" == typeof t && (t = {type: t}), o = i.extend({}, n.settings.defaults, t), t.type = o.type = o.type || t.type || n.settings.defaultType || (o.defaults ? o.defaults.type : null), t = r.create(o)), a.push(t))
            }), a
        }, renderNew: function () {
            var e = this;
            return e.items().each(function (t, n) {
                var r, i;
                t.parent(e), t._rendered || (r = e.getEl("body"), i = o.createFragment(t.renderHtml()), r.hasChildNodes() && n <= r.childNodes.length - 1 ? r.insertBefore(i, r.childNodes[n]) : r.appendChild(i), t.postRender())
            }), e._layout.applyClasses(e), e._lastRect = null, e
        }, append: function (e) {
            return this.add(e).renderNew()
        }, prepend: function (e) {
            var t = this;
            return t.items().set(t.create(e).concat(t.items().toArray())), t.renderNew()
        }, insert: function (e, t, n) {
            var r = this, i, o, a;
            return e = r.create(e), i = r.items(), !n && t < i.length - 1 && (t += 1), t >= 0 && t < i.length && (o = i.slice(0, t).toArray(), a = i.slice(t).toArray(), i.set(o.concat(e, a))), r.renderNew()
        }, fromJSON: function (e) {
            var t = this;
            for (var n in e)t.find("#" + n).value(e[n]);
            return t
        }, toJSON: function () {
            var e = this, t = {};
            return e.find("*").each(function (e) {
                var n = e.name(), r = e.value();
                n && "undefined" != typeof r && (t[n] = r)
            }), t
        }, preRender: function () {
        }, renderHtml: function () {
            var e = this, t = e._layout;
            return e.preRender(), t.preRender(e), '<div id="' + e._id + '" class="' + e.classes() + '" role="' + this.settings.role + '"><div id="' + e._id + '-body" class="' + e.classes("body") + '">' + (e.settings.html || "") + t.renderHtml(e) + "</div></div>"
        }, postRender: function () {
            var e = this, t;
            return e.items().exec("postRender"), e._super(), e._layout.postRender(e), e._rendered = !0, e.settings.style && o.css(e.getEl(), e.settings.style), e.settings.border && (t = e.borderBox(), o.css(e.getEl(), {"border-top-width": t.top, "border-right-width": t.right, "border-bottom-width": t.bottom, "border-left-width": t.left})), e
        }, initLayoutRect: function () {
            var e = this, t = e._super();
            return e._layout.recalc(e), t
        }, recalc: function () {
            var e = this, t = e._layoutRect, n = e._lastRect;
            return n && n.w == t.w && n.h == t.h ? void 0 : (e._layout.recalc(e), t = e.layoutRect(), e._lastRect = {x: t.x, y: t.y, w: t.w, h: t.h}, !0)
        }, reflow: function () {
            var t, n;
            if (this.visible()) {
                for (e.repaintControls = [], e.repaintControls.map = {}, n = this.recalc(), t = e.repaintControls.length; t--;)e.repaintControls[t].repaint();
                "flow" !== this.settings.layout && "stack" !== this.settings.layout && this.repaint(), e.repaintControls = []
            }
            return this
        }})
    }), r(q, [z], function (e) {
        function t() {
            var e = document, t, n, r, i, o, a, s, l, c = Math.max;
            return t = e.documentElement, n = e.body, r = c(t.scrollWidth, n.scrollWidth), i = c(t.clientWidth, n.clientWidth), o = c(t.offsetWidth, n.offsetWidth), a = c(t.scrollHeight, n.scrollHeight), s = c(t.clientHeight, n.clientHeight), l = c(t.offsetHeight, n.offsetHeight), {width: o > r ? i : r, height: l > a ? s : a}
        }

        return function (n, r) {
            function i() {
                return a.getElementById(r.handle || n)
            }

            var o, a = document, s, l, c, d, u, f;
            r = r || {}, l = function (n) {
                var l = t(), p, m;
                n.preventDefault(), s = n.button, p = i(), u = n.screenX, f = n.screenY, m = window.getComputedStyle ? window.getComputedStyle(p, null).getPropertyValue("cursor") : p.runtimeStyle.cursor, o = a.createElement("div"), e.css(o, {position: "absolute", top: 0, left: 0, width: l.width, height: l.height, zIndex: 2147483647, opacity: 1e-4, background: "red", cursor: m}), a.body.appendChild(o), e.on(a, "mousemove", d), e.on(a, "mouseup", c), r.start(n)
            }, d = function (e) {
                return e.button !== s ? c(e) : (e.deltaX = e.screenX - u, e.deltaY = e.screenY - f, e.preventDefault(), r.drag(e), void 0)
            }, c = function (t) {
                e.off(a, "mousemove", d), e.off(a, "mouseup", c), o.parentNode.removeChild(o), r.stop && r.stop(t)
            }, this.destroy = function () {
                e.off(i())
            }, e.on(i(), "mousedown", l)
        }
    }), r(j, [z, q], function (e, t) {
        return{init: function () {
            var e = this;
            e.on("repaint", e.renderScroll)
        }, renderScroll: function () {
            function n() {
                function t(t, a, s, l, c, d) {
                    var u, f, p, m, h, g, v, y, b;
                    if (f = i.getEl("scroll" + t)) {
                        if (y = a.toLowerCase(), b = s.toLowerCase(), i.getEl("absend") && e.css(i.getEl("absend"), y, i.layoutRect()[l] - 1), !c)return e.css(f, "display", "none"), void 0;
                        e.css(f, "display", "block"), u = i.getEl("body"), p = i.getEl("scroll" + t + "t"), m = u["client" + s] - 2 * o, m -= n && r ? f["client" + d] : 0, h = u["scroll" + s], g = m / h, v = {}, v[y] = u["offset" + a] + o, v[b] = m, e.css(f, v), v = {}, v[y] = u["scroll" + a] * g, v[b] = m * g, e.css(p, v)
                    }
                }

                var n, r, a;
                a = i.getEl("body"), n = a.scrollWidth > a.clientWidth, r = a.scrollHeight > a.clientHeight, t("h", "Left", "Width", "contentW", n, "Height"), t("v", "Top", "Height", "contentH", r, "Width")
            }

            function r() {
                function n(n, r, a, s, l) {
                    var c, d = i._id + "-scroll" + n, u = i.classPrefix;
                    i.getEl().appendChild(e.createFragment('<div id="' + d + '" class="' + u + "scrollbar " + u + "scrollbar-" + n + '"><div id="' + d + 't" class="' + u + 'scrollbar-thumb"></div></div>')), i.draghelper = new t(d + "t", {start: function () {
                        c = i.getEl("body")["scroll" + r], e.addClass(e.get(d), u + "active")
                    }, drag: function (e) {
                        var t, d, u, f, p = i.layoutRect();
                        d = p.contentW > p.innerW, u = p.contentH > p.innerH, f = i.getEl("body")["client" + a] - 2 * o, f -= d && u ? i.getEl("scroll" + n)["client" + l] : 0, t = f / i.getEl("body")["scroll" + a], i.getEl("body")["scroll" + r] = c + e["delta" + s] / t
                    }, stop: function () {
                        e.removeClass(e.get(d), u + "active")
                    }})
                }

                i.addClass("scroll"), n("v", "Top", "Height", "Y", "Width"), n("h", "Left", "Width", "X", "Height")
            }

            var i = this, o = 2;
            i.settings.autoScroll && (i._hasScroll || (i._hasScroll = !0, r(), i.on("wheel", function (e) {
                var t = i.getEl("body");
                t.scrollLeft += 10 * (e.deltaX || 0), t.scrollTop += 10 * e.deltaY, n()
            }), e.on(i.getEl("body"), "scroll", n)), n())
        }}
    }), r($, [U, j], function (e, t) {
        return e.extend({Defaults: {layout: "fit", containerCls: "panel"}, Mixins: [t], renderHtml: function () {
            var e = this, t = e._layout, n = e.settings.html;
            return e.preRender(), t.preRender(e), "undefined" == typeof n ? n = '<div id="' + e._id + '-body" class="' + e.classes("body") + '">' + t.renderHtml(e) + "</div>" : ("function" == typeof n && (n = n.call(e)), e._hasBody = !1), '<div id="' + e._id + '" class="' + e.classes() + '" hideFocus="1" tabIndex="-1">' + (e._preBodyHtml || "") + n + "</div>"
        }})
    }), r(K, [z], function (e) {
        function t(t, n, r) {
            var i, o, a, s, l, c, d, u, f, p;
            return f = e.getViewPort(), o = e.getPos(n), a = o.x, s = o.y, t._fixed && (a -= f.x, s -= f.y), i = t.getEl(), p = e.getSize(i), l = p.width, c = p.height, p = e.getSize(n), d = p.width, u = p.height, r = (r || "").split(""), "b" === r[0] && (s += u), "r" === r[1] && (a += d), "c" === r[0] && (s += Math.round(u / 2)), "c" === r[1] && (a += Math.round(d / 2)), "b" === r[3] && (s -= c), "r" === r[4] && (a -= l), "c" === r[3] && (s -= Math.round(c / 2)), "c" === r[4] && (a -= Math.round(l / 2)), {x: a, y: s, w: l, h: c}
        }

        return{testMoveRel: function (n, r) {
            for (var i = e.getViewPort(), o = 0; o < r.length; o++) {
                var a = t(this, n, r[o]);
                if (this._fixed) {
                    if (a.x > 0 && a.x + a.w < i.w && a.y > 0 && a.y + a.h < i.h)return r[o]
                } else if (a.x > i.x && a.x + a.w < i.w + i.x && a.y > i.y && a.y + a.h < i.h + i.y)return r[o]
            }
            return r[0]
        }, moveRel: function (e, n) {
            "string" != typeof n && (n = this.testMoveRel(e, n));
            var r = t(this, e, n);
            return this.moveTo(r.x, r.y)
        }, moveBy: function (e, t) {
            var n = this, r = n.layoutRect();
            return n.moveTo(r.x + e, r.y + t), n
        }, moveTo: function (t, n) {
            function r(e, t, n) {
                return 0 > e ? 0 : e + n > t ? (e = t - n, 0 > e ? 0 : e) : e
            }

            var i = this;
            if (i.settings.constrainToViewport) {
                var o = e.getViewPort(window), a = i.layoutRect();
                t = r(t, o.w + o.x, a.w), n = r(n, o.h + o.y, a.h)
            }
            return i._rendered ? i.layoutRect({x: t, y: n}).repaint() : (i.settings.x = t, i.settings.y = n), i.fire("move", {x: t, y: n}), i
        }}
    }), r(Y, [z], function (e) {
        return{resizeToContent: function () {
            this._layoutRect.autoResize = !0, this._lastRect = null, this.reflow()
        }, resizeTo: function (t, n) {
            if (1 >= t || 1 >= n) {
                var r = e.getWindowSize();
                t = 1 >= t ? t * r.w : t, n = 1 >= n ? n * r.h : n
            }
            return this._layoutRect.autoResize = !1, this.layoutRect({minW: t, minH: n, w: t, h: n}).reflow()
        }, resizeBy: function (e, t) {
            var n = this, r = n.layoutRect();
            return n.resizeTo(r.w + e, r.h + t)
        }}
    }), r(G, [$, K, Y, z], function (e, t, n, r) {
        function i(e) {
            var t;
            for (t = s.length; t--;)s[t] === e && s.splice(t, 1);
            for (t = l.length; t--;)l[t] === e && l.splice(t, 1)
        }

        var o, a, s = [], l = [], c, d = e.extend({Mixins: [t, n], init: function (e) {
            function t() {
                var e, t = d.zIndex || 65535, n;
                if (l.length)for (e = 0; e < l.length; e++)l[e].modal && (t++, n = l[e]), l[e].getEl().style.zIndex = t, l[e].zIndex = t, t++;
                var i = document.getElementById(u.classPrefix + "modal-block");
                n ? r.css(i, "z-index", n.zIndex - 1) : i && (i.parentNode.removeChild(i), c = !1), d.currentZIndex = t
            }

            function n(e, t) {
                for (; e;) {
                    if (e == t)return!0;
                    e = e.parent()
                }
            }

            function i(e) {
                function t(t, n) {
                    for (var r, i = 0; i < s.length; i++)if (s[i] != e)for (r = s[i].parent(); r && (r = r.parent());)r == e && s[i].fixed(t).moveBy(0, n).repaint()
                }

                var n = r.getViewPort().y;
                e.settings.autofix && (e._fixed ? e._autoFixY > n && (e.fixed(!1).layoutRect({y: e._autoFixY}).repaint(), t(!1, e._autoFixY - n)) : (e._autoFixY = e.layoutRect().y, e._autoFixY < n && (e.fixed(!0).layoutRect({y: 0}).repaint(), t(!0, n - e._autoFixY))))
            }

            var u = this;
            u._super(e), u._eventsRoot = u, u.addClass("floatpanel"), e.autohide && (o || (o = function (e) {
                var t, r = u.getParentCtrl(e.target);
                for (t = s.length; t--;) {
                    var i = s[t];
                    if (i.settings.autohide) {
                        if (r && (n(r, i) || i.parent() === r))continue;
                        e = i.fire("autohide", {target: e.target}), e.isDefaultPrevented() || i.hide()
                    }
                }
            }, r.on(document, "click", o)), s.push(u)), e.autofix && (a || (a = function () {
                var e;
                for (e = s.length; e--;)i(s[e])
            }, r.on(window, "scroll", a)), u.on("move", function () {
                i(this)
            })), u.on("postrender show", function (e) {
                if (e.control == u) {
                    var n, i = u.classPrefix;
                    u.modal && !c && (n = r.createFragment('<div id="' + i + 'modal-block" class="' + i + "reset " + i + 'fade"></div>'), n = n.firstChild, u.getContainerElm().appendChild(n), setTimeout(function () {
                        r.addClass(n, i + "in"), r.addClass(u.getEl(), i + "in")
                    }, 0), c = !0), l.push(u), t()
                }
            }), u.on("close hide", function (e) {
                if (e.control == u) {
                    for (var n = l.length; n--;)l[n] === u && l.splice(n, 1);
                    t()
                }
            }), u.on("show", function () {
                u.parents().each(function (e) {
                    return e._fixed ? (u.fixed(!0), !1) : void 0
                })
            }), e.popover && (u._preBodyHtml = '<div class="' + u.classPrefix + 'arrow"></div>', u.addClass("popover").addClass("bottom").addClass(u.isRtl() ? "end" : "start"))
        }, fixed: function (e) {
            var t = this;
            if (t._fixed != e) {
                if (t._rendered) {
                    var n = r.getViewPort();
                    e ? t.layoutRect().y -= n.y : t.layoutRect().y += n.y
                }
                t.toggleClass("fixed", e), t._fixed = e
            }
            return t
        }, show: function () {
            var e = this, t, n = e._super();
            for (t = s.length; t-- && s[t] !== e;);
            return-1 === t && s.push(e), n
        }, hide: function () {
            return i(this), this._super()
        }, hideAll: function () {
            d.hideAll()
        }, close: function () {
            var e = this;
            return e.fire("close"), e.remove()
        }, remove: function () {
            i(this), this._super()
        }});
        return d.hideAll = function () {
            for (var e = s.length; e--;) {
                var t = s[e];
                t.settings.autohide && (t.fire("cancel", {}, !1), t.hide(), s.splice(e, 1))
            }
        }, d
    }), r(X, [z], function (e) {
        return function (t) {
            function n() {
                if (!m)if (m = [], u.find)u.find("*").each(function (e) {
                    e.canFocus && m.push(e.getEl())
                }); else for (var e = u.getEl().getElementsByTagName("*"), t = 0; t < e.length; t++)e[t].id && e[t] && m.push(e[t])
            }

            function r() {
                return document.getElementById(h)
            }

            function i(e) {
                return e = e || r(), e && e.getAttribute("role")
            }

            function o(e) {
                for (var t, n = e || r(); n = n.parentNode;)if (t = i(n))return t
            }

            function a(e) {
                var t = document.getElementById(h);
                return t ? t.getAttribute("aria-" + e) : void 0
            }

            function s() {
                var n = r();
                if (!n || "TEXTAREA" != n.nodeName && "text" != n.type)return t.onAction ? t.onAction(h) : e.fire(r(), "click", {keyboard: !0}), !0
            }

            function l() {
                var e;
                t.onCancel ? ((e = r()) && e.blur(), t.onCancel()) : t.root.fire("cancel")
            }

            function c(e) {
                function r(e) {
                    for (var t = u ? u.getEl() : document.body; e && e != t;) {
                        if ("none" == e.style.display)return!1;
                        e = e.parentNode
                    }
                    return!0
                }

                var i = -1, o, a, l = [];
                for (n(), a = l.length, a = 0; a < m.length; a++)r(m[a]) && l.push(m[a]);
                for (a = l.length; a--;)if (l[a].id === h) {
                    i = a;
                    break
                }
                i += e, 0 > i ? i = l.length - 1 : i >= l.length && (i = 0), o = l[i], o.focus(), h = o.id, t.actOnFocus && s()
            }

            function d() {
                var e, r;
                for (r = i(t.root.getEl()), n(), e = m.length; e--;)if ("toolbar" == r && m[e].id === h)return m[e].focus(), void 0;
                m[0].focus()
            }

            var u = t.root, f = t.enableUpDown !== !1, p = t.enableLeftRight !== !1, m = t.items, h;
            return u.on("keydown", function (e) {
                var n = 37, r = 39, d = 38, u = 40, m = 27, h = 14, g = 13, v = 32, y = 9, b;
                switch (e.keyCode) {
                    case n:
                        p && (t.leftAction ? t.leftAction() : c(-1), b = !0);
                        break;
                    case r:
                        p && ("menuitem" == i() && "menu" == o() ? a("haspopup") && s() : c(1), b = !0);
                        break;
                    case d:
                        f && (c(-1), b = !0);
                        break;
                    case u:
                        f && ("menuitem" == i() && "menubar" == o() ? s() : "button" == i() && a("haspopup") ? s() : c(1), b = !0);
                        break;
                    case y:
                        b = !0, e.shiftKey ? c(-1) : c(1);
                        break;
                    case m:
                        b = !0, l();
                        break;
                    case h:
                    case g:
                    case v:
                        b = s()
                }
                b && (e.stopPropagation(), e.preventDefault())
            }), u.on("focusin", function (e) {
                n(), h = e.target.id
            }), {moveFocus: c, focusFirst: d, cancel: l}
        }
    }), r(J, [G, $, z, X, q], function (e, t, n, r, i) {
        var o = e.extend({modal: !0, Defaults: {border: 1, layout: "flex", containerCls: "panel", role: "dialog", callbacks: {submit: function () {
            this.fire("submit", {data: this.toJSON()})
        }, close: function () {
            this.close()
        }}}, init: function (e) {
            var n = this;
            n._super(e), n.isRtl() && n.addClass("rtl"), n.addClass("window"), n._fixed = !0, e.buttons && (n.statusbar = new t({layout: "flex", border: "1 0 0 0", spacing: 3, padding: 10, align: "center", pack: n.isRtl() ? "start" : "end", defaults: {type: "button"}, items: e.buttons}), n.statusbar.addClass("foot"), n.statusbar.parent(n)), n.on("click", function (e) {
                -1 != e.target.className.indexOf(n.classPrefix + "close") && n.close()
            }), n.aria("label", e.title), n._fullscreen = !1
        }, recalc: function () {
            var e = this, t = e.statusbar, r, i, o, a;
            e._fullscreen && (e.layoutRect(n.getWindowSize()), e.layoutRect().contentH = e.layoutRect().innerH), e._super(), r = e.layoutRect(), e.settings.title && !e._fullscreen && (i = r.headerW, i > r.w && (o = r.x - Math.max(0, i / 2), e.layoutRect({w: i, x: o}), a = !0)), t && (t.layoutRect({w: e.layoutRect().innerW}).recalc(), i = t.layoutRect().minW + r.deltaW, i > r.w && (o = r.x - Math.max(0, i - r.w), e.layoutRect({w: i, x: o}), a = !0)), a && e.recalc()
        }, initLayoutRect: function () {
            var e = this, t = e._super(), r = 0, i;
            if (e.settings.title && !e._fullscreen) {
                i = e.getEl("head");
                var o = n.getSize(i);
                t.headerW = o.width, t.headerH = o.height, r += t.headerH
            }
            e.statusbar && (r += e.statusbar.layoutRect().h), t.deltaH += r, t.minH += r, t.h += r;
            var a = n.getWindowSize();
            return t.x = Math.max(0, a.w / 2 - t.w / 2), t.y = Math.max(0, a.h / 2 - t.h / 2), t
        }, renderHtml: function () {
            var e = this, t = e._layout, n = e._id, r = e.classPrefix, i = e.settings, o = "", a = "", s = i.html;
            return e.preRender(), t.preRender(e), i.title && (o = '<div id="' + n + '-head" class="' + r + 'window-head"><div class="' + r + 'title">' + e.encode(i.title) + '</div><button type="button" class="' + r + 'close" aria-hidden="true">&times;</button><div id="' + n + '-dragh" class="' + r + 'dragh"></div></div>'), i.url && (s = '<iframe src="' + i.url + '" tabindex="-1"></iframe>'), "undefined" == typeof s && (s = t.renderHtml(e)), e.statusbar && (a = e.statusbar.renderHtml()), '<div id="' + n + '" class="' + e.classes() + '" hideFocus="1" tabIndex="-1">' + o + '<div id="' + n + '-body" class="' + e.classes("body") + '">' + s + "</div>" + a + "</div>"
        }, fullscreen: function (e) {
            var t = this, r = document.documentElement, i, o = t.classPrefix, a;
            if (e != t._fullscreen)if (n.on(window, "resize", function () {
                var e;
                if (t._fullscreen)if (i)t._timer || (t._timer = setTimeout(function () {
                    var e = n.getWindowSize();
                    t.moveTo(0, 0).resizeTo(e.w, e.h), t._timer = 0
                }, 50)); else {
                    e = (new Date).getTime();
                    var r = n.getWindowSize();
                    t.moveTo(0, 0).resizeTo(r.w, r.h), (new Date).getTime() - e > 50 && (i = !0)
                }
            }), a = t.layoutRect(), t._fullscreen = e, e) {
                t._initial = {x: a.x, y: a.y, w: a.w, h: a.h}, t._borderBox = t.parseBox("0"), t.getEl("head").style.display = "none", a.deltaH -= a.headerH + 2, n.addClass(r, o + "fullscreen"), n.addClass(document.body, o + "fullscreen"), t.addClass("fullscreen");
                var s = n.getWindowSize();
                t.moveTo(0, 0).resizeTo(s.w, s.h)
            } else t._borderBox = t.parseBox(t.settings.border), t.getEl("head").style.display = "", a.deltaH += a.headerH, n.removeClass(r, o + "fullscreen"), n.removeClass(document.body, o + "fullscreen"), t.removeClass("fullscreen"), t.moveTo(t._initial.x, t._initial.y).resizeTo(t._initial.w, t._initial.h);
            return t.reflow()
        }, postRender: function () {
            var e = this, t = [], n, o, a;
            setTimeout(function () {
                e.addClass("in")
            }, 0), e.keyboardNavigation = new r({root: e, enableLeftRight: !1, enableUpDown: !1, items: t, onCancel: function () {
                e.close()
            }}), e.find("*").each(function (e) {
                e.canFocus && (o = o || e.settings.autofocus, n = n || e, "filepicker" == e.type ? (t.push(e.getEl("inp")), e.getEl("open") && t.push(e.getEl("open"))) : t.push(e.getEl()))
            }), e.statusbar && e.statusbar.find("*").each(function (e) {
                e.canFocus && (o = o || e.settings.autofocus, n = n || e, t.push(e.getEl()))
            }), e._super(), e.statusbar && e.statusbar.postRender(), !o && n && n.focus(), this.dragHelper = new i(e._id + "-dragh", {start: function () {
                a = {x: e.layoutRect().x, y: e.layoutRect().y}
            }, drag: function (t) {
                e.moveTo(a.x + t.deltaX, a.y + t.deltaY)
            }}), e.on("submit", function (t) {
                t.isDefaultPrevented() || e.close()
            })
        }, submit: function () {
            return this.fire("submit", {data: this.toJSON()})
        }, remove: function () {
            var e = this, t = e.classPrefix;
            e.dragHelper.destroy(), e._super(), e.statusbar && this.statusbar.remove(), e._fullscreen && (n.removeClass(document.documentElement, t + "fullscreen"), n.removeClass(document.body, t + "fullscreen"))
        }});
        return o
    }), r(Q, [J], function (e) {
        var t = e.extend({init: function (e) {
            e = {border: 1, padding: 20, layout: "flex", pack: "center", align: "center", containerCls: "panel", autoScroll: !0, buttons: {type: "button", text: "Ok", action: "ok"}, items: {type: "label", multiline: !0, maxWidth: 500, maxHeight: 200}}, this._super(e)
        }, Statics: {OK: 1, OK_CANCEL: 2, YES_NO: 3, YES_NO_CANCEL: 4, msgBox: function (n) {
            var r, i = n.callback || function () {
            };
            switch (n.buttons) {
                case t.OK_CANCEL:
                    r = [
                        {type: "button", text: "Ok", subtype: "primary", onClick: function (e) {
                            e.control.parents()[1].close(), i(!0)
                        }},
                        {type: "button", text: "Cancel", onClick: function (e) {
                            e.control.parents()[1].close(), i(!1)
                        }}
                    ];
                    break;
                case t.YES_NO:
                    r = [
                        {type: "button", text: "Ok", subtype: "primary", onClick: function (e) {
                            e.control.parents()[1].close(), i(!0)
                        }}
                    ];
                    break;
                case t.YES_NO_CANCEL:
                    r = [
                        {type: "button", text: "Ok", subtype: "primary", onClick: function (e) {
                            e.control.parents()[1].close()
                        }}
                    ];
                    break;
                default:
                    r = [
                        {type: "button", text: "Ok", subtype: "primary", onClick: function (e) {
                            e.control.parents()[1].close(), i(!0)
                        }}
                    ]
            }
            return new e({padding: 20, x: n.x, y: n.y, minWidth: 300, minHeight: 100, layout: "flex", pack: "center", align: "center", buttons: r, title: n.title, items: {type: "label", multiline: !0, maxWidth: 500, maxHeight: 200, text: n.text}, onClose: n.onClose}).renderTo(document.body).reflow()
        }, alert: function (e, n) {
            return"string" == typeof e && (e = {text: e}), e.callback = n, t.msgBox(e)
        }, confirm: function (e, n) {
            return"string" == typeof e && (e = {text: e}), e.callback = n, e.buttons = t.OK_CANCEL, t.msgBox(e)
        }}});
        return t
    }), r(Z, [J, Q], function (e, t) {
        return function (n) {
            function r() {
                return o.length ? o[o.length - 1] : void 0
            }

            var i = this, o = [];
            i.windows = o, i.open = function (t, r) {
                var i;
                return n.editorManager.activeEditor = n, t.title = t.title || " ", t.url = t.url || t.file, t.url && (t.width = parseInt(t.width || 320, 10), t.height = parseInt(t.height || 240, 10)), t.body && (t.items = {defaults: t.defaults, type: t.bodyType || "form", items: t.body}), t.url || t.buttons || (t.buttons = [
                    {text: "Ok", subtype: "primary", onclick: function () {
                        i.find("form")[0].submit(), i.close()
                    }},
                    {text: "Cancel", onclick: function () {
                        i.close()
                    }}
                ]), i = new e(t), o.push(i), i.on("close", function () {
                    for (var e = o.length; e--;)o[e] === i && o.splice(e, 1);
                    n.focus()
                }), t.data && i.on("postRender", function () {
                    this.find("*").each(function (e) {
                        var n = e.name();
                        n in t.data && e.value(t.data[n])
                    })
                }), i.features = t || {}, i.params = r || {}, n.nodeChanged(), i.renderTo(document.body).reflow()
            }, i.alert = function (e, n, r) {
                t.alert(e, function () {
                    n && n.call(r || this)
                })
            }, i.confirm = function (e, n, r) {
                t.confirm(e, function (e) {
                    n.call(r || this, e)
                })
            }, i.close = function () {
                r() && r().close()
            }, i.getParams = function () {
                return r() ? r().params : null
            }, i.setParams = function (e) {
                r() && (r().params = e)
            }
        }
    }), r(et, [S, A, b, m, h, f], function (e, t, n, r, i, o) {
        return function (a) {
            function s(e, t) {
                try {
                    a.getDoc().execCommand(e, !1, t)
                } catch (n) {
                }
            }

            function l() {
                var e = a.getDoc().documentMode;
                return e ? e : 6
            }

            function c(e) {
                return e.isDefaultPrevented()
            }

            function d() {
                function t(e) {
                    var t = new MutationObserver(function () {
                    });
                    o.each(a.getBody().getElementsByTagName("*"), function (e) {
                        "SPAN" == e.tagName && e.setAttribute("mce-data-marked", 1), !e.hasAttribute("data-mce-style") && e.hasAttribute("style") && a.dom.setAttrib(e, "style", e.getAttribute("style"))
                    }), t.observe(a.getDoc(), {childList: !0, attributes: !0, subtree: !0, attributeFilter: ["style"]}), a.getDoc().execCommand(e ? "ForwardDelete" : "Delete", !1, null);
                    var n = a.selection.getRng(), r = n.startContainer.parentNode;
                    o.each(t.takeRecords(), function (e) {
                        if ("style" == e.attributeName) {
                            var t = e.target.getAttribute("data-mce-style");
                            t ? e.target.setAttribute("style", t) : e.target.removeAttribute("style")
                        }
                        o.each(e.addedNodes, function (e) {
                            if ("SPAN" == e.nodeName && !e.getAttribute("mce-data-marked")) {
                                var t, i;
                                e == r && (t = n.startOffset, i = e.firstChild), z.remove(e, !0), i && (n.setStart(i, t), n.setEnd(i, t), a.selection.setRng(n))
                            }
                        })
                    }), t.disconnect(), o.each(a.dom.select("span[mce-data-marked]"), function (e) {
                        e.removeAttribute("mce-data-marked")
                    })
                }

                var n = a.getDoc();
                window.MutationObserver && (a.on("keydown", function (n) {
                    var r = n.keyCode == F, i = e.metaKeyPressed(n);
                    if (!c(n) && (r || n.keyCode == I)) {
                        var o = a.selection.getRng(), s = o.startContainer, l = o.startOffset;
                        if (!i && o.collapsed && 3 == s.nodeType && (r ? l < s.data.length : l > 0))return;
                        n.preventDefault(), i && a.selection.getSel().modify("extend", r ? "forward" : "backward", "word"), t(r)
                    }
                }), a.on("keypress", function (e) {
                    c(e) || W.isCollapsed() || !e.charCode || (e.preventDefault(), t(!0), a.selection.setContent(String.fromCharCode(e.charCode)))
                }), a.addCommand("Delete", function () {
                    t()
                }), a.addCommand("ForwardDelete", function () {
                    t(!0)
                }), a.on("dragstart", function (e) {
                    e.dataTransfer.setData("mce-internal", a.selection.getContent())
                }), a.on("drop", function (e) {
                    if (!c(e)) {
                        var r = e.dataTransfer.getData("mce-internal");
                        r && n.caretRangeFromPoint && (e.preventDefault(), t(), a.selection.setRng(n.caretRangeFromPoint(e.x, e.y)), a.insertContent(r))
                    }
                }), a.on("cut", function (e) {
                    !c(e) && e.clipboardData && (e.preventDefault(), e.clipboardData.clearData(), e.clipboardData.setData("text/html", a.selection.getContent()), e.clipboardData.setData("text/plain", a.selection.getContent({format: "text"})), t(!0))
                }))
            }

            function u() {
                function e(e) {
                    var t = z.create("body"), n = e.cloneContents();
                    return t.appendChild(n), W.serializer.serialize(t, {format: "html"})
                }

                function n(n) {
                    if (!n.setStart) {
                        if (n.item)return!1;
                        var r = n.duplicate();
                        return r.moveToElementText(a.getBody()), t.compareRanges(n, r)
                    }
                    var i = e(n), o = z.createRng();
                    o.selectNode(a.getBody());
                    var s = e(o);
                    return i === s
                }

                a.on("keydown", function (e) {
                    var t = e.keyCode, r, i;
                    if (!c(e) && (t == F || t == I)) {
                        if (r = a.selection.isCollapsed(), i = a.getBody(), r && !z.isEmpty(i))return;
                        if (!r && !n(a.selection.getRng()))return;
                        e.preventDefault(), a.setContent(""), i.firstChild && z.isBlock(i.firstChild) ? a.selection.setCursorLocation(i.firstChild, 0) : a.selection.setCursorLocation(i, 0), a.nodeChanged()
                    }
                })
            }

            function f() {
                a.on("keydown", function (t) {
                    !c(t) && 65 == t.keyCode && e.metaKeyPressed(t) && (t.preventDefault(), a.execCommand("SelectAll"))
                })
            }

            function p() {
                a.settings.content_editable || (z.bind(a.getDoc(), "focusin", function () {
                    W.setRng(W.getRng())
                }), z.bind(a.getDoc(), "mousedown", function (e) {
                    e.target == a.getDoc().documentElement && (a.getWin().focus(), W.setRng(W.getRng()))
                }))
            }

            function m() {
                a.on("keydown", function (e) {
                    if (!c(e) && e.keyCode === I && W.isCollapsed() && 0 === W.getRng(!0).startOffset) {
                        var t = W.getNode(), n = t.previousSibling;
                        if ("HR" == t.nodeName)return z.remove(t), e.preventDefault(), void 0;
                        n && n.nodeName && "hr" === n.nodeName.toLowerCase() && (z.remove(n), e.preventDefault())
                    }
                })
            }

            function h() {
                window.Range.prototype.getClientRects || a.on("mousedown", function (e) {
                    if (!c(e) && "HTML" === e.target.nodeName) {
                        var t = a.getBody();
                        t.blur(), setTimeout(function () {
                            t.focus()
                        }, 0)
                    }
                })
            }

            function g() {
                a.on("click", function (e) {
                    e = e.target, /^(IMG|HR)$/.test(e.nodeName) && W.getSel().setBaseAndExtent(e, 0, e, 1), "A" == e.nodeName && z.hasClass(e, "mce-item-anchor") && W.select(e), a.nodeChanged()
                })
            }

            function v() {
                function e() {
                    var e = z.getAttribs(W.getStart().cloneNode(!1));
                    return function () {
                        var t = W.getStart();
                        t !== a.getBody() && (z.setAttrib(t, "style", null), O(e, function (e) {
                            t.setAttributeNode(e.cloneNode(!0))
                        }))
                    }
                }

                function t() {
                    return!W.isCollapsed() && z.getParent(W.getStart(), z.isBlock) != z.getParent(W.getEnd(), z.isBlock)
                }

                a.on("keypress", function (n) {
                    var r;
                    return c(n) || 8 != n.keyCode && 46 != n.keyCode || !t() ? void 0 : (r = e(), a.getDoc().execCommand("delete", !1, null), r(), n.preventDefault(), !1)
                }), z.bind(a.getDoc(), "cut", function (n) {
                    var r;
                    !c(n) && t() && (r = e(), setTimeout(function () {
                        r()
                    }, 0))
                })
            }

            function y() {
                var e, n;
                a.on("selectionchange", function () {
                    n && (clearTimeout(n), n = 0), n = window.setTimeout(function () {
                        var n = W.getRng();
                        e && t.compareRanges(n, e) || (a.nodeChanged(), e = n)
                    }, 50)
                })
            }

            function b() {
                document.body.setAttribute("role", "application")
            }

            function C() {
                a.on("keydown", function (e) {
                    if (!c(e) && e.keyCode === I && W.isCollapsed() && 0 === W.getRng(!0).startOffset) {
                        var t = W.getNode().previousSibling;
                        if (t && t.nodeName && "table" === t.nodeName.toLowerCase())return e.preventDefault(), !1
                    }
                })
            }

            function x() {
                l() > 7 || (s("RespectVisibilityInDesign", !0), a.contentStyles.push(".mceHideBrInPre pre br {display: none}"), z.addClass(a.getBody(), "mceHideBrInPre"), U.addNodeFilter("pre", function (e) {
                    for (var t = e.length, r, i, o, a; t--;)for (r = e[t].getAll("br"), i = r.length; i--;)o = r[i], a = o.prev, a && 3 === a.type && "\n" != a.value.charAt(a.value - 1) ? a.value += "\n" : o.parent.insert(new n("#text", 3), o, !0).value = "\n"
                }), q.addNodeFilter("pre", function (e) {
                    for (var t = e.length, n, r, i, o; t--;)for (n = e[t].getAll("br"), r = n.length; r--;)i = n[r], o = i.prev, o && 3 == o.type && (o.value = o.value.replace(/\r?\n$/, ""))
                }))
            }

            function w() {
                z.bind(a.getBody(), "mouseup", function () {
                    var e, t = W.getNode();
                    "IMG" == t.nodeName && ((e = z.getStyle(t, "width")) && (z.setAttrib(t, "width", e.replace(/[^0-9%]+/g, "")), z.setStyle(t, "width", "")), (e = z.getStyle(t, "height")) && (z.setAttrib(t, "height", e.replace(/[^0-9%]+/g, "")), z.setStyle(t, "height", "")))
                })
            }

            function _() {
                a.on("keydown", function (t) {
                    var n, r, i, o, s;
                    if (!c(t) && t.keyCode == e.BACKSPACE && (n = W.getRng(), r = n.startContainer, i = n.startOffset, o = z.getRoot(), s = r, n.collapsed && 0 === i)) {
                        for (; s && s.parentNode && s.parentNode.firstChild == s && s.parentNode != o;)s = s.parentNode;
                        "BLOCKQUOTE" === s.tagName && (a.formatter.toggle("blockquote", null, s), n = z.createRng(), n.setStart(r, 0), n.setEnd(r, 0), W.setRng(n))
                    }
                })
            }

            function N() {
                function e() {
                    a._refreshContentEditable(), s("StyleWithCSS", !1), s("enableInlineTableEditing", !1), V.object_resizing || s("enableObjectResizing", !1)
                }

                V.readonly || a.on("BeforeExecCommand MouseDown", e)
            }

            function E() {
                function e() {
                    O(z.select("a"), function (e) {
                        var t = e.parentNode, n = z.getRoot();
                        if (t.lastChild === e) {
                            for (; t && !z.isBlock(t);) {
                                if (t.parentNode.lastChild !== t || t === n)return;
                                t = t.parentNode
                            }
                            z.add(t, "br", {"data-mce-bogus": 1})
                        }
                    })
                }

                a.on("SetContent ExecCommand", function (t) {
                    ("setcontent" == t.type || "mceInsertLink" === t.command) && e()
                })
            }

            function k() {
                V.forced_root_block && a.on("init", function () {
                    s("DefaultParagraphSeparator", V.forced_root_block)
                })
            }

            function S() {
                a.on("Undo Redo SetContent", function (e) {
                    e.initial || a.execCommand("mceRepaint")
                })
            }

            function T() {
                a.on("keydown", function (e) {
                    var t;
                    c(e) || e.keyCode != I || (t = a.getDoc().selection.createRange(), t && t.item && (e.preventDefault(), a.undoManager.beforeChange(), z.remove(t.item(0)), a.undoManager.add()))
                })
            }

            function R() {
                var e;
                l() >= 10 && (e = "", O("p div h1 h2 h3 h4 h5 h6".split(" "), function (t, n) {
                    e += (n > 0 ? "," : "") + t + ":empty"
                }), a.contentStyles.push(e + "{padding-right: 1px !important}"))
            }

            function A() {
                l() < 9 && (U.addNodeFilter("noscript", function (e) {
                    for (var t = e.length, n, r; t--;)n = e[t], r = n.firstChild, r && n.attr("data-mce-innertext", r.value)
                }), q.addNodeFilter("noscript", function (e) {
                    for (var t = e.length, i, o, a; t--;)i = e[t], o = e[t].firstChild, o ? o.value = r.decode(o.value) : (a = i.attributes.map["data-mce-innertext"], a && (i.attr("data-mce-innertext", null), o = new n("#text", 3), o.value = a, o.raw = !0, i.append(o)))
                }))
            }

            function B() {
                function e(e, t) {
                    var n = i.createTextRange();
                    try {
                        n.moveToPoint(e, t)
                    } catch (r) {
                        n = null
                    }
                    return n
                }

                function t(t) {
                    var r;
                    t.button ? (r = e(t.x, t.y), r && (r.compareEndPoints("StartToStart", a) > 0 ? r.setEndPoint("StartToStart", a) : r.setEndPoint("EndToEnd", a), r.select())) : n()
                }

                function n() {
                    var e = r.selection.createRange();
                    a && !e.item && 0 === e.compareEndPoints("StartToEnd", e) && a.select(), z.unbind(r, "mouseup", n), z.unbind(r, "mousemove", t), a = o = 0
                }

                var r = z.doc, i = r.body, o, a, s;
                r.documentElement.unselectable = !0, z.bind(r, "mousedown contextmenu", function (i) {
                    if ("HTML" === i.target.nodeName) {
                        if (o && n(), s = r.documentElement, s.scrollHeight > s.clientHeight)return;
                        o = 1, a = e(i.x, i.y), a && (z.bind(r, "mouseup", n), z.bind(r, "mousemove", t), z.win.focus(), a.select())
                    }
                })
            }

            function L() {
                a.on("keyup focusin", function (t) {
                    65 == t.keyCode && e.metaKeyPressed(t) || W.normalize()
                })
            }

            function H() {
                a.contentStyles.push("img:-moz-broken {-moz-force-broken-image-icon:1;min-width:24px;min-height:24px}")
            }

            function D() {
                a.inline || a.on("keydown", function () {
                    document.activeElement == document.body && a.getWin().focus()
                })
            }

            function M() {
                a.inline || (a.contentStyles.push("body {min-height: 150px}"), a.on("click", function (e) {
                    "HTML" == e.target.nodeName && (a.execCommand("SelectAll"), a.selection.collapse(!0), a.nodeChanged())
                }))
            }

            function P() {
                i.mac && a.on("keydown", function (t) {
                    !e.metaKeyPressed(t) || 37 != t.keyCode && 39 != t.keyCode || (t.preventDefault(), a.selection.getSel().modify("move", 37 == t.keyCode ? "backward" : "forward", "word"))
                })
            }

            var O = o.each, I = e.BACKSPACE, F = e.DELETE, z = a.dom, W = a.selection, V = a.settings, U = a.parser, q = a.serializer, j = i.gecko, $ = i.ie, K = i.webkit;
            C(), _(), u(), L(), K && (d(), p(), g(), k(), i.iOS ? (y(), D(), M()) : f()), $ && i.ie < 11 && (m(), b(), x(), w(), T(), R(), A(), B()), i.ie >= 11 && M(), i.ie && f(), j && (m(), h(), v(), N(), E(), S(), H(), P())
        }
    }), r(tt, [f], function (e) {
        function t() {
            return!1
        }

        function n() {
            return!0
        }

        var r = "__bindings", i = e.makeMap("focusin focusout click dblclick mousedown mouseup mousemove mouseover beforepaste paste cut copy selectionchange mouseout mouseenter mouseleave keydown keypress keyup contextmenu dragstart dragend dragover draggesture dragdrop drop drag", " ");
        return{fire: function (e, i, o) {
            var a = this, s, l, c, d, u;
            if (e = e.toLowerCase(), i = i || {}, i.type = e, i.target || (i.target = a), i.preventDefault || (i.preventDefault = function () {
                i.isDefaultPrevented = n
            }, i.stopPropagation = function () {
                i.isPropagationStopped = n
            }, i.stopImmediatePropagation = function () {
                i.isImmediatePropagationStopped = n
            }, i.isDefaultPrevented = t, i.isPropagationStopped = t, i.isImmediatePropagationStopped = t), a[r] && (s = a[r][e]))for (l = 0, c = s.length; c > l && (s[l] = d = s[l], !i.isImmediatePropagationStopped()); l++)if (d.call(a, i) === !1)return i.preventDefault(), i;
            if (o !== !1 && a.parent)for (u = a.parent(); u && !i.isPropagationStopped();)u.fire(e, i, !1), u = u.parent();
            return i
        }, on: function (e, t) {
            var n = this, o, a, s, l;
            if (t === !1 && (t = function () {
                return!1
            }), t)for (s = e.toLowerCase().split(" "), l = s.length; l--;)e = s[l], o = n[r], o || (o = n[r] = {}), a = o[e], a || (a = o[e] = [], n.bindNative && i[e] && n.bindNative(e)), a.push(t);
            return n
        }, off: function (e, t) {
            var n = this, o, a = n[r], s, l, c, d;
            if (a)if (e)for (c = e.toLowerCase().split(" "), o = c.length; o--;) {
                if (e = c[o], s = a[e], !e) {
                    for (l in a)a[e].length = 0;
                    return n
                }
                if (s) {
                    if (t)for (d = s.length; d--;)s[d] === t && s.splice(d, 1); else s.length = 0;
                    !s.length && n.unbindNative && i[e] && (n.unbindNative(e), delete a[e])
                }
            } else {
                if (n.unbindNative)for (e in a)n.unbindNative(e);
                n[r] = []
            }
            return n
        }, hasEventListeners: function (e) {
            var t = this[r];
            return e = e.toLowerCase(), !(!t || !t[e] || 0 === t[e].length)
        }}
    }), r(nt, [f, h], function (e, t) {
        var n = e.each, r = e.explode, i = {f9: 120, f10: 121, f11: 122};
        return function (o) {
            var a = this, s = {};
            o.on("keyup keypress keydown", function (e) {
                (e.altKey || e.ctrlKey || e.metaKey) && n(s, function (n) {
                    var r = t.mac ? e.metaKey : e.ctrlKey;
                    if (n.ctrl == r && n.alt == e.altKey && n.shift == e.shiftKey)return e.keyCode == n.keyCode || e.charCode && e.charCode == n.charCode ? (e.preventDefault(), "keydown" == e.type && n.func.call(n.scope), !0) : void 0
                })
            }), a.add = function (t, a, l, c) {
                var d;
                return d = l, "string" == typeof l ? l = function () {
                    o.execCommand(d, !1, null)
                } : e.isArray(d) && (l = function () {
                    o.execCommand(d[0], d[1], d[2])
                }), n(r(t.toLowerCase()), function (e) {
                    var t = {func: l, scope: c || o, desc: o.translate(a), alt: !1, ctrl: !1, shift: !1};
                    n(r(e, "+"), function (e) {
                        switch (e) {
                            case"alt":
                            case"ctrl":
                            case"shift":
                                t[e] = !0;
                                break;
                            default:
                                t.charCode = e.charCodeAt(0), t.keyCode = i[e] || e.toUpperCase().charCodeAt(0)
                        }
                    }), s[(t.ctrl ? "ctrl" : "") + "," + (t.alt ? "alt" : "") + "," + (t.shift ? "shift" : "") + "," + t.keyCode] = t
                }), !0
            }
        }
    }), r(rt, [g, y, b, E, N, R, B, L, H, D, M, P, v, d, Z, C, w, et, h, f, tt, nt], function (e, n, r, i, o, a, s, l, c, d, u, f, p, m, h, g, v, y, b, C, x, w) {
        function _(e, t) {
            return"selectionchange" == t || "drop" == t ? e.getDoc() : !e.inline && /^mouse|click|contextmenu/.test(t) ? e.getDoc() : e.getBody()
        }

        function N(e, t, r) {
            var i = this, o, a;
            o = i.documentBaseUrl = r.documentBaseURL, a = r.baseURI, i.settings = t = T({id: e, theme: "modern", delta_width: 0, delta_height: 0, popup_css: "", plugins: "", document_base_url: o, add_form_submit_trigger: !0, submit_patch: !0, add_unload_trigger: !0, convert_urls: !0, relative_urls: !0, remove_script_host: !0, object_resizing: !0, doctype: "<!DOCTYPE html>", visual: !0, font_size_style_values: "xx-small,x-small,small,medium,large,x-large,xx-large", font_size_legacy_values: "xx-small,small,medium,large,x-large,xx-large,300%", forced_root_block: "p", hidden_input: !0, padd_empty_editor: !0, render_ui: !0, indentation: "30px", inline_styles: !0, convert_fonts_to_spans: !0, indent: "simple", indent_before: "p,h1,h2,h3,h4,h5,h6,blockquote,div,title,style,pre,script,td,ul,li,area,table,thead,tfoot,tbody,tr,section,article,hgroup,aside,figure,option,optgroup,datalist", indent_after: "p,h1,h2,h3,h4,h5,h6,blockquote,div,title,style,pre,script,td,ul,li,area,table,thead,tfoot,tbody,tr,section,article,hgroup,aside,figure,option,optgroup,datalist", validate: !0, entity_encoding: "named", url_converter: i.convertURL, url_converter_scope: i, ie7_compat: !0}, t), n.language = t.language || "en", n.languageLoad = t.language_load, n.baseURL = r.baseURL, i.id = t.id = e, i.isNotDirty = !0, i.plugins = {}, i.documentBaseURI = new f(t.document_base_url || o, {base_uri: a}), i.baseURI = a, i.contentCSS = [], i.contentStyles = [], i.shortcuts = new w(i), i.execCommands = {}, i.queryStateCommands = {}, i.queryValueCommands = {}, i.loadedCSS = {}, i.suffix = r.suffix, i.editorManager = r, i.inline = t.inline, i.execCallback("setup", i), r.fire("SetupEditor", i)
        }

        var E = e.DOM, k = n.ThemeManager, S = n.PluginManager, T = C.extend, R = C.each, A = C.explode, B = C.inArray, L = C.trim, H = C.resolve, D = m.Event, M = b.gecko, P = b.ie;
        return N.prototype = {render: function () {
            function e() {
                E.unbind(window, "ready", e), n.render()
            }

            function t() {
                var e = p.ScriptLoader;
                if (r.language && "en" != r.language && (r.language_url = n.editorManager.baseURL + "/langs/" + r.language + ".js"), r.language_url && e.add(r.language_url), r.theme && "function" != typeof r.theme && "-" != r.theme.charAt(0) && !k.urls[r.theme]) {
                    var t = r.theme_url;
                    t = t ? n.documentBaseURI.toAbsolute(t) : "themes/" + r.theme + "/theme" + o + ".js", k.load(r.theme, t)
                }
                C.isArray(r.plugins) && (r.plugins = r.plugins.join(" ")), R(r.external_plugins, function (e, t) {
                    S.load(t, e), r.plugins += " " + t
                }), R(r.plugins.split(/[ ,]/), function (e) {
                    if (e = L(e), e && !S.urls[e])if ("-" == e.charAt(0)) {
                        e = e.substr(1, e.length);
                        var t = S.dependencies(e);
                        R(t, function (e) {
                            var t = {prefix: "plugins/", resource: e, suffix: "/plugin" + o + ".js"};
                            e = S.createUrl(t, e), S.load(e.resource, e)
                        })
                    } else S.load(e, {prefix: "plugins/", resource: e, suffix: "/plugin" + o + ".js"})
                }), e.loadQueue(function () {
                    n.removed || n.init()
                })
            }

            var n = this, r = n.settings, i = n.id, o = n.suffix;
            if (!D.domLoaded)return E.bind(window, "ready", e), void 0;
            if (n.getElement() && b.contentEditable) {
                r.inline ? n.inline = !0 : (n.orgVisibility = n.getElement().style.visibility, n.getElement().style.visibility = "hidden");
                var a = n.getElement().form || E.getParent(i, "form");
                a && (n.formElement = a, r.hidden_input && !/TEXTAREA|INPUT/i.test(n.getElement().nodeName) && (E.insertAfter(E.create("input", {type: "hidden", name: i}), i), n.hasHiddenInput = !0), n.formEventDelegate = function (e) {
                    n.fire(e.type, e)
                }, E.bind(a, "submit reset", n.formEventDelegate), n.on("reset", function () {
                    n.setContent(n.startContent, {format: "raw"})
                }), !r.submit_patch || a.submit.nodeType || a.submit.length || a._mceOldSubmit || (a._mceOldSubmit = a.submit, a.submit = function () {
                    return n.editorManager.triggerSave(), n.isNotDirty = !0, a._mceOldSubmit(a)
                })), n.windowManager = new h(n), "xml" == r.encoding && n.on("GetContent", function (e) {
                    e.save && (e.content = E.encode(e.content))
                }), r.add_form_submit_trigger && n.on("submit", function () {
                    n.initialized && n.save()
                }), r.add_unload_trigger && (n._beforeUnload = function () {
                    !n.initialized || n.destroyed || n.isHidden() || n.save({format: "raw", no_events: !0, set_dirty: !1})
                }, n.editorManager.on("BeforeUnload", n._beforeUnload)), t()
            }
        }, init: function () {
            function e(n) {
                var r = S.get(n), i, o;
                i = S.urls[n] || t.documentBaseUrl.replace(/\/$/, ""), n = L(n), r && -1 === B(m, n) && (R(S.dependencies(n), function (t) {
                    e(t)
                }), o = new r(t, i), t.plugins[n] = o, o.init && (o.init(t, i), m.push(n)))
            }

            var t = this, n = t.settings, r = t.getElement(), i, o, a, s, l, c, d, u, f, p, m = [];
            if (t.rtl = this.editorManager.i18n.rtl, t.editorManager.add(t), n.aria_label = n.aria_label || E.getAttrib(r, "aria-label", t.getLang("aria.rich_text_area")), n.theme && ("function" != typeof n.theme ? (n.theme = n.theme.replace(/-/, ""), l = k.get(n.theme), t.theme = new l(t, k.urls[n.theme]), t.theme.init && t.theme.init(t, k.urls[n.theme] || t.documentBaseUrl.replace(/\/$/, ""))) : t.theme = n.theme), R(n.plugins.replace(/\-/g, "").split(/[ ,]/), e), n.render_ui && t.theme && (t.orgDisplay = r.style.display, "function" != typeof n.theme ? (i = n.width || r.style.width || r.offsetWidth, o = n.height || r.style.height || r.offsetHeight, a = n.min_height || 100, f = /^[0-9\.]+(|px)$/i, f.test("" + i) && (i = Math.max(parseInt(i, 10) + (l.deltaWidth || 0), 100)), f.test("" + o) && (o = Math.max(parseInt(o, 10) + (l.deltaHeight || 0), a)), l = t.theme.renderUI({targetNode: r, width: i, height: o, deltaWidth: n.delta_width, deltaHeight: n.delta_height}), n.content_editable || (E.setStyles(l.sizeContainer || l.editorContainer, {wi2dth: i, h2eight: o}), o = (l.iframeHeight || o) + ("number" == typeof o ? l.deltaHeight || 0 : ""), a > o && (o = a))) : (l = n.theme(t, r), l.editorContainer.nodeType && (l.editorContainer = l.editorContainer.id = l.editorContainer.id || t.id + "_parent"), l.iframeContainer.nodeType && (l.iframeContainer = l.iframeContainer.id = l.iframeContainer.id || t.id + "_iframecontainer"), o = l.iframeHeight || r.offsetHeight), t.editorContainer = l.editorContainer), n.content_css && R(A(n.content_css), function (e) {
                t.contentCSS.push(t.documentBaseURI.toAbsolute(e))
            }), n.content_style && t.contentStyles.push(n.content_style), n.content_editable)return r = s = l = null, t.initContentBody();
            for (t.iframeHTML = n.doctype + "<html><head>", n.document_base_url != t.documentBaseUrl && (t.iframeHTML += '<base href="' + t.documentBaseURI.getURI() + '" />'), !b.caretAfter && n.ie7_compat && (t.iframeHTML += '<meta http-equiv="X-UA-Compatible" content="IE=7" />'), t.iframeHTML += '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />', p = 0; p < t.contentCSS.length; p++) {
                var h = t.contentCSS[p];
                t.iframeHTML += '<link type="text/css" rel="stylesheet" href="' + h + '" />', t.loadedCSS[h] = !0
            }
            d = n.body_id || "tinymce", -1 != d.indexOf("=") && (d = t.getParam("body_id", "", "hash"), d = d[t.id] || d), u = n.body_class || "", -1 != u.indexOf("=") && (u = t.getParam("body_class", "", "hash"), u = u[t.id] || ""), t.iframeHTML += '</head><body id="' + d + '" class="mce-content-body ' + u + '" onload="window.parent.tinymce.get(\'' + t.id + "').fire('load');\"><br></body></html>";
            var g = 'javascript:(function(){document.open();document.domain="' + document.domain + '";var ed = window.parent.tinymce.get("' + t.id + '");document.write(ed.iframeHTML);document.close();ed.initContentBody(true);})()';
            if (document.domain != location.hostname && (c = g), s = E.add(l.iframeContainer, "iframe", {id: t.id + "_ifr", src: c || 'javascript:""', frameBorder: "0", allowTransparency: "true", title: t.editorManager.translate("Rich Text Area. Press ALT-F9 for menu. Press ALT-F10 for toolbar. Press ALT-0 for help"), style: {width: "100%", height: o, display: "block"}}), P)try {
                t.getDoc()
            } catch (v) {
                s.src = c = g
            }
            t.contentAreaContainer = l.iframeContainer, l.editorContainer && (E.get(l.editorContainer).style.display = t.orgDisplay), E.get(t.id).style.display = "none", E.setAttrib(t.id, "aria-hidden", !0), c || t.initContentBody(), r = s = l = null
        }, initContentBody: function (t) {
            var n = this, o = n.settings, f = E.get(n.id), p = n.getDoc(), m, h;
            o.inline || (n.getElement().style.visibility = n.orgVisibility), t || o.content_editable || (p.open(), p.write(n.iframeHTML), p.close()), o.content_editable && (n.on("remove", function () {
                var e = this.getBody();
                E.removeClass(e, "mce-content-body"), E.removeClass(e, "mce-edit-focus"), E.setAttrib(e, "tabIndex", null), E.setAttrib(e, "contentEditable", null)
            }), E.addClass(f, "mce-content-body"), f.tabIndex = -1, n.contentDocument = p = o.content_document || document, n.contentWindow = o.content_window || window, n.bodyElement = f, o.content_document = o.content_window = null, o.root_name = f.nodeName.toLowerCase()), m = n.getBody(), m.disabled = !0, o.readonly || (n.inline && "static" == E.getStyle(m, "position", !0) && (m.style.position = "relative"), m.contentEditable = n.getParam("content_editable_state", !0)), m.disabled = !1, n.schema = new g(o), n.dom = new e(p, {keep_values: !0, url_converter: n.convertURL, url_converter_scope: n, hex_colors: o.force_hex_style_colors, class_filter: o.class_filter, update_styles: !0, root_element: o.content_editable ? n.id : null, collect: o.content_editable, schema: n.schema, onSetAttrib: function (e) {
                n.fire("SetAttrib", e)
            }}), n.parser = new v(o, n.schema), n.parser.addAttributeFilter("src,href,style", function (e, t) {
                for (var r = e.length, i, o = n.dom, a, s; r--;)i = e[r], a = i.attr(t), s = "data-mce-" + t, i.attributes.map[s] || ("style" === t ? i.attr(s, o.serializeStyle(o.parseStyle(a), i.name)) : i.attr(s, n.convertURL(a, t, i.name)))
            }), n.parser.addNodeFilter("script", function (e) {
                for (var t = e.length, n; t--;)n = e[t], n.attr("type", "mce-" + (n.attr("type") || "text/javascript"))
            }), n.parser.addNodeFilter("#cdata", function (e) {
                for (var t = e.length, n; t--;)n = e[t], n.type = 8, n.name = "#comment", n.value = "[CDATA[" + n.value + "]]"
            }), n.parser.addNodeFilter("p,h1,h2,h3,h4,h5,h6,div", function (e) {
                for (var t = e.length, i, o = n.schema.getNonEmptyElements(); t--;)i = e[t], i.isEmpty(o) && (i.empty().append(new r("br", 1)).shortEnded = !0)
            }), n.serializer = new i(o, n), n.selection = new a(n.dom, n.getWin(), n.serializer, n), n.formatter = new s(n), n.undoManager = new l(n), n.forceBlocks = new d(n), n.enterKey = new c(n), n.editorCommands = new u(n), n.fire("PreInit"), o.browser_spellcheck || o.gecko_spellcheck || (p.body.spellcheck = !1, E.setAttrib(m, "spellcheck", "false")), n.fire("PostRender"), n.quirks = y(n), o.directionality && (m.dir = o.directionality), o.nowrap && (m.style.whiteSpace = "nowrap"), o.protect && n.on("BeforeSetContent", function (e) {
                R(o.protect, function (t) {
                    e.content = e.content.replace(t, function (e) {
                        return"<!--mce:protected " + escape(e) + "-->"
                    })
                })
            }), n.on("SetContent", function () {
                n.addVisual(n.getBody())
            }), o.padd_empty_editor && n.on("PostProcess", function (e) {
                e.content = e.content.replace(/^(<p[^>]*>(&nbsp;|&#160;|\s|\u00a0|)<\/p>[\r\n]*|<br \/>[\r\n]*)$/, "")
            }), n.load({initial: !0, format: "html"}), n.startContent = n.getContent({format: "raw"}), n.initialized = !0, R(n._pendingNativeEvents, function (e) {
                n.dom.bind(_(n, e), e, function (e) {
                    n.fire(e.type, e)
                })
            }), n.fire("init"), n.focus(!0), n.nodeChanged({initial: !0}), n.execCallback("init_instance_callback", n), n.contentStyles.length > 0 && (h = "", R(n.contentStyles, function (e) {
                h += e + "\r\n"
            }), n.dom.addStyle(h)), R(n.contentCSS, function (e) {
                n.loadedCSS[e] || (n.dom.loadCSS(e), n.loadedCSS[e] = !0)
            }), o.auto_focus && setTimeout(function () {
                var e = n.editorManager.get(o.auto_focus);
                e.selection.select(e.getBody(), 1), e.selection.collapse(1), e.getBody().focus(), e.getWin().focus()
            }, 100), f = p = m = null
        }, focus: function (e) {
            var t, n = this, r = n.selection, i = n.settings.content_editable, o, a, s = n.getDoc(), l;
            e || (o = r.getRng(), o.item && (a = o.item(0)), n._refreshContentEditable(), i || (b.opera || n.getBody().focus(), n.getWin().focus()), (M || i) && (l = n.getBody(), l.setActive && b.ie < 11 ? l.setActive() : l.focus(), i && r.normalize()), a && a.ownerDocument == s && (o = s.body.createControlRange(), o.addElement(a), o.select())), n.editorManager.activeEditor != n && ((t = n.editorManager.activeEditor) && t.fire("deactivate", {relatedTarget: n}), n.fire("activate", {relatedTarget: t})), n.editorManager.activeEditor = n
        }, execCallback: function (e) {
            var t = this, n = t.settings[e], r;
            if (n)return t.callbackLookup && (r = t.callbackLookup[e]) && (n = r.func, r = r.scope), "string" == typeof n && (r = n.replace(/\.\w+$/, ""), r = r ? H(r) : 0, n = H(n), t.callbackLookup = t.callbackLookup || {}, t.callbackLookup[e] = {func: n, scope: r}), n.apply(r || t, Array.prototype.slice.call(arguments, 1))
        }, translate: function (e) {
            var t = this.settings.language || "en", n = this.editorManager.i18n;
            return e ? n.data[t + "." + e] || e.replace(/\{\#([^\}]+)\}/g, function (e, r) {
                return n.data[t + "." + r] || "{#" + r + "}"
            }) : ""
        }, getLang: function (e, n) {
            return this.editorManager.i18n.data[(this.settings.language || "en") + "." + e] || (n !== t ? n : "{#" + e + "}")
        }, getParam: function (e, t, n) {
            var r = e in this.settings ? this.settings[e] : t, i;
            return"hash" === n ? (i = {}, "string" == typeof r ? R(r.indexOf("=") > 0 ? r.split(/[;,](?![^=;,]*(?:[;,]|$))/) : r.split(","), function (e) {
                e = e.split("="), i[L(e[0])] = e.length > 1 ? L(e[1]) : L(e)
            }) : i = r, i) : r
        }, nodeChanged: function () {
            var e = this, t = e.selection, n, r, i;
            e.initialized && !e.settings.disable_nodechange && (i = e.getBody(), n = t.getStart() || i, n = P && n.ownerDocument != e.getDoc() ? e.getBody() : n, "IMG" == n.nodeName && t.isCollapsed() && (n = n.parentNode), r = [], e.dom.getParent(n, function (e) {
                return e === i ? !0 : (r.push(e), void 0)
            }), e.fire("NodeChange", {element: n, parents: r}))
        }, addButton: function (e, t) {
            var n = this;
            t.cmd && (t.onclick = function () {
                n.execCommand(t.cmd)
            }), t.text || t.icon || (t.icon = e), n.buttons = n.buttons || {}, t.tooltip = t.tooltip || t.title, n.buttons[e] = t
        }, addMenuItem: function (e, t) {
            var n = this;
            t.cmd && (t.onclick = function () {
                n.execCommand(t.cmd)
            }), n.menuItems = n.menuItems || {}, n.menuItems[e] = t
        }, addCommand: function (e, t, n) {
            this.execCommands[e] = {func: t, scope: n || this}
        }, addQueryStateHandler: function (e, t, n) {
            this.queryStateCommands[e] = {func: t, scope: n || this}
        }, addQueryValueHandler: function (e, t, n) {
            this.queryValueCommands[e] = {func: t, scope: n || this}
        }, addShortcut: function (e, t, n, r) {
            this.shortcuts.add(e, t, n, r)
        }, execCommand: function (e, t, n, r) {
            var i = this, o = 0, a;
            return/^(mceAddUndoLevel|mceEndUndoLevel|mceBeginUndoLevel|mceRepaint)$/.test(e) || r && r.skip_focus || i.focus(), r = T({}, r), r = i.fire("BeforeExecCommand", {command: e, ui: t, value: n}), r.isDefaultPrevented() ? !1 : (a = i.execCommands[e]) && a.func.call(a.scope, t, n) !== !0 ? (i.fire("ExecCommand", {command: e, ui: t, value: n}), !0) : (R(i.plugins, function (r) {
                return r.execCommand && r.execCommand(e, t, n) ? (i.fire("ExecCommand", {command: e, ui: t, value: n}), o = !0, !1) : void 0
            }), o ? o : i.theme && i.theme.execCommand && i.theme.execCommand(e, t, n) ? (i.fire("ExecCommand", {command: e, ui: t, value: n}), !0) : i.editorCommands.execCommand(e, t, n) ? (i.fire("ExecCommand", {command: e, ui: t, value: n}), !0) : (i.getDoc().execCommand(e, t, n), i.fire("ExecCommand", {command: e, ui: t, value: n}), void 0))
        }, queryCommandState: function (e) {
            var t = this, n, r;
            if (!t._isHidden()) {
                if ((n = t.queryStateCommands[e]) && (r = n.func.call(n.scope), r !== !0))return r;
                if (r = t.editorCommands.queryCommandState(e), -1 !== r)return r;
                try {
                    return t.getDoc().queryCommandState(e)
                } catch (i) {
                }
            }
        }, queryCommandValue: function (e) {
            var n = this, r, i;
            if (!n._isHidden()) {
                if ((r = n.queryValueCommands[e]) && (i = r.func.call(r.scope), i !== !0))return i;
                if (i = n.editorCommands.queryCommandValue(e), i !== t)return i;
                try {
                    return n.getDoc().queryCommandValue(e)
                } catch (o) {
                }
            }
        }, show: function () {
            var e = this;
            E.show(e.getContainer()), E.hide(e.id), e.load(), e.fire("show")
        }, hide: function () {
            var e = this, t = e.getDoc();
            P && t && !e.inline && t.execCommand("SelectAll"), e.save(), E.hide(e.getContainer()), E.setStyle(e.id, "display", e.orgDisplay), e.fire("hide")
        }, isHidden: function () {
            return!E.isHidden(this.id)
        }, setProgressState: function (e, t) {
            this.fire("ProgressState", {state: e, time: t})
        }, load: function (e) {
            var n = this, r = n.getElement(), i;
            return r ? (e = e || {}, e.load = !0, i = n.setContent(r.value !== t ? r.value : r.innerHTML, e), e.element = r, e.no_events || n.fire("LoadContent", e), e.element = r = null, i) : void 0
        }, save: function (e) {
            var t = this, n = t.getElement(), r, i;
            if (n && t.initialized)return e = e || {}, e.save = !0, e.element = n, r = e.content = t.getContent(e), e.no_events || t.fire("SaveContent", e), r = e.content, /TEXTAREA|INPUT/i.test(n.nodeName) ? n.value = r : (n.innerHTML = r, (i = E.getParent(t.id, "form")) && R(i.elements, function (e) {
                return e.name == t.id ? (e.value = r, !1) : void 0
            })), e.element = n = null, e.set_dirty !== !1 && (t.isNotDirty = !0), r
        }, setContent: function (e, t) {
            var n = this, r = n.getBody(), i;
            return t = t || {}, t.format = t.format || "html", t.set = !0, t.content = e, t.no_events || n.fire("BeforeSetContent", t), e = t.content, 0 === e.length || /^\s+$/.test(e) ? (i = n.settings.forced_root_block, i && n.schema.isValidChild(r.nodeName.toLowerCase(), i.toLowerCase()) ? (e = P && 11 > P ? "" : '<br data-mce-bogus="1">', e = n.dom.createHTML(i, n.settings.forced_root_block_attrs, e)) : (!P || 11 > P) && (e = '<br data-mce-bogus="1">'), r.innerHTML = e, n.fire("SetContent", t)) : ("raw" !== t.format && (e = new o({}, n.schema).serialize(n.parser.parse(e, {isRootContent: !0}))), t.content = L(e), n.dom.setHTML(r, t.content), t.no_events || n.fire("SetContent", t)), t.content
        }, getContent: function (e) {
            var t = this, n, r = t.getBody();
            return e = e || {}, e.format = e.format || "html", e.get = !0, e.getInner = !0, e.no_events || t.fire("BeforeGetContent", e), n = "raw" == e.format ? r.innerHTML : "text" == e.format ? r.innerText || r.textContent : t.serializer.serialize(r, e), e.content = "text" != e.format ? L(n) : n, e.no_events || t.fire("GetContent", e), e.content
        }, insertContent: function (e) {
            this.execCommand("mceInsertContent", !1, e)
        }, isDirty: function () {
            return!this.isNotDirty
        }, getContainer: function () {
            var e = this;
            return e.container || (e.container = E.get(e.editorContainer || e.id + "_parent")), e.container
        }, getContentAreaContainer: function () {
            return this.contentAreaContainer
        }, getElement: function () {
            return E.get(this.settings.content_element || this.id)
        }, getWin: function () {
            var e = this, t;
            return e.contentWindow || (t = E.get(e.id + "_ifr"), t && (e.contentWindow = t.contentWindow)), e.contentWindow
        }, getDoc: function () {
            var e = this, t;
            return e.contentDocument || (t = e.getWin(), t && (e.contentDocument = t.document)), e.contentDocument
        }, getBody: function () {
            return this.bodyElement || this.getDoc().body
        }, convertURL: function (e, t, n) {
            var r = this, i = r.settings;
            return i.urlconverter_callback ? r.execCallback("urlconverter_callback", e, n, !0, t) : !i.convert_urls || n && "LINK" == n.nodeName || 0 === e.indexOf("file:") || 0 === e.length ? e : i.relative_urls ? r.documentBaseURI.toRelative(e) : e = r.documentBaseURI.toAbsolute(e, i.remove_script_host)
        }, addVisual: function (e) {
            var n = this, r = n.settings, i = n.dom, o;
            e = e || n.getBody(), n.hasVisual === t && (n.hasVisual = r.visual), R(i.select("table,a", e), function (e) {
                var t;
                switch (e.nodeName) {
                    case"TABLE":
                        return o = r.visual_table_class || "mce-item-table", t = i.getAttrib(e, "border"), t && "0" != t || (n.hasVisual ? i.addClass(e, o) : i.removeClass(e, o)), void 0;
                    case"A":
                        return i.getAttrib(e, "href", !1) || (t = i.getAttrib(e, "name") || e.id, o = "mce-item-anchor", t && (n.hasVisual ? i.addClass(e, o) : i.removeClass(e, o))), void 0
                }
            }), n.fire("VisualAid", {element: e, hasVisual: n.hasVisual})
        }, remove: function () {
            var e = this;
            if (!e.removed) {
                e.removed = 1, e.hasHiddenInput && E.remove(e.getElement().nextSibling);
                var t = e.getDoc();
                P && t && !e.inline && t.execCommand("SelectAll"), e.save(), E.setStyle(e.id, "display", e.orgDisplay), e.settings.content_editable || (D.unbind(e.getWin()), D.unbind(e.getDoc()));
                var n = e.getContainer();
                D.unbind(e.getBody()), D.unbind(n), e.fire("remove"), e.editorManager.remove(e), E.remove(n), e.destroy()
            }
        }, bindNative: function (e) {
            var t = this;
            t.settings.readonly || (t.initialized ? t.dom.bind(_(t, e), e, function (n) {
                t.fire(e, n)
            }) : t._pendingNativeEvents ? t._pendingNativeEvents.push(e) : t._pendingNativeEvents = [e])
        }, unbindNative: function (e) {
            var t = this;
            t.initialized && t.dom.unbind(e)
        }, destroy: function (e) {
            var t = this, n;
            if (!t.destroyed) {
                if (!e && !t.removed)return t.remove(), void 0;
                e && M && (D.unbind(t.getDoc()), D.unbind(t.getWin()), D.unbind(t.getBody())), e || (t.editorManager.off("beforeunload", t._beforeUnload), t.theme && t.theme.destroy && t.theme.destroy(), t.selection.destroy(), t.dom.destroy()), n = t.formElement, n && (n._mceOldSubmit && (n.submit = n._mceOldSubmit, n._mceOldSubmit = null), E.unbind(n, "submit reset", t.formEventDelegate)), t.contentAreaContainer = t.formElement = t.container = null, t.settings.content_element = t.bodyElement = t.contentDocument = t.contentWindow = null, t.selection && (t.selection = t.selection.win = t.selection.dom = t.selection.dom.doc = null), t.destroyed = 1
            }
        }, _refreshContentEditable: function () {
            var e = this, t, n;
            e._isHidden() && (t = e.getBody(), n = t.parentNode, n.removeChild(t), n.appendChild(t), t.focus())
        }, _isHidden: function () {
            var e;
            return M ? (e = this.selection.getSel(), !e || !e.rangeCount || 0 === e.rangeCount) : 0
        }}, T(N.prototype, x), N
    }), r(it, [], function () {
        var e = {};
        return{rtl: !1, add: function (t, n) {
            for (var r in n)e[r] = n[r];
            this.rtl = this.rtl || "rtl" === e._dir
        }, translate: function (t) {
            if ("undefined" == typeof t)return t;
            if ("string" != typeof t && t.raw)return t.raw;
            if (t.push) {
                var n = t.slice(1);
                t = (e[t[0]] || t[0]).replace(/\{([^\}]+)\}/g, function (e, t) {
                    return n[t]
                })
            }
            return e[t] || t
        }, data: e}
    }), r(ot, [g, h], function (e, t) {
        function n(r) {
            function i() {
                try {
                    return document.activeElement
                } catch (e) {
                    return document.body
                }
            }

            function o(e) {
                return e && e.startContainer ? {startContainer: e.startContainer, startOffset: e.startOffset, endContainer: e.endContainer, endOffset: e.endOffset} : e
            }

            function a(e, t) {
                var n;
                return t.startContainer ? (n = e.getDoc().createRange(), n.setStart(t.startContainer, t.startOffset), n.setEnd(t.endContainer, t.endOffset)) : n = t, n
            }

            function s(t) {
                return!!e.DOM.getParent(t, n.isEditorUIElement)
            }

            function l(e, t) {
                for (var n = t.getBody(); e;) {
                    if (e == n)return!0;
                    e = e.parentNode
                }
            }

            function c(n) {
                var c = n.editor, d;
                c.on("init", function () {
                    "onbeforedeactivate"in document && t.ie < 11 ? c.dom.bind(c.getBody(), "beforedeactivate", function () {
                        try {
                            c.lastRng = c.selection.getRng()
                        } catch (e) {
                        }
                        c.selection.lastFocusBookmark = o(c.lastRng)
                    }) : (c.inline || t.ie > 10) && (c.on("nodechange keyup", function () {
                        var e = document.activeElement;
                        e && e.id == c.id + "_ifr" && (e = c.getBody()), l(e, c) && (c.lastRng = c.selection.getRng())
                    }), t.webkit && (d = function () {
                        var e = c.selection.getRng();
                        e.collapsed || (c.lastRng = e)
                    }, e.DOM.bind(document, "selectionchange", d), c.on("remove", function () {
                        e.DOM.unbind(document, "selectionchange", d)
                    })))
                }), c.on("setcontent", function () {
                    c.lastRng = null
                }), c.on("mousedown", function () {
                    c.selection.lastFocusBookmark = null
                }), c.on("focusin", function () {
                    var e = r.focusedEditor;
                    c.selection.lastFocusBookmark && (c.selection.setRng(a(c, c.selection.lastFocusBookmark)), c.selection.lastFocusBookmark = null), e != c && (e && e.fire("blur", {focusedEditor: c}), r.activeEditor = c, r.focusedEditor = c, c.fire("focus", {blurredEditor: e}), c.focus(!1)), c.lastRng = null
                }), c.on("focusout", function () {
                    window.setTimeout(function () {
                        var e = r.focusedEditor;
                        s(i()) || e != c || (c.fire("blur", {focusedEditor: null}), r.focusedEditor = null, c.selection.lastFocusBookmark = null)
                    }, 0)
                })
            }

            e.DOM.bind(document, "focusin", function (e) {
                var t = r.activeEditor;
                t && e.target.ownerDocument == document && (t.selection.lastFocusBookmark = o(t.lastRng), s(e.target) || r.focusedEditor != t || (t.fire("blur", {focusedEditor: null}), r.focusedEditor = null))
            }), r.on("AddEditor", c)
        }

        return n.isEditorUIElement = function (e) {
            return-1 !== e.className.indexOf("mce-")
        }, n
    }), r(at, [rt, g, P, h, f, tt, it, ot], function (e, n, r, i, o, a, s, l) {
        var c = n.DOM, d = o.explode, u = o.each, f = o.extend, p = 0, m, h = {majorVersion: "4", minorVersion: "0.12", releaseDate: "2013-12-18", editors: [], i18n: s, activeEditor: null, setup: function () {
            var e = this, t, n, i = "", o;
            if (n = document.location.href.replace(/[\?#].*$/, "").replace(/[\/\\][^\/]+$/, ""), /[\/\\]$/.test(n) || (n += "/"), o = window.tinymce || window.tinyMCEPreInit)t = o.base || o.baseURL, i = o.suffix; else for (var a = document.getElementsByTagName("script"), s = 0; s < a.length; s++) {
                var c = a[s].src;
                if (/tinymce(\.full|\.jquery|)(\.min|\.dev|)\.js/.test(c)) {
                    -1 != c.indexOf(".min") && (i = ".min"), t = c.substring(0, c.lastIndexOf("/"));
                    break
                }
            }
            e.baseURL = new r(n).toAbsolute(t), e.documentBaseURL = n, e.baseURI = new r(e.baseURL), e.suffix = i, e.focusManager = new l(e)
        }, init: function (t) {
            function n(e) {
                var t = e.id;
                return t || (t = e.name, t = t && !c.get(t) ? e.name : c.uniqueId(), e.setAttribute("id", t)), t
            }

            function r(e, t, n) {
                var r = e[t];
                if (r)return r.apply(n || this, Array.prototype.slice.call(arguments, 2))
            }

            function i(e, t) {
                return t.constructor === RegExp ? t.test(e.className) : c.hasClass(e, t)
            }

            function o() {
                var m, h;
                if (c.unbind(window, "ready", o), r(t, "onpageload"), t.types)return u(t.types, function (r) {
                    u(c.select(r.selector), function (i) {
                        var o = new e(n(i), f({}, t, r), a);
                        s.push(o), o.render(1)
                    })
                }), void 0;
                if (t.selector)return u(c.select(t.selector), function (r) {
                    var i = new e(n(r), t, a);
                    s.push(i), i.render(1)
                }), void 0;
                switch (t.mode) {
                    case"exact":
                        m = t.elements || "", m.length > 0 && u(d(m), function (n) {
                            c.get(n) ? (l = new e(n, t, a), s.push(l), l.render(!0)) : u(document.forms, function (r) {
                                u(r.elements, function (r) {
                                    r.name === n && (n = "mce_editor_" + p++, c.setAttrib(r, "id", n), l = new e(n, t, a), s.push(l), l.render(1))
                                })
                            })
                        });
                        break;
                    case"textareas":
                    case"specific_textareas":
                        u(c.select("textarea"), function (r) {
                            t.editor_deselector && i(r, t.editor_deselector) || (!t.editor_selector || i(r, t.editor_selector)) && (l = new e(n(r), t, a), s.push(l), l.render(!0))
                        })
                }
                t.oninit && (m = h = 0, u(s, function (e) {
                    h++, e.initialized ? m++ : e.on("init", function () {
                        m++, m == h && r(t, "oninit")
                    }), m == h && r(t, "oninit")
                }))
            }

            var a = this, s = [], l;
            a.settings = t, c.bind(window, "ready", o)
        }, get: function (e) {
            return e === t ? this.editors : this.editors[e]
        }, add: function (e) {
            var t = this, n = t.editors;
            return n[e.id] = e, n.push(e), t.activeEditor = e, t.fire("AddEditor", {editor: e}), m || (m = function () {
                t.fire("BeforeUnload")
            }, c.bind(window, "beforeunload", m)), e
        }, createEditor: function (t, n) {
            return this.add(new e(t, n, this))
        }, remove: function (e) {
            var t = this, n, r = t.editors, i, o;
            {
                if (e) {
                    if ("string" == typeof e)return e = e.selector || e, u(c.select(e), function (e) {
                        t.remove(r[e.id])
                    }), void 0;
                    if (i = e, !r[i.id])return null;
                    for (delete r[i.id], n = 0; n < r.length; n++)if (r[n] == i) {
                        r.splice(n, 1), o = !0;
                        break
                    }
                    return t.activeEditor == i && (t.activeEditor = r[0]), o && t.fire("RemoveEditor", {editor: i}), r.length || c.unbind(window, "beforeunload", m), i.remove(), i
                }
                for (n = r.length - 1; n >= 0; n--)t.remove(r[n])
            }
        }, execCommand: function (t, n, r) {
            var i = this, o = i.get(r);
            switch (t) {
                case"mceAddEditor":
                    return i.get(r) || new e(r, i.settings, i).render(), !0;
                case"mceRemoveEditor":
                    return o && o.remove(), !0;
                case"mceToggleEditor":
                    return o ? (o.isHidden() ? o.show() : o.hide(), !0) : (i.execCommand("mceAddEditor", 0, r), !0)
            }
            return i.activeEditor ? i.activeEditor.execCommand(t, n, r) : !1
        }, triggerSave: function () {
            u(this.editors, function (e) {
                e.save()
            })
        }, addI18n: function (e, t) {
            s.add(e, t)
        }, translate: function (e) {
            return s.translate(e)
        }};
        return f(h, a), h.setup(), window.tinymce = window.tinyMCE = h, h
    }), r(st, [at, f], function (e, t) {
        var n = t.each, r = t.explode;
        e.on("AddEditor", function (e) {
            var t = e.editor;
            t.on("preInit", function () {
                function e(e, t) {
                    n(t, function (t, n) {
                        t && s.setStyle(e, n, t)
                    }), s.rename(e, "span")
                }

                function i(e) {
                    s = t.dom, l.convert_fonts_to_spans && n(s.select("font,u,strike", e.node), function (e) {
                        o[e.nodeName.toLowerCase()](s, e)
                    })
                }

                var o, a, s, l = t.settings;
                l.inline_styles && (a = r(l.font_size_legacy_values), o = {font: function (t, n) {
                    e(n, {backgroundColor: n.style.backgroundColor, color: n.color, fontFamily: n.face, fontSize: a[parseInt(n.size, 10) - 1]})
                }, u: function (t, n) {
                    e(n, {textDecoration: "underline"})
                }, strike: function (t, n) {
                    e(n, {textDecoration: "line-through"})
                }}, t.on("PreProcess SetContent", i))
            })
        })
    }), r(lt, [], function () {
        return{send: function (e) {
            function t() {
                !e.async || 4 == n.readyState || r++ > 1e4 ? (e.success && 1e4 > r && 200 == n.status ? e.success.call(e.success_scope, "" + n.responseText, n, e) : e.error && e.error.call(e.error_scope, r > 1e4 ? "TIMED_OUT" : "GENERAL", n, e), n = null) : setTimeout(t, 10)
            }

            var n, r = 0;
            if (e.scope = e.scope || this, e.success_scope = e.success_scope || e.scope, e.error_scope = e.error_scope || e.scope, e.async = e.async === !1 ? !1 : !0, e.data = e.data || "", n = new XMLHttpRequest) {
                if (n.overrideMimeType && n.overrideMimeType(e.content_type), n.open(e.type || (e.data ? "POST" : "GET"), e.url, e.async), e.content_type && n.setRequestHeader("Content-Type", e.content_type), n.setRequestHeader("X-Requested-With", "XMLHttpRequest"), n.send(e.data), !e.async)return t();
                setTimeout(t, 10)
            }
        }}
    }), r(ct, [], function () {
        function e(t, n) {
            var r, i, o, a;
            if (n = n || '"', null === t)return"null";
            if (o = typeof t, "string" == o)return i = "\bb	t\nn\ff\rr\"\"''\\\\", n + t.replace(/([\u0080-\uFFFF\x00-\x1f\"\'\\])/g, function (e, t) {
                return'"' === n && "'" === e ? e : (r = i.indexOf(t), r + 1 ? "\\" + i.charAt(r + 1) : (e = t.charCodeAt().toString(16), "\\u" + "0000".substring(e.length) + e))
            }) + n;
            if ("object" == o) {
                if (t.hasOwnProperty && "[object Array]" === Object.prototype.toString.call(t)) {
                    for (r = 0, i = "["; r < t.length; r++)i += (r > 0 ? "," : "") + e(t[r], n);
                    return i + "]"
                }
                i = "{";
                for (a in t)t.hasOwnProperty(a) && (i += "function" != typeof t[a] ? (i.length > 1 ? "," + n : n) + a + n + ":" + e(t[a], n) : "");
                return i + "}"
            }
            return"" + t
        }

        return{serialize: e, parse: function (e) {
            try {
                return window[String.fromCharCode(101) + "val"]("(" + e + ")")
            } catch (t) {
            }
        }}
    }), r(dt, [ct, lt, f], function (e, t, n) {
        function r(e) {
            this.settings = i({}, e), this.count = 0
        }

        var i = n.extend;
        return r.sendRPC = function (e) {
            return(new r).send(e)
        }, r.prototype = {send: function (n) {
            var r = n.error, o = n.success;
            n = i(this.settings, n), n.success = function (t, i) {
                t = e.parse(t), "undefined" == typeof t && (t = {error: "JSON Parse error."}), t.error ? r.call(n.error_scope || n.scope, t.error, i) : o.call(n.success_scope || n.scope, t.result)
            }, n.error = function (e, t) {
                r && r.call(n.error_scope || n.scope, e, t)
            }, n.data = e.serialize({id: n.id || "c" + this.count++, method: n.method, params: n.params}), n.content_type = "application/json", t.send(n)
        }}, r
    }), r(ut, [g], function (e) {
        return{callbacks: {}, count: 0, send: function (n) {
            var r = this, i = e.DOM, o = n.count !== t ? n.count : r.count, a = "tinymce_jsonp_" + o;
            r.callbacks[o] = function (e) {
                i.remove(a), delete r.callbacks[o], n.callback(e)
            }, i.add(i.doc.body, "script", {id: a, src: n.url, type: "text/javascript"}), r.count++
        }}
    }), r(ft, [], function () {
        function e() {
            s = [];
            for (var e in a)s.push(e);
            i.length = s.length
        }

        function n() {
            function n(e) {
                var n, r;
                return r = e !== t ? d + e : i.indexOf(",", d), -1 === r || r > i.length ? null : (n = i.substring(d, r), d = r + 1, n)
            }

            var r, i, s, d = 0;
            if (a = {}, c) {
                o.load(l), i = o.getAttribute(l) || "";
                do {
                    var u = n();
                    if (null === u)break;
                    if (r = n(parseInt(u, 32) || 0), null !== r) {
                        if (u = n(), null === u)break;
                        s = n(parseInt(u, 32) || 0), r && (a[r] = s)
                    }
                } while (null !== r);
                e()
            }
        }

        function r() {
            var t, n = "";
            if (c) {
                for (var r in a)t = a[r], n += (n ? "," : "") + r.length.toString(32) + "," + r + "," + t.length.toString(32) + "," + t;
                o.setAttribute(l, n);
                try {
                    o.save(l)
                } catch (i) {
                }
                e()
            }
        }

        var i, o, a, s, l, c;
        try {
            if (window.localStorage)return localStorage
        } catch (d) {
        }
        return l = "tinymce", o = document.documentElement, c = !!o.addBehavior, c && o.addBehavior("#default#userData"), i = {key: function (e) {
            return s[e]
        }, getItem: function (e) {
            return e in a ? a[e] : null
        }, setItem: function (e, t) {
            a[e] = "" + t, r()
        }, removeItem: function (e) {
            delete a[e], r()
        }, clear: function () {
            a = {}, r()
        }}, n(), i
    }), r(pt, [g, d, v, y, f, h], function (e, t, n, r, i, o) {
        var a = window.tinymce;
        return a.DOM = e.DOM, a.ScriptLoader = n.ScriptLoader, a.PluginManager = r.PluginManager, a.ThemeManager = r.ThemeManager, a.dom = a.dom || {}, a.dom.Event = t.Event, i.each(i, function (e, t) {
            a[t] = e
        }), i.each("isOpera isWebKit isIE isGecko isMac".split(" "), function (e) {
            a[e] = o[e.substr(2).toLowerCase()]
        }), {}
    }), r(mt, [O, f], function (e, t) {
        return e.extend({Defaults: {firstControlClass: "first", lastControlClass: "last"}, init: function (e) {
            this.settings = t.extend({}, this.Defaults, e)
        }, preRender: function (e) {
            e.addClass(this.settings.containerClass, "body")
        }, applyClasses: function (e) {
            var t = this, n = t.settings, r, i, o;
            r = e.items().filter(":visible"), i = n.firstControlClass, o = n.lastControlClass, r.each(function (e) {
                e.removeClass(i).removeClass(o), n.controlClass && e.addClass(n.controlClass)
            }), r.eq(0).addClass(i), r.eq(-1).addClass(o)
        }, renderHtml: function (e) {
            var t = this, n = t.settings, r, i = "";
            return r = e.items(), r.eq(0).addClass(n.firstControlClass), r.eq(-1).addClass(n.lastControlClass), r.each(function (e) {
                n.controlClass && e.addClass(n.controlClass), i += e.renderHtml()
            }), i
        }, recalc: function () {
        }, postRender: function () {
        }})
    }), r(ht, [mt], function (e) {
        return e.extend({Defaults: {containerClass: "abs-layout", controlClass: "abs-layout-item"}, recalc: function (e) {
            e.items().filter(":visible").each(function (e) {
                var t = e.settings;
                e.layoutRect({x: t.x, y: t.y, w: t.w, h: t.h}), e.recalc && e.recalc()
            })
        }, renderHtml: function (e) {
            return'<div id="' + e._id + '-absend" class="' + e.classPrefix + 'abs-end"></div>' + this._super(e)
        }})
    }), r(gt, [W, K], function (e, t) {
        return e.extend({Mixins: [t], Defaults: {classes: "widget tooltip tooltip-n"}, text: function (e) {
            var t = this;
            return"undefined" != typeof e ? (t._value = e, t._rendered && (t.getEl().lastChild.innerHTML = t.encode(e)), t) : t._value
        }, renderHtml: function () {
            var e = this, t = e.classPrefix;
            return'<div id="' + e._id + '" class="' + e.classes() + '" role="presentation"><div class="' + t + 'tooltip-arrow"></div><div class="' + t + 'tooltip-inner">' + e.encode(e._text) + "</div></div>"
        }, repaint: function () {
            var e = this, t, n;
            t = e.getEl().style, n = e._layoutRect, t.left = n.x + "px", t.top = n.y + "px", t.zIndex = 131070
        }})
    }), r(vt, [W, gt], function (e, t) {
        var n, r = e.extend({init: function (e) {
            var t = this;
            t._super(e), t.canFocus = !0, e.tooltip && r.tooltips !== !1 && (t.on("mouseenter", function (n) {
                var r = t.tooltip().moveTo(-65535);
                if (n.control == t) {
                    var i = r.text(e.tooltip).show().testMoveRel(t.getEl(), ["bc-tc", "bc-tl", "bc-tr"]);
                    r.toggleClass("tooltip-n", "bc-tc" == i), r.toggleClass("tooltip-nw", "bc-tl" == i), r.toggleClass("tooltip-ne", "bc-tr" == i), r.moveRel(t.getEl(), i)
                } else r.hide()
            }), t.on("mouseleave mousedown click", function () {
                t.tooltip().hide()
            })), t.aria("label", e.tooltip)
        }, tooltip: function () {
            var e = this;
            return n || (n = new t({type: "tooltip"}), n.renderTo(e.getContainerElm())), n
        }, active: function (e) {
            var t = this, n;
            return e !== n && (t.aria("pressed", e), t.toggleClass("active", e)), t._super(e)
        }, disabled: function (e) {
            var t = this, n;
            return e !== n && (t.aria("disabled", e), t.toggleClass("disabled", e)), t._super(e)
        }, postRender: function () {
            var e = this, t = e.settings;
            e._rendered = !0, e._super(), e.parent() || !t.width && !t.height || (e.initLayoutRect(), e.repaint()), t.autofocus && setTimeout(function () {
                e.focus()
            }, 0)
        }, remove: function () {
            this._super(), n && (n.remove(), n = null)
        }});
        return r
    }), r(yt, [vt], function (e) {
        return e.extend({Defaults: {classes: "widget btn", role: "button"}, init: function (e) {
            var t = this, n;
            t.on("click mousedown", function (e) {
                e.preventDefault()
            }), t._super(e), n = e.size, e.subtype && t.addClass(e.subtype), n && t.addClass("btn-" + n)
        }, icon: function (e) {
            var t = this, n = t.classPrefix;
            if ("undefined" == typeof e)return t.settings.icon;
            if (t.settings.icon = e, e = e ? n + "ico " + n + "i-" + t.settings.icon : "", t._rendered) {
                var r = t.getEl().firstChild, i = r.getElementsByTagName("i")[0];
                e ? (i && i == r.firstChild || (i = document.createElement("i"), r.insertBefore(i, r.firstChild)), i.className = e) : i && r.removeChild(i), t.text(t._text)
            }
            return t
        }, repaint: function () {
            var e = this.getEl().firstChild.style;
            e.width = e.height = "100%", this._super()
        }, renderHtml: function () {
            var e = this, t = e._id, n = e.classPrefix, r = e.settings.icon, i = "";
            return e.settings.image && (r = "none", i = " style=\"background-image: url('" + e.settings.image + "')\""), r = e.settings.icon ? n + "ico " + n + "i-" + r : "", '<div id="' + t + '" class="' + e.classes() + '" tabindex="-1"><button role="presentation" type="button" tabindex="-1">' + (r ? '<i class="' + r + '"' + i + "></i>" : "") + (e._text ? (r ? "\xa0" : "") + e.encode(e._text) : "") + "</button></div>"
        }})
    }), r(bt, [U], function (e) {
        return e.extend({Defaults: {defaultType: "button", role: "toolbar"}, renderHtml: function () {
            var e = this, t = e._layout;
            return e.addClass("btn-group"), e.preRender(), t.preRender(e), '<div id="' + e._id + '" class="' + e.classes() + '"><div id="' + e._id + '-body">' + (e.settings.html || "") + t.renderHtml(e) + "</div></div>"
        }})
    }), r(Ct, [vt], function (e) {
        return e.extend({Defaults: {classes: "checkbox", role: "checkbox", checked: !1}, init: function (e) {
            var t = this;
            t._super(e), t.on("click mousedown", function (e) {
                e.preventDefault()
            }), t.on("click", function (e) {
                e.preventDefault(), t.disabled() || t.checked(!t.checked())
            }), t.checked(t.settings.checked)
        }, checked: function (e) {
            var t = this;
            return"undefined" != typeof e ? (e ? t.addClass("checked") : t.removeClass("checked"), t._checked = e, t.aria("checked", e), t) : t._checked
        }, value: function (e) {
            return this.checked(e)
        }, renderHtml: function () {
            var e = this, t = e._id, n = e.classPrefix;
            return'<div id="' + t + '" class="' + e.classes() + '" unselectable="on" aria-labeledby="' + t + '-al" tabindex="-1"><i class="' + n + "ico " + n + 'i-checkbox"></i><span id="' + t + '-al" class="' + n + 'label">' + e.encode(e._text) + "</span></div>"
        }})
    }), r(xt, [yt, G], function (e, t) {
        return e.extend({showPanel: function () {
            var e = this, n = e.settings;
            if (e.active(!0), e.panel)e.panel.show(); else {
                var r = n.panel;
                r.type && (r = {layout: "grid", items: r}), r.popover = !0, r.autohide = !0, e.panel = new t(r).on("hide",function () {
                    e.active(!1)
                }).parent(e).renderTo(e.getContainerElm()), e.panel.fire("show"), e.panel.reflow()
            }
            e.panel.moveRel(e.getEl(), n.popoverAlign || (e.isRtl() ? ["bc-tr", "bc-tc"] : ["bc-tl", "bc-tc"]))
        }, hidePanel: function () {
            var e = this;
            e.panel && e.panel.hide()
        }, postRender: function () {
            var e = this;
            return e.on("click", function (t) {
                t.control === e && (e.panel && e.panel.visible() ? e.hidePanel() : e.showPanel())
            }), e._super()
        }})
    }), r(wt, [xt, g], function (e, t) {
        var n = t.DOM;
        return e.extend({init: function (e) {
            this._super(e), this.addClass("colorbutton")
        }, color: function (e) {
            return e ? (this._color = e, this.getEl("preview").style.backgroundColor = e, this) : this._color
        }, renderHtml: function () {
            var e = this, t = e._id, n = e.classPrefix, r = e.settings.icon ? n + "ico " + n + "i-" + e.settings.icon : "", i = e.settings.image ? " style=\"background-image: url('" + e.settings.image + "')\"" : "";
            return'<div id="' + t + '" class="' + e.classes() + '"><button role="presentation" hidefocus type="button" tabindex="-1">' + (r ? '<i class="' + r + '"' + i + "></i>" : "") + '<span id="' + t + '-preview" class="' + n + 'preview"></span>' + (e._text ? (r ? " " : "") + e._text : "") + '</button><button type="button" class="' + n + 'open" hidefocus tabindex="-1"> <i class="' + n + 'caret"></i></button></div>'
        }, postRender: function () {
            var e = this, t = e.settings.onclick;
            return e.on("click", function (r) {
                r.control != e || n.getParent(r.target, "." + e.classPrefix + "open") || (r.stopImmediatePropagation(), t.call(e, r))
            }), delete e.settings.onclick, e._super()
        }})
    }), r(_t, [vt, z], function (e, t) {
        return e.extend({init: function (e) {
            var n = this;
            n._super(e), n.addClass("combobox"), n.on("click", function (e) {
                for (var t = e.target; t;)t.id && -1 != t.id.indexOf("-open") && n.fire("action"), t = t.parentNode
            }), n.on("keydown", function (e) {
                "INPUT" == e.target.nodeName && 13 == e.keyCode && n.parents().reverse().each(function (t) {
                    return e.preventDefault(), n.fire("change"), t.hasEventListeners("submit") && t.toJSON ? (t.fire("submit", {data: t.toJSON()}), !1) : void 0
                })
            }), e.placeholder && (n.addClass("placeholder"), n.on("focusin", function () {
                n._hasOnChange || (t.on(n.getEl("inp"), "change", function () {
                    n.fire("change")
                }), n._hasOnChange = !0), n.hasClass("placeholder") && (n.getEl("inp").value = "", n.removeClass("placeholder"))
            }), n.on("focusout", function () {
                0 === n.value().length && (n.getEl("inp").value = e.placeholder, n.addClass("placeholder"))
            }))
        }, value: function (e) {
            var t = this;
            return"undefined" != typeof e ? (t._value = e, t.removeClass("placeholder"), t._rendered && (t.getEl("inp").value = e), t) : t._rendered ? (e = t.getEl("inp").value, e != t.settings.placeholder ? e : "") : t._value
        }, disabled: function (e) {
            var t = this;
            return t._rendered && "undefined" != typeof e && (t.getEl("inp").disabled = e), t._super(e)
        }, focus: function () {
            this.getEl("inp").focus()
        }, repaint: function () {
            var e = this, n = e.getEl(), r = e.getEl("open"), i = e.layoutRect(), o, a;
            o = r ? i.w - t.getSize(r).width - 10 : i.w - 10;
            var s = document;
            return s.all && (!s.documentMode || s.documentMode <= 8) && (a = e.layoutRect().h - 2 + "px"), t.css(n.firstChild, {width: o, lineHeight: a}), e._super(), e
        }, postRender: function () {
            var e = this;
            return t.on(this.getEl("inp"), "change", function () {
                e.fire("change")
            }), e._super()
        }, remove: function () {
            t.off(this.getEl("inp")), this._super()
        }, renderHtml: function () {
            var e = this, t = e._id, n = e.settings, r = e.classPrefix, i = n.value || n.placeholder || "", o, a, s = "";
            return o = n.icon ? r + "ico " + r + "i-" + n.icon : "", a = e._text, (o || a) && (s = '<div id="' + t + '-open" class="' + r + "btn " + r + 'open" tabIndex="-1"><button id="' + t + '-action" type="button" hidefocus tabindex="-1">' + (o ? '<i class="' + o + '"></i>' : '<i class="' + r + 'caret"></i>') + (a ? (o ? " " : "") + a : "") + "</button></div>", e.addClass("has-open")), '<div id="' + t + '" class="' + e.classes() + '"><input id="' + t + '-inp" class="' + r + "textbox " + r + 'placeholder" value="' + i + '" hidefocus="true"' + (e.disabled() ? ' disabled="disabled"' : "") + ">" + s + "</div>"
        }})
    }), r(Nt, [vt, X], function (e, t) {
        return e.extend({init: function (e) {
            var t = this;
            e.delimiter || (e.delimiter = "\xbb"), t._super(e), t.addClass("path"), t.canFocus = !0, t.on("click", function (e) {
                var n, r = e.target;
                (n = r.getAttribute("data-index")) && t.fire("select", {value: t.data()[n], index: n})
            })
        }, focus: function () {
            var e = this;
            return e.keyNav = new t({root: e, enableLeftRight: !0}), e.keyNav.focusFirst(), e
        }, data: function (e) {
            var t = this;
            return"undefined" != typeof e ? (t._data = e, t.update(), t) : t._data
        }, update: function () {
            this.innerHtml(this._getPathHtml())
        }, postRender: function () {
            var e = this;
            e._super(), e.data(e.settings.data)
        }, renderHtml: function () {
            var e = this;
            return'<div id="' + e._id + '" class="' + e.classes() + '">' + e._getPathHtml() + "</div>"
        }, _getPathHtml: function () {
            var e = this, t = e._data || [], n, r, i = "", o = e.classPrefix;
            for (n = 0, r = t.length; r > n; n++)i += (n > 0 ? '<div class="' + o + 'divider" aria-hidden="true"> ' + e.settings.delimiter + " </div>" : "") + '<div role="button" class="' + o + "path-item" + (n == r - 1 ? " " + o + "last" : "") + '" data-index="' + n + '" tabindex="-1" id="' + e._id + "-" + n + '">' + t[n].name + "</div>";
            return i || (i = '<div class="' + o + 'path-item">&nbsp;</div>'), i
        }})
    }), r(Et, [Nt, at], function (e, t) {
        return e.extend({postRender: function () {
            function e(e) {
                if (1 === e.nodeType) {
                    if ("BR" == e.nodeName || e.getAttribute("data-mce-bogus"))return!0;
                    if ("bookmark" === e.getAttribute("data-mce-type"))return!0
                }
                return!1
            }

            var n = this, r = t.activeEditor;
            return n.on("select", function (t) {
                var n = [], i, o = r.getBody();
                for (r.focus(), i = r.selection.getStart(); i && i != o;)e(i) || n.push(i), i = i.parentNode;
                r.selection.select(n[n.length - 1 - t.index]), r.nodeChanged()
            }), r.on("nodeChange", function (t) {
                for (var i = [], o = t.parents, a = o.length; a--;)if (1 == o[a].nodeType && !e(o[a])) {
                    var s = r.fire("ResolveName", {name: o[a].nodeName.toLowerCase(), target: o[a]});
                    i.push({name: s.name})
                }
                n.data(i)
            }), n._super()
        }})
    }), r(kt, [U], function (e) {
        return e.extend({Defaults: {layout: "flex", align: "center", defaults: {flex: 1}}, renderHtml: function () {
            var e = this, t = e._layout, n = e.classPrefix;
            return e.addClass("formitem"), t.preRender(e), '<div id="' + e._id + '" class="' + e.classes() + '" hideFocus="1" tabIndex="-1">' + (e.settings.title ? '<div id="' + e._id + '-title" class="' + n + 'title">' + e.settings.title + "</div>" : "") + '<div id="' + e._id + '-body" class="' + e.classes("body") + '">' + (e.settings.html || "") + t.renderHtml(e) + "</div></div>"
        }})
    }), r(St, [U, kt], function (e, t) {
        return e.extend({Defaults: {containerCls: "form", layout: "flex", direction: "column", align: "stretch", flex: 1, padding: 20, labelGap: 30, spacing: 10, callbacks: {submit: function () {
            this.submit()
        }}}, preRender: function () {
            var e = this, n = e.items();
            n.each(function (n) {
                var r, i = n.settings.label;
                i && (r = new t({layout: "flex", autoResize: "overflow", defaults: {flex: 1}, items: [
                    {type: "label", text: i, flex: 0, forId: n._id}
                ]}), r.type = "formitem", "undefined" == typeof n.settings.flex && (n.settings.flex = 1), e.replace(n, r), r.add(n))
            })
        }, recalcLabels: function () {
            var e = this, t = 0, n = [], r, i;
            if (e.settings.labelGapCalc !== !1)for (e.items().filter("formitem").each(function (e) {
                var r = e.items()[0], i = r.getEl().clientWidth;
                t = i > t ? i : t, n.push(r)
            }), i = e.settings.labelGap || 0, r = n.length; r--;)n[r].settings.minWidth = t + i
        }, visible: function (e) {
            var t = this._super(e);
            return e === !0 && this._rendered && this.recalcLabels(), t
        }, submit: function () {
            return this.fire("submit", {data: this.toJSON()})
        }, postRender: function () {
            var e = this;
            e._super(), e.recalcLabels(), e.fromJSON(e.settings.data)
        }})
    }), r(Tt, [St], function (e) {
        return e.extend({Defaults: {containerCls: "fieldset", layout: "flex", direction: "column", align: "stretch", flex: 1, padding: "25 15 5 15", labelGap: 30, spacing: 10, border: 1}, renderHtml: function () {
            var e = this, t = e._layout, n = e.classPrefix;
            return e.preRender(), t.preRender(e), '<fieldset id="' + e._id + '" class="' + e.classes() + '" hideFocus="1" tabIndex="-1">' + (e.settings.title ? '<legend id="' + e._id + '-title" class="' + n + 'fieldset-title">' + e.settings.title + "</legend>" : "") + '<div id="' + e._id + '-body" class="' + e.classes("body") + '">' + (e.settings.html || "") + t.renderHtml(e) + "</div></fieldset>"
        }})
    }), r(Rt, [_t], function (e) {
        return e.extend({init: function (e) {
            var t = this, n = tinymce.activeEditor, r;
            e.spellcheck = !1, r = n.settings.file_browser_callback, r && (e.icon = "browse", e.onaction = function () {
                r(t.getEl("inp").id, t.getEl("inp").value, e.filetype, window)
            }), t._super(e)
        }})
    }), r(At, [ht], function (e) {
        return e.extend({recalc: function (e) {
            var t = e.layoutRect(), n = e.paddingBox();
            e.items().filter(":visible").each(function (e) {
                e.layoutRect({x: n.left, y: n.top, w: t.innerW - n.right - n.left, h: t.innerH - n.top - n.bottom}), e.recalc && e.recalc()
            })
        }})
    }), r(Bt, [ht], function (e) {
        return e.extend({recalc: function (e) {
            var t, n, r, i, o, a, s, l, c, d, u, f, p, m, h, g, v = [], y, b, C, x, w, _, N, E, k, S, T, R, A, B, L, H, D, M, P, O, I, F, z, W, V = Math.max, U = Math.min;
            for (r = e.items().filter(":visible"), i = e.layoutRect(), o = e._paddingBox, a = e.settings, f = e.isRtl() ? a.direction || "row-reversed" : a.direction, s = a.align, l = e.isRtl() ? a.pack || "end" : a.pack, c = a.spacing || 0, ("row-reversed" == f || "column-reverse" == f) && (r = r.set(r.toArray().reverse()), f = f.split("-")[0]), "column" == f ? (k = "y", N = "h", E = "minH", S = "maxH", R = "innerH", T = "top", A = "bottom", B = "deltaH", L = "contentH", I = "left", M = "w", H = "x", D = "innerW", P = "minW", O = "maxW", F = "right", z = "deltaW", W = "contentW") : (k = "x", N = "w", E = "minW", S = "maxW", R = "innerW", T = "left", A = "right", B = "deltaW", L = "contentW", I = "top", M = "h", H = "y", D = "innerH", P = "minH", O = "maxH", F = "bottom", z = "deltaH", W = "contentH"), u = i[R] - o[T] - o[T], _ = d = 0, t = 0, n = r.length; n > t; t++)p = r[t], m = p.layoutRect(), h = p.settings, g = h.flex, u -= n - 1 > t ? c : 0, g > 0 && (d += g, m[S] && v.push(p), m.flex = g), u -= m[E], y = o[I] + m[P] + o[F], y > _ && (_ = y);
            if (x = {}, x[E] = 0 > u ? i[E] - u + i[B] : i[R] - u + i[B], x[P] = _ + i[z], x[L] = i[R] - u, x[W] = _, x.minW = U(x.minW, i.maxW), x.minH = U(x.minH, i.maxH), x.minW = V(x.minW, i.startMinWidth), x.minH = V(x.minH, i.startMinHeight), !i.autoResize || x.minW == i.minW && x.minH == i.minH) {
                for (C = u / d, t = 0, n = v.length; n > t; t++)p = v[t], m = p.layoutRect(), b = m[S], y = m[E] + m.flex * C, y > b ? (u -= m[S] - m[E], d -= m.flex, m.flex = 0, m.maxFlexSize = b) : m.maxFlexSize = 0;
                for (C = u / d, w = o[T], x = {}, 0 === d && ("end" == l ? w = u + o[T] : "center" == l ? (w = Math.round(i[R] / 2 - (i[R] - u) / 2) + o[T], 0 > w && (w = o[T])) : "justify" == l && (w = o[T], c = Math.floor(u / (r.length - 1)))), x[H] = o[I], t = 0, n = r.length; n > t; t++)p = r[t], m = p.layoutRect(), y = m.maxFlexSize || m[E], "center" === s ? x[H] = Math.round(i[D] / 2 - m[M] / 2) : "stretch" === s ? (x[M] = V(m[P] || 0, i[D] - o[I] - o[F]), x[H] = o[I]) : "end" === s && (x[H] = i[D] - m[M] - o.top), m.flex > 0 && (y += m.flex * C), x[N] = y, x[k] = w, p.layoutRect(x), p.recalc && p.recalc(), w += y + c
            } else if (x.w = x.minW, x.h = x.minH, e.layoutRect(x), this.recalc(e), null === e._lastRect) {
                var q = e.parent();
                q && (q._lastRect = null, q.recalc())
            }
        }})
    }), r(Lt, [mt], function (e) {
        return e.extend({Defaults: {containerClass: "flow-layout", controlClass: "flow-layout-item", endClass: "break"}, recalc: function (e) {
            e.items().filter(":visible").each(function (e) {
                e.recalc && e.recalc()
            })
        }})
    }), r(Ht, [W, vt, G, f, at, h], function (e, t, n, r, i, o) {
        function a(e) {
            function t(t) {
                function n(e) {
                    return e.replace(/%(\w+)/g, "")
                }

                var r, i, o = e.dom, a = "", l, c;
                return c = e.settings.preview_styles, c === !1 ? "" : (c || (c = "font-family font-size font-weight font-style text-decoration text-transform color background-color border border-radius"), (t = e.formatter.get(t)) ? (t = t[0], r = t.block || t.inline || "span", i = o.create(r), s(t.styles, function (e, t) {
                    e = n(e), e && o.setStyle(i, t, e)
                }), s(t.attributes, function (e, t) {
                    e = n(e), e && o.setAttrib(i, t, e)
                }), s(t.classes, function (e) {
                    e = n(e), o.hasClass(i, e) || o.addClass(i, e)
                }), e.fire("PreviewFormats"), o.setStyles(i, {position: "absolute", left: -65535}), e.getBody().appendChild(i), l = o.getStyle(e.getBody(), "fontSize", !0), l = /px$/.test(l) ? parseInt(l, 10) : 0, s(c.split(" "), function (t) {
                    var n = o.getStyle(i, t, !0);
                    if (!("background-color" == t && /transparent|rgba\s*\([^)]+,\s*0\)/.test(n) && (n = o.getStyle(e.getBody(), t, !0), "#ffffff" == o.toHex(n).toLowerCase()) || "color" == t && "#000000" == o.toHex(n).toLowerCase())) {
                        if ("font-size" == t && /em|%$/.test(n)) {
                            if (0 === l)return;
                            n = parseFloat(n, 10) / (/%$/.test(n) ? 100 : 1), n = n * l + "px"
                        }
                        "border" == t && n && (a += "padding:0 2px;"), a += t + ":" + n + ";"
                    }
                }), e.fire("AfterPreviewFormats"), o.remove(i), a) : void 0)
            }

            function r(t, n) {
                return function () {
                    var r = this;
                    e.on("nodeChange", function (i) {
                        var o = e.formatter, a = null;
                        s(i.parents, function (e) {
                            return s(t, function (t) {
                                return n ? o.matchNode(e, n, {value: t.value}) && (a = t.value) : o.matchNode(e, t.value) && (a = t.value), a ? !1 : void 0
                            }), a ? !1 : void 0
                        }), r.value(a)
                    })
                }
            }

            function i(e) {
                e = e.split(";");
                for (var t = e.length; t--;)e[t] = e[t].split("=");
                return e
            }

            function o() {
                function n(e) {
                    var t = [];
                    if (e)return s(e, function (e) {
                        var o = {text: e.title, icon: e.icon};
                        if (e.items)o.menu = n(e.items); else {
                            var a = e.format || "custom" + r++;
                            e.format || (e.name = a, i.push(e)), o.format = a
                        }
                        t.push(o)
                    }), t
                }

                var r = 0, i = [], o = [
                    {title: "Headers", items: [
                        {title: "Header 1", format: "h1"},
                        {title: "Header 2", format: "h2"},
                        {title: "Header 3", format: "h3"},
                        {title: "Header 4", format: "h4"},
                        {title: "Header 5", format: "h5"},
                        {title: "Header 6", format: "h6"}
                    ]},
                    {title: "Inline", items: [
                        {title: "Bold", icon: "bold", format: "bold"},
                        {title: "Italic", icon: "italic", format: "italic"},
                        {title: "Underline", icon: "underline", format: "underline"},
                        {title: "Strikethrough", icon: "strikethrough", format: "strikethrough"},
                        {title: "Superscript", icon: "superscript", format: "superscript"},
                        {title: "Subscript", icon: "subscript", format: "subscript"},
                        {title: "Code", icon: "code", format: "code"}
                    ]},
                    {title: "Blocks", items: [
                        {title: "Paragraph", format: "p"},
                        {title: "Blockquote", format: "blockquote"},
                        {title: "Div", format: "div"},
                        {title: "Pre", format: "pre"}
                    ]},
                    {title: "Alignment", items: [
                        {title: "Left", icon: "alignleft", format: "alignleft"},
                        {title: "Center", icon: "aligncenter", format: "aligncenter"},
                        {title: "Right", icon: "alignright", format: "alignright"},
                        {title: "Justify", icon: "alignjustify", format: "alignjustify"}
                    ]}
                ];
                e.on("init", function () {
                    s(i, function (t) {
                        e.formatter.register(t.name, t)
                    })
                });
                var a = n(e.settings.style_formats || o);
                return a = {type: "menu", items: a, onPostRender: function (t) {
                    e.fire("renderFormatsMenu", {control: t.control})
                }, itemDefaults: {preview: !0, textStyle: function () {
                    return this.settings.format ? t(this.settings.format) : void 0
                }, onPostRender: function () {
                    var t = this, n = this.settings.format;
                    n && t.parent().on("show", function () {
                        t.disabled(!e.formatter.canApply(n)), t.active(e.formatter.match(n))
                    })
                }, onclick: function () {
                    this.settings.format && f(this.settings.format)
                }}}
            }

            function a() {
                return e.undoManager ? e.undoManager.hasUndo() : !1
            }

            function l() {
                return e.undoManager ? e.undoManager.hasRedo() : !1
            }

            function c() {
                var t = this;
                t.disabled(!a()), e.on("Undo Redo AddUndo TypingUndo", function () {
                    t.disabled(!a())
                })
            }

            function d() {
                var t = this;
                t.disabled(!l()), e.on("Undo Redo AddUndo TypingUndo", function () {
                    t.disabled(!l())
                })
            }

            function u() {
                var t = this;
                e.on("VisualAid", function (e) {
                    t.active(e.hasVisual)
                }), t.active(e.hasVisual)
            }

            function f(t) {
                t.control && (t = t.control.value()), t && e.execCommand("mceToggleFormat", !1, t)
            }

            var p;
            p = o(), s({bold: "Bold", italic: "Italic", underline: "Underline", strikethrough: "Strikethrough", subscript: "Subscript", superscript: "Superscript"}, function (t, n) {
                e.addButton(n, {tooltip: t, onPostRender: function () {
                    var t = this;
                    e.formatter ? e.formatter.formatChanged(n, function (e) {
                        t.active(e)
                    }) : e.on("init", function () {
                        e.formatter.formatChanged(n, function (e) {
                            t.active(e)
                        })
                    })
                }, onclick: function () {
                    f(n)
                }})
            }), s({outdent: ["Decrease indent", "Outdent"], indent: ["Increase indent", "Indent"], cut: ["Cut", "Cut"], copy: ["Copy", "Copy"], paste: ["Paste", "Paste"], help: ["Help", "mceHelp"], selectall: ["Select all", "SelectAll"], hr: ["Insert horizontal rule", "InsertHorizontalRule"], removeformat: ["Clear formatting", "RemoveFormat"], visualaid: ["Visual aids", "mceToggleVisualAid"], newdocument: ["New document", "mceNewDocument"]}, function (t, n) {
                e.addButton(n, {tooltip: t[0], cmd: t[1]})
            }), s({blockquote: ["Toggle blockquote", "mceBlockQuote"], numlist: ["Numbered list", "InsertOrderedList"], bullist: ["Bullet list", "InsertUnorderedList"], subscript: ["Subscript", "Subscript"], superscript: ["Superscript", "Superscript"], alignleft: ["Align left", "JustifyLeft"], aligncenter: ["Align center", "JustifyCenter"], alignright: ["Align right", "JustifyRight"], alignjustify: ["Justify", "JustifyFull"]}, function (t, n) {
                e.addButton(n, {tooltip: t[0], cmd: t[1], onPostRender: function () {
                    var t = this;
                    e.formatter ? e.formatter.formatChanged(n, function (e) {
                        t.active(e)
                    }) : e.on("init", function () {
                        e.formatter.formatChanged(n, function (e) {
                            t.active(e)
                        })
                    })
                }})
            }), e.addButton("undo", {tooltip: "Undo", onPostRender: c, cmd: "undo"}), e.addButton("redo", {tooltip: "Redo", onPostRender: d, cmd: "redo"}), e.addMenuItem("newdocument", {text: "New document", shortcut: "Ctrl+N", icon: "newdocument", cmd: "mceNewDocument"}), e.addMenuItem("undo", {text: "Undo", icon: "undo", shortcut: "Ctrl+Z", onPostRender: c, cmd: "undo"}), e.addMenuItem("redo", {text: "Redo", icon: "redo", shortcut: "Ctrl+Y", onPostRender: d, cmd: "redo"}), e.addMenuItem("visualaid", {text: "Visual aids", selectable: !0, onPostRender: u, cmd: "mceToggleVisualAid"}), s({cut: ["Cut", "Cut", "Ctrl+X"], copy: ["Copy", "Copy", "Ctrl+C"], paste: ["Paste", "Paste", "Ctrl+V"], selectall: ["Select all", "SelectAll", "Ctrl+A"], bold: ["Bold", "Bold", "Ctrl+B"], italic: ["Italic", "Italic", "Ctrl+I"], underline: ["Underline", "Underline"], strikethrough: ["Strikethrough", "Strikethrough"], subscript: ["Subscript", "Subscript"], superscript: ["Superscript", "Superscript"], removeformat: ["Clear formatting", "RemoveFormat"]}, function (t, n) {
                e.addMenuItem(n, {text: t[0], icon: n, shortcut: t[2], cmd: t[1]})
            }), e.on("mousedown", function () {
                n.hideAll()
            }), e.addButton("styleselect", {type: "menubutton", text: "Formats", menu: p}), e.addButton("formatselect", function () {
                var n = [], o = i(e.settings.block_formats || "Paragraph=p;Address=address;Pre=pre;Header 1=h1;Header 2=h2;Header 3=h3;Header 4=h4;Header 5=h5;Header 6=h6");
                return s(o, function (e) {
                    n.push({text: e[0], value: e[1], textStyle: function () {
                        return t(e[1])
                    }})
                }), {type: "listbox", text: o[0][0], values: n, fixedWidth: !0, onselect: f, onPostRender: r(n)}
            }), e.addButton("fontselect", function () {
                var t = "Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats", n = [], o = i(e.settings.font_formats || t);
                return s(o, function (e) {
                    n.push({text: {raw: e[0]}, value: e[1], textStyle: -1 == e[1].indexOf("dings") ? "font-family:" + e[1] : ""})
                }), {type: "listbox", text: "Font Family", tooltip: "Font Family", values: n, fixedWidth: !0, onPostRender: r(n, "fontname"), onselect: function (t) {
                    t.control.settings.value && e.execCommand("FontName", !1, t.control.settings.value)
                }}
            }), e.addButton("fontsizeselect", function () {
                var t = [], n = "8pt 10pt 12pt 14pt 18pt 24pt 36pt", i = e.settings.fontsize_formats || n;
                return s(i.split(" "), function (e) {
                    t.push({text: e, value: e})
                }), {type: "listbox", text: "Font Sizes", tooltip: "Font Sizes", values: t, fixedWidth: !0, onPostRender: r(t, "fontsize"), onclick: function (t) {
                    t.control.settings.value && e.execCommand("FontSize", !1, t.control.settings.value)
                }}
            }), e.addMenuItem("formats", {text: "Formats", menu: p})
        }

        var s = r.each;
        i.on("AddEditor", function (t) {
            t.editor.rtl && (e.rtl = !0), a(t.editor)
        }), e.translate = function (e) {
            return i.translate(e)
        }, t.tooltips = !o.iOS
    }), r(Dt, [ht], function (e) {
        return e.extend({recalc: function (e) {
            var t = e.settings, n, r, i, o, a, s, l, c, d, u, f, p, m, h, g, v, y, b, C, x, w, _, N = [], E = [], k, S, T, R, A, B;
            for (t = e.settings, i = e.items().filter(":visible"), o = e.layoutRect(), r = t.columns || Math.ceil(Math.sqrt(i.length)), n = Math.ceil(i.length / r), y = t.spacingH || t.spacing || 0, b = t.spacingV || t.spacing || 0, C = t.alignH || t.align, x = t.alignV || t.align, g = e._paddingBox, C && "string" == typeof C && (C = [C]), x && "string" == typeof x && (x = [x]), u = 0; r > u; u++)N.push(0);
            for (f = 0; n > f; f++)E.push(0);
            for (f = 0; n > f; f++)for (u = 0; r > u && (d = i[f * r + u], d); u++)c = d.layoutRect(), k = c.minW, S = c.minH, N[u] = k > N[u] ? k : N[u], E[f] = S > E[f] ? S : E[f];
            for (A = o.innerW - g.left - g.right, w = 0, u = 0; r > u; u++)w += N[u] + (u > 0 ? y : 0), A -= (u > 0 ? y : 0) + N[u];
            for (B = o.innerH - g.top - g.bottom, _ = 0, f = 0; n > f; f++)_ += E[f] + (f > 0 ? b : 0), B -= (f > 0 ? b : 0) + E[f];
            if (w += g.left + g.right, _ += g.top + g.bottom, l = {}, l.minW = w + (o.w - o.innerW), l.minH = _ + (o.h - o.innerH), l.contentW = l.minW - o.deltaW, l.contentH = l.minH - o.deltaH, l.minW = Math.min(l.minW, o.maxW), l.minH = Math.min(l.minH, o.maxH), l.minW = Math.max(l.minW, o.startMinWidth), l.minH = Math.max(l.minH, o.startMinHeight), !o.autoResize || l.minW == o.minW && l.minH == o.minH) {
                o.autoResize && (l = e.layoutRect(l), l.contentW = l.minW - o.deltaW, l.contentH = l.minH - o.deltaH);
                var L;
                L = "start" == t.packV ? 0 : B > 0 ? Math.floor(B / n) : 0;
                var H = 0, D = t.flexWidths;
                if (D)for (u = 0; u < D.length; u++)H += D[u]; else H = r;
                var M = A / H;
                for (u = 0; r > u; u++)N[u] += D ? D[u] * M : M;
                for (m = g.top, f = 0; n > f; f++) {
                    for (p = g.left, s = E[f] + L, u = 0; r > u && (d = i[f * r + u], d); u++)h = d.settings, c = d.layoutRect(), a = Math.max(N[u], c.startMinWidth), T = R = 0, c.x = p, c.y = m, v = h.alignH || (C ? C[u] || C[0] : null), "center" == v ? c.x = p + a / 2 - c.w / 2 : "right" == v ? c.x = p + a - c.w : "stretch" == v && (c.w = a), v = h.alignV || (x ? x[u] || x[0] : null), "center" == v ? c.y = m + s / 2 - c.h / 2 : "bottom" == v ? c.y = m + s - c.h : "stretch" == v && (c.h = s), d.layoutRect(c), p += a + y, d.recalc && d.recalc();
                    m += s + b
                }
            } else if (l.w = l.minW, l.h = l.minH, e.layoutRect(l), this.recalc(e), null === e._lastRect) {
                var P = e.parent();
                P && (P._lastRect = null, P.recalc())
            }
        }})
    }), r(Mt, [vt], function (e) {
        return e.extend({renderHtml: function () {
            var e = this;
            return e.addClass("iframe"), e.canFocus = !1, '<iframe id="' + e._id + '" class="' + e.classes() + '" tabindex="-1" src="' + (e.settings.url || "javascript:''") + '" frameborder="0"></iframe>'
        }, src: function (e) {
            this.getEl().src = e
        }, html: function (e, t) {
            var n = this, r = this.getEl().contentWindow.document.body;
            return r ? (r.innerHTML = e, t && t()) : setTimeout(function () {
                n.html(e)
            }, 0), this
        }})
    }), r(Pt, [vt, z], function (e, t) {
        return e.extend({init: function (e) {
            var t = this;
            t._super(e), t.addClass("widget"), t.addClass("label"), t.canFocus = !1, e.multiline && t.addClass("autoscroll"), e.strong && t.addClass("strong")
        }, initLayoutRect: function () {
            var e = this, n = e._super();
            if (e.settings.multiline) {
                var r = t.getSize(e.getEl());
                r.width > n.maxW && (n.minW = n.maxW, e.addClass("multiline")), e.getEl().style.width = n.minW + "px", n.startMinH = n.h = n.minH = Math.min(n.maxH, t.getSize(e.getEl()).height)
            }
            return n
        }, repaint: function () {
            var e = this;
            return e.settings.multiline || (e.getEl().style.lineHeight = e.layoutRect().h + "px"), e._super()
        }, text: function (e) {
            var t = this;
            return t._rendered && e && this.innerHtml(t.encode(e)), t._super(e)
        }, renderHtml: function () {
            var e = this, t = e.settings.forId;
            return'<label id="' + e._id + '" class="' + e.classes() + '"' + (t ? ' for="' + t : "") + '">' + e.encode(e._text) + "</label>"
        }})
    }), r(Ot, [U, X], function (e, t) {
        return e.extend({Defaults: {role: "toolbar", layout: "flow"}, init: function (e) {
            var t = this;
            t._super(e), t.addClass("toolbar")
        }, postRender: function () {
            var e = this;
            return e.items().addClass("toolbar-item"), e.keyNav = new t({root: e, enableLeftRight: !0}), e._super()
        }})
    }), r(It, [Ot], function (e) {
        return e.extend({Defaults: {role: "menubar", containerCls: "menubar", defaults: {type: "menubutton"}}})
    }), r(Ft, [yt, V, It], function (e, t, n) {
        function r(e, t) {
            for (; e;) {
                if (t === e)return!0;
                e = e.parentNode
            }
            return!1
        }

        var i = e.extend({init: function (e) {
            var t = this;
            t._renderOpen = !0, t._super(e), t.addClass("menubtn"), e.fixedWidth && t.addClass("fixed-width"), t.aria("haspopup", !0), t.hasPopup = !0
        }, showMenu: function () {
            var e = this, n = e.settings, r;
            return e.menu && e.menu.visible() ? e.hideMenu() : (e.menu || (r = n.menu || [], r.length ? r = {type: "menu", items: r} : r.type = r.type || "menu", e.menu = t.create(r).parent(e).renderTo(e.getContainerElm()), e.fire("createmenu"), e.menu.reflow(), e.menu.on("cancel", function (t) {
                t.control === e.menu && e.focus()
            }), e.menu.on("show hide",function (t) {
                t.control == e.menu && e.activeMenu("show" == t.type)
            }).fire("show"), e.aria("expanded", !0)), e.menu.show(), e.menu.layoutRect({w: e.layoutRect().w}), e.menu.moveRel(e.getEl(), e.isRtl() ? ["br-tr", "tr-br"] : ["bl-tl", "tl-bl"]), void 0)
        }, hideMenu: function () {
            var e = this;
            e.menu && (e.menu.items().each(function (e) {
                e.hideMenu && e.hideMenu()
            }), e.menu.hide(), e.aria("expanded", !1))
        }, activeMenu: function (e) {
            this.toggleClass("active", e)
        }, renderHtml: function () {
            var e = this, t = e._id, r = e.classPrefix, i = e.settings.icon ? r + "ico " + r + "i-" + e.settings.icon : "";
            return e.aria("role", e.parent()instanceof n ? "menuitem" : "button"), '<div id="' + t + '" class="' + e.classes() + '" tabindex="-1"><button id="' + t + '-open" role="presentation" type="button" tabindex="-1">' + (i ? '<i class="' + i + '"></i>' : "") + "<span>" + (e._text ? (i ? "\xa0" : "") + e.encode(e._text) : "") + '</span> <i class="' + r + 'caret"></i></button></div>'
        }, postRender: function () {
            var e = this;
            return e.on("click", function (t) {
                t.control === e && r(t.target, e.getEl()) && (e.showMenu(), t.keyboard && e.menu.items()[0].focus())
            }), e.on("mouseenter", function (t) {
                var n = t.control, r = e.parent(), o;
                n && r && n instanceof i && n.parent() == r && (r.items().filter("MenuButton").each(function (e) {
                    e.hideMenu && e != n && (e.menu && e.menu.visible() && (o = !0), e.hideMenu())
                }), o && (n.focus(), n.showMenu()))
            }), e._super()
        }, text: function (e) {
            var t = this, n, r;
            if (t._rendered)for (r = t.getEl("open").getElementsByTagName("span"), n = 0; n < r.length; n++)r[n].innerHTML = (t.settings.icon && e ? "\xa0" : "") + t.encode(e);
            return this._super(e)
        }, remove: function () {
            this._super(), this.menu && this.menu.remove()
        }});
        return i
    }), r(zt, [Ft], function (e) {
        return e.extend({init: function (e) {
            var t = this, n, r, i, o, a;
            if (t._values = n = e.values, n) {
                for (r = 0; r < n.length; r++)i = n[r].selected || e.value === n[r].value, i && (o = o || n[r].text, t._value = n[r].value);
                e.menu = n
            }
            e.text = e.text || o || n[0].text, t._super(e), t.addClass("listbox"), t.on("select", function (n) {
                var r = n.control;
                a && (n.lastControl = a), e.multiple ? r.active(!r.active()) : t.value(n.control.settings.value), a = r
            })
        }, value: function (e) {
            function t(e, n) {
                e.items().each(function (e) {
                    r = e.value() === n, r && (i = i || e.text()), e.active(r), e.menu && t(e.menu, n)
                })
            }

            var n = this, r, i, o, a;
            if ("undefined" != typeof e) {
                if (n.menu)t(n.menu, e); else for (o = n.settings.menu, a = 0; a < o.length; a++)r = o[a].value == e, r && (i = i || o[a].text), o[a].active = r;
                n.text(i || this.settings.text)
            }
            return n._super(e)
        }})
    }), r(Wt, [vt, V, h], function (e, t, n) {
        return e.extend({Defaults: {border: 0, role: "menuitem"}, init: function (e) {
            var t = this;
            t.hasPopup = !0, t._super(e), e = t.settings, t.addClass("menu-item"), e.menu && t.addClass("menu-item-expand"), e.preview && t.addClass("menu-item-preview"), ("-" === t._text || "|" === t._text) && (t.addClass("menu-item-sep"), t.aria("role", "separator"), t.canFocus = !1, t._text = "-"), e.selectable && (t.aria("role", "menuitemcheckbox"), t.aria("checked", !0), t.addClass("menu-item-checkbox"), e.icon = "selected"), e.preview || e.selectable || t.addClass("menu-item-normal"), t.on("mousedown", function (e) {
                e.preventDefault()
            }), t.on("mouseenter click", function (n) {
                n.control === t && (e.menu || "click" !== n.type ? (t.showMenu(), n.keyboard && setTimeout(function () {
                    t.menu.items()[0].focus()
                }, 0)) : (t.parent().hideAll(), t.fire("cancel"), t.fire("select")))
            }), e.menu && t.aria("haspopup", !0)
        }, hasMenus: function () {
            return!!this.settings.menu
        }, showMenu: function () {
            var e = this, n = e.settings, r, i = e.parent();
            if (i.items().each(function (t) {
                t !== e && t.hideMenu()
            }), n.menu) {
                r = e.menu, r ? r.show() : (r = n.menu, r.length ? r = {type: "menu", items: r} : r.type = r.type || "menu", i.settings.itemDefaults && (r.itemDefaults = i.settings.itemDefaults), r = e.menu = t.create(r).parent(e).renderTo(e.getContainerElm()), r.reflow(), r.fire("show"), r.on("cancel", function () {
                    e.focus()
                }), r.on("hide", function (t) {
                    t.control === r && e.removeClass("selected")
                })), r._parentMenu = i, r.addClass("menu-sub");
                var o = r.testMoveRel(e.getEl(), e.isRtl() ? ["tl-tr", "bl-br", "tr-tl", "br-bl"] : ["tr-tl", "br-bl", "tl-tr", "bl-br"]);
                r.moveRel(e.getEl(), o), r.rel = o, o = "menu-sub-" + o, r.removeClass(r._lastRel), r.addClass(o), r._lastRel = o, e.addClass("selected"), e.aria("expanded", !0)
            }
        }, hideMenu: function () {
            var e = this;
            return e.menu && (e.menu.items().each(function (e) {
                e.hideMenu && e.hideMenu()
            }), e.menu.hide(), e.aria("expanded", !1)), e
        }, renderHtml: function () {
            var e = this, t = e._id, r = e.settings, i = e.classPrefix, o = e.encode(e._text), a = e.settings.icon, s = "", l = r.shortcut;
            return a && e.parent().addClass("menu-has-icons"), r.image && (a = "none", s = " style=\"background-image: url('" + r.image + "')\""), l && n.mac && (l = l.replace(/ctrl\+alt\+/i, "&#x2325;&#x2318;"), l = l.replace(/ctrl\+/i, "&#x2318;"), l = l.replace(/alt\+/i, "&#x2325;"), l = l.replace(/shift\+/i, "&#x21E7;")), a = i + "ico " + i + "i-" + (e.settings.icon || "none"), '<div id="' + t + '" class="' + e.classes() + '" tabindex="-1">' + ("-" !== o ? '<i class="' + a + '"' + s + "></i>&nbsp;" : "") + ("-" !== o ? '<span id="' + t + '-text" class="' + i + 'text">' + o + "</span>" : "") + (l ? '<div id="' + t + '-shortcut" class="' + i + 'menu-shortcut">' + l + "</div>" : "") + (r.menu ? '<div class="' + i + 'caret"></div>' : "") + "</div>"
        }, postRender: function () {
            var e = this, t = e.settings, n = t.textStyle;
            if ("function" == typeof n && (n = n.call(this)), n) {
                var r = e.getEl("text");
                r && r.setAttribute("style", n)
            }
            return e._super()
        }, remove: function () {
            this._super(), this.menu && this.menu.remove()
        }})
    }), r(Vt, [G, X, Wt, f], function (e, t, n, r) {
        var i = e.extend({Defaults: {defaultType: "menuitem", border: 1, layout: "stack", role: "menu"}, init: function (e) {
            var i = this;
            if (e.autohide = !0, e.constrainToViewport = !0, e.itemDefaults)for (var o = e.items, a = o.length; a--;)o[a] = r.extend({}, e.itemDefaults, o[a]);
            i._super(e), i.addClass("menu"), i.keyNav = new t({root: i, enableUpDown: !0, enableLeftRight: !0, leftAction: function () {
                i.parent()instanceof n && i.keyNav.cancel()
            }, onCancel: function () {
                i.fire("cancel", {}, !1), i.hide()
            }})
        }, repaint: function () {
            return this.toggleClass("menu-align", !0), this._super(), this.getEl().style.height = "", this.getEl("body").style.height = "", this
        }, cancel: function () {
            var e = this;
            e.hideAll(), e.fire("cancel"), e.fire("select")
        }, hideAll: function () {
            var e = this;
            return this.find("menuitem").exec("hideMenu"), e._super()
        }, preRender: function () {
            var e = this;
            return e.items().each(function (t) {
                var n = t.settings;
                return n.icon || n.selectable ? (e._hasIcons = !0, !1) : void 0
            }), e._super()
        }});
        return i
    }), r(Ut, [Ct], function (e) {
        return e.extend({Defaults: {classes: "radio", role: "radio"}})
    }), r(qt, [vt, q], function (e, t) {
        return e.extend({renderHtml: function () {
            var e = this, t = e.classPrefix;
            return e.addClass("resizehandle"), "both" == e.settings.direction && e.addClass("resizehandle-both"), e.canFocus = !1, '<div id="' + e._id + '" class="' + e.classes() + '"><i class="' + t + "ico " + t + 'i-resize"></i></div>'
        }, postRender: function () {
            var e = this;
            e._super(), e.resizeDragHelper = new t(this._id, {start: function () {
                e.fire("ResizeStart")
            }, drag: function (t) {
                "both" != e.settings.direction && (t.deltaX = 0), e.fire("Resize", t)
            }, end: function () {
                e.fire("ResizeEnd")
            }})
        }, remove: function () {
            return this.resizeDragHelper && this.resizeDragHelper.destroy(), this._super()
        }})
    }), r(jt, [vt], function (e) {
        return e.extend({renderHtml: function () {
            var e = this;
            return e.addClass("spacer"), e.canFocus = !1, '<div id="' + e._id + '" class="' + e.classes() + '"></div>'
        }})
    }), r($t, [Ft, z], function (e, t) {
        return e.extend({Defaults: {classes: "widget btn splitbtn", role: "splitbutton"}, repaint: function () {
            var e = this, n = e.getEl(), r = e.layoutRect(), i, o;
            return e._super(), i = n.firstChild, o = n.lastChild, t.css(i, {width: r.w - t.getSize(o).width, height: r.h - 2}), t.css(o, {height: r.h - 2}), e
        }, activeMenu: function (e) {
            var n = this;
            t.toggleClass(n.getEl().lastChild, n.classPrefix + "active", e)
        }, renderHtml: function () {
            var e = this, t = e._id, n = e.classPrefix, r = e.settings.icon ? n + "ico " + n + "i-" + e.settings.icon : "";
            return'<div id="' + t + '" class="' + e.classes() + '"><button type="button" hidefocus tabindex="-1">' + (r ? '<i class="' + r + '"></i>' : "") + (e._text ? (r ? " " : "") + e._text : "") + '</button><button type="button" class="' + n + 'open" hidefocus tabindex="-1">' + (e._menuBtnText ? (r ? "\xa0" : "") + e._menuBtnText : "") + ' <i class="' + n + 'caret"></i></button></div>'
        }, postRender: function () {
            var e = this, t = e.settings.onclick;
            return e.on("click", function (e) {
                var n = e.target;
                if (e.control == this)for (; n;) {
                    if ("BUTTON" == n.nodeName && -1 == n.className.indexOf("open"))return e.stopImmediatePropagation(), t.call(this, e), void 0;
                    n = n.parentNode
                }
            }), delete e.settings.onclick, e._super()
        }})
    }), r(Kt, [Lt], function (e) {
        return e.extend({Defaults: {containerClass: "stack-layout", controlClass: "stack-layout-item", endClass: "break"}})
    }), r(Yt, [$, z], function (e, t) {
        return e.extend({lastIdx: 0, Defaults: {layout: "absolute", defaults: {type: "panel"}}, activateTab: function (e) {
            this.activeTabId && t.removeClass(this.getEl(this.activeTabId), this.classPrefix + "active"), this.activeTabId = "t" + e, t.addClass(this.getEl("t" + e), this.classPrefix + "active"), e != this.lastIdx && (this.items()[this.lastIdx].hide(), this.lastIdx = e), this.items()[e].show().fire("showtab"), this.reflow()
        }, renderHtml: function () {
            var e = this, t = e._layout, n = "", r = e.classPrefix;
            return e.preRender(), t.preRender(e), e.items().each(function (t, i) {
                n += '<div id="' + e._id + "-t" + i + '" class="' + r + 'tab" unselectable="on">' + e.encode(t.settings.title) + "</div>"
            }), '<div id="' + e._id + '" class="' + e.classes() + '" hideFocus="1" tabIndex="-1"><div id="' + e._id + '-head" class="' + r + 'tabs">' + n + '</div><div id="' + e._id + '-body" class="' + e.classes("body") + '">' + t.renderHtml(e) + "</div></div>"
        }, postRender: function () {
            var e = this;
            e._super(), e.settings.activeTab = e.settings.activeTab || 0, e.activateTab(e.settings.activeTab), this.on("click", function (t) {
                var n = t.target.parentNode;
                if (t.target.parentNode.id == e._id + "-head")for (var r = n.childNodes.length; r--;)n.childNodes[r] == t.target && e.activateTab(r)
            })
        }, initLayoutRect: function () {
            var e = this, n, r, i;
            r = t.getSize(e.getEl("head")).width, r = 0 > r ? 0 : r, i = 0, e.items().each(function (t, n) {
                r = Math.max(r, t.layoutRect().minW), i = Math.max(i, t.layoutRect().minH), e.settings.activeTab != n && t.hide()
            }), e.items().each(function (e) {
                e.settings.x = 0, e.settings.y = 0, e.settings.w = r, e.settings.h = i, e.layoutRect({x: 0, y: 0, w: r, h: i})
            });
            var o = t.getSize(e.getEl("head")).height;
            return e.settings.minWidth = r, e.settings.minHeight = i + o, n = e._super(), n.deltaH += o, n.innerH = n.h - n.deltaH, n
        }})
    }), r(Gt, [vt, z], function (e, t) {
        return e.extend({init: function (e) {
            var t = this;
            t._super(e), t._value = e.value || "", t.addClass("textbox"), e.multiline ? t.addClass("multiline") : t.on("keydown", function (e) {
                13 == e.keyCode && t.parents().reverse().each(function (t) {
                    return e.preventDefault(), t.hasEventListeners("submit") && t.toJSON ? (t.fire("submit", {data: t.toJSON()}), !1) : void 0
                })
            })
        }, disabled: function (e) {
            var t = this;
            return t._rendered && "undefined" != typeof e && (t.getEl().disabled = e), t._super(e)
        }, value: function (e) {
            var t = this;
            return"undefined" != typeof e ? (t._value = e, t._rendered && (t.getEl().value = e), t) : t._rendered ? t.getEl().value : t._value
        }, repaint: function () {
            var e = this, t, n, r, i = 0, o = 0, a;
            t = e.getEl().style, n = e._layoutRect, a = e._lastRepaintRect || {};
            var s = document;
            return!e.settings.multiline && s.all && (!s.documentMode || s.documentMode <= 8) && (t.lineHeight = n.h - o + "px"), r = e._borderBox, i = r.left + r.right + 8, o = r.top + r.bottom + (e.settings.multiline ? 8 : 0), n.x !== a.x && (t.left = n.x + "px", a.x = n.x), n.y !== a.y && (t.top = n.y + "px", a.y = n.y), n.w !== a.w && (t.width = n.w - i + "px", a.w = n.w), n.h !== a.h && (t.height = n.h - o + "px", a.h = n.h), e._lastRepaintRect = a, e.fire("repaint", {}, !1), e
        }, renderHtml: function () {
            var e = this, t = e._id, n = e.settings, r = e.encode(e._value, !1), i = "";
            return"spellcheck"in n && (i += ' spellcheck="' + n.spellcheck + '"'), n.maxLength && (i += ' maxlength="' + n.maxLength + '"'), n.size && (i += ' size="' + n.size + '"'), n.subtype && (i += ' type="' + n.subtype + '"'), e.disabled() && (i += ' disabled="disabled"'), n.multiline ? '<textarea id="' + t + '" class="' + e.classes() + '" ' + (n.rows ? ' rows="' + n.rows + '"' : "") + ' hidefocus="true"' + i + ">" + r + "</textarea>" : '<input id="' + t + '" class="' + e.classes() + '" value="' + r + '" hidefocus="true"' + i + ">"
        }, postRender: function () {
            var e = this;
            return t.on(e.getEl(), "change", function (t) {
                e.fire("change", t)
            }), e._super()
        }, remove: function () {
            t.off(this.getEl()), this._super()
        }})
    }), r(Xt, [z], function (e) {
        return function (t) {
            var n = this, r;
            n.show = function (i) {
                return n.hide(), r = !0, window.setTimeout(function () {
                    r && t.appendChild(e.createFragment('<div class="mce-throbber"></div>'))
                }, i || 0), n
            }, n.hide = function () {
                var e = t.lastChild;
                return e && -1 != e.className.indexOf("throbber") && e.parentNode.removeChild(e), r = !1, n
            }
        }
    }), a([l, c, d, u, f, p, m, h, g, v, y, b, C, x, w, _, N, E, k, S, T, R, A, B, L, H, D, M, P, O, I, F, z, W, V, U, q, j, $, K, Y, G, X, J, Q, Z, et, tt, nt, rt, it, ot, at, st, lt, ct, dt, ut, ft, pt, mt, ht, gt, vt, yt, bt, Ct, xt, wt, _t, Nt, Et, kt, St, Tt, Rt, At, Bt, Lt, Ht, Dt, Mt, Pt, Ot, It, Ft, zt, Wt, Vt, Ut, qt, jt, $t, Kt, Yt, Gt, Xt])
}(this);
