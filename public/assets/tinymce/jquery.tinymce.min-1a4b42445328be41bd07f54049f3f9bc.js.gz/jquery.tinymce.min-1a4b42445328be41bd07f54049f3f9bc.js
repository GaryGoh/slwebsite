!function (e) {
    function t() {
        function t(e) {
            "remove" === e && this.each(function (e, t) {
                var n = r(t);
                n && n.remove()
            }), this.find("span.mceEditor,div.mceEditor").each(function (e, t) {
                var n = tinymce.get(t.id.replace(/_parent$/, ""));
                n && n.remove()
            })
        }

        function i(e) {
            var n, i = this;
            if (null != e)t.call(i), i.each(function (t, n) {
                var i;
                (i = tinymce.get(n.id)) && i.setContent(e)
            }); else if (i.length > 0 && (n = tinymce.get(i[0].id)))return n.getContent()
        }

        function r(e) {
            var t = null;
            return e && e.id && a.tinymce && (t = tinymce.get(e.id)), t
        }

        function c(e) {
            return!!(e && e.length && a.tinymce && e.is(":tinymce"))
        }

        var u = {};
        e.each(["text", "html", "val"], function (t, a) {
            var o = u[a] = e.fn[a], s = "text" === a;
            e.fn[a] = function (t) {
                var a = this;
                if (!c(a))return o.apply(a, arguments);
                if (t !== n)return i.call(a.filter(":tinymce"), t), o.apply(a.not(":tinymce"), arguments), a;
                var u = "", l = arguments;
                return(s ? a : a.eq(0)).each(function (t, n) {
                    var i = r(n);
                    u += i ? s ? i.getContent().replace(/<(?:"[^"]*"|'[^']*'|[^'">])*>/g, "") : i.getContent({save: !0}) : o.apply(e(n), l)
                }), u
            }
        }), e.each(["append", "prepend"], function (t, i) {
            var a = u[i] = e.fn[i], o = "prepend" === i;
            e.fn[i] = function (e) {
                var t = this;
                return c(t) ? e !== n ? (t.filter(":tinymce").each(function (t, n) {
                    var i = r(n);
                    i && i.setContent(o ? e + i.getContent() : i.getContent() + e)
                }), a.apply(t.not(":tinymce"), arguments), t) : void 0 : a.apply(t, arguments)
            }
        }), e.each(["remove", "replaceWith", "replaceAll", "empty"], function (n, i) {
            var r = u[i] = e.fn[i];
            e.fn[i] = function () {
                return t.call(this, i), r.apply(this, arguments)
            }
        }), u.attr = e.fn.attr, e.fn.attr = function (t, a) {
            var o = this, s = arguments;
            if (!t || "value" !== t || !c(o))return a !== n ? u.attr.apply(o, s) : u.attr.apply(o, s);
            if (a !== n)return i.call(o.filter(":tinymce"), a), u.attr.apply(o.not(":tinymce"), s), o;
            var l = o[0], m = r(l);
            return m ? m.getContent({save: !0}) : u.attr.apply(e(l), s)
        }
    }

    var n, i, r = [], a = window;
    e.fn.tinymce = function (n) {
        function c() {
            var i = [], r = 0;
            t && (t(), t = null), l.each(function (e, t) {
                var a, c = t.id, u = n.oninit;
                c || (t.id = c = tinymce.DOM.uniqueId()), tinymce.get(c) || (a = new tinymce.Editor(c, n, tinymce.EditorManager), i.push(a), a.on("init", function () {
                    var e, t = u;
                    l.css("visibility", ""), u && ++r == i.length && ("string" == typeof t && (e = -1 === t.indexOf(".") ? null : tinymce.resolve(t.replace(/\.\w+$/, "")), t = tinymce.resolve(t)), t.apply(e || tinymce, i))
                }))
            }), e.each(i, function (e, t) {
                t.render()
            })
        }

        var u, o, s, l = this, m = "";
        if (!l.length)return l;
        if (!n)return tinymce.get(l[0].id);
        if (l.css("visibility", "hidden"), a.tinymce || i || !(u = n.script_url))1 === i ? r.push(c) : c(); else {
            i = 1, o = u.substring(0, u.lastIndexOf("/")), -1 != u.indexOf(".min") && (m = ".min"), a.tinymce = a.tinyMCEPreInit || {base: o, suffix: m}, -1 != u.indexOf("gzip") && (s = n.language || "en", u = u + (/\?/.test(u) ? "&" : "?") + "js=true&core=true&suffix=" + escape(m) + "&themes=" + escape(n.theme || "modern") + "&plugins=" + escape(n.plugins || "") + "&languages=" + (s || ""), a.tinyMCE_GZ || (a.tinyMCE_GZ = {start: function () {
                function t(e) {
                    tinymce.ScriptLoader.markDone(tinymce.baseURI.toAbsolute(e))
                }

                t("langs/" + s + ".js"), t("themes/" + n.theme + "/theme" + m + ".js"), t("themes/" + n.theme + "/langs/" + s + ".js"), e.each(n.plugins.split(","), function (e, n) {
                    n && (t("plugins/" + n + "/plugin" + m + ".js"), t("plugins/" + n + "/langs/" + s + ".js"))
                })
            }, end: function () {
            }}));
            var p = document.createElement("script");
            p.type = "text/javascript", p.onload = p.onreadystatechange = function (t) {
                t = t || event, 2 === i || "load" != t.type && !/complete|loaded/.test(p.readyState) || (tinymce.dom.Event.domLoaded = 1, i = 2, n.script_loaded && n.script_loaded(), c(), e.each(r, function (e, t) {
                    t()
                }))
            }, p.src = u, document.body.appendChild(p)
        }
        return l
    }, e.extend(e.expr[":"], {tinymce: function (e) {
        return!!(e.id && "tinymce"in window && tinymce.get(e.id))
    }})
}(jQuery);
